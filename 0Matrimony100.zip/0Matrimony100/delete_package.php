<?php
include "header.php";
require "dbi.php";
?>
<?php
$pm_id= $_POST["pm_id"];

//require "dbi.php";

$query="delete from package_master where pm_id=$pm_id";

mysqli_query($con,$query) or die(mysqli_error($con));

if(mysqli_affected_rows($con) > 0)
{
	header("location:package_list.php");
}

?>