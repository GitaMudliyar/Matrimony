<?php
include "header.php";
require "dbi.php";
$pm_id= $_POST["pm_id"];
//$package_type= $_POST["package_type"];


//require "dbi.php";

$package_type=strtoupper($_POST["package_type"]);
$price= $_POST["price"];
$discount= $_POST["discount"];
$duration=$_POST["duration"];
$chat_limit=$_POST["chat_limit"];

$query="update package_master set package_type='$package_type',price='$price',discount='$discount', duration='$duration',chat_limit='$chat_limit' where pm_id=$pm_id";
//echo $query;

mysqli_query($con,$query) or die(mysqli_error($con));

if(mysqli_affected_rows($con) > 0)
{
	header("location:package_list.php");
}

?>