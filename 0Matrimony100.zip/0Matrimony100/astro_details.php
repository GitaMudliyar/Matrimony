<?php
include "header.php";
require "dbi.php";
?>
<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
}

table{
	width:95%;
}


</style>
</head>
<body>

<?php 
//include "header.php"; 
//include "validate_member.php";

?>
<form action="update_astro_details.php" method="post">
<div class='table-responsive' >
<table border='0'>

<th>
<!--
  <font color="navy">
<b><h4><a href="personal_information.php" id="aa"  class='btn active  btn-primary'   style="background-color:crimson";><span></span>
	<span></span><span></span><span></span>01 Personal Information&nbsp;
	</a></h4></b>
	<br>
	<h4><a href="profile_details.php" id="aa" class='btn active  btn-primary' style="background-color:crimson">02 Profile Details
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		
	<h4><a href="family_details.php" id="aa" class='btn active  btn-primary'style="background-color:crimson">03 Family Details
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
	
	<h4><a href="astro_details.php" id="aa" class='btn active  btn-primary'style="background-color:pink"><font color="navy">04 Astro Details</font>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>

	<h4><a href="education_and_career.php" id="aa" class='btn active  btn-primary'style="background-color:crimson">05 Education And Career</a></h4><br>

	<h4><a href="hobbies_and_traits.php" id="aa" class='btn active  btn-primary'style="background-color:crimson">06 Hobbies and Traits
	&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		<h4><a href="about_myself.php" id="aa" class='btn active  btn-primary'style="background-color:crimson"> 07 About Myself
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		
		<h4><a href="expectation.php" id="aa" class='btn active  btn-primary'style="background-color:crimson"> 08 My Expectations
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		
		<h4> <a href="upload_photo.php"id="aa" class='btn active  btn-primary'style="background-color:crimson">09 Upload Profile Photo&nbsp;&nbsp;</a></h4><br>
    
	</font>
    
  </th><th>-->
  

  		<?php
//include "dbi.php";

if(!empty($uname))
{
	$result = mysqli_query($con,"select * from astro_details where uname='$uname'");

	if($row=mysqli_fetch_array($result))
	{
		
//$about_self=$row["about_self"];
//$h_activities=$row["h_activities"];



$country_of_birth=$row["country_of_birth"];
$city_of_birth=$row["city_of_birth"];

$time_of_birth=$row["time_of_birth"];
$manglik=$row["manglik"];
$rashi=$row["rashi"];
$nakshatra=$row["nakshatra"];
$want_horoscope_match=$row["want_horoscope_match"];

	}
	else
	{
		//$about_self="";
		
		$country_of_birth="";
$city_of_birth="";

$time_of_birth="";
$manglik="";
$rashi="";
$nakshatra="";
$want_horoscope_match="";
		
		
		
	}

}


?>
  

  
 <!--   <h2>Column 2</h2>
    <p>Some text..</p>-->
	

	<div class="wizard-header">
									<h3 class="heading"><b>Astro Details</b></h3>
									<p>Please enter your infomation and proceed to the next step so we can build your accounts.</p>
								</div>
								
								
								<div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>Country Of Birth:</legend>
											<input type="text" class="form-control" id="Place" name="country_of_birth" placeholder="Enter Country Name"  style='text-transform:uppercase' required>
										</fieldset>
									</div>
								</div>
								
								
								<div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>City Of Birth:</legend>
											<input type="text" class="form-control" id="Place" name="city_of_birth" placeholder="Enter Name"  style='text-transform:uppercase' required>
										</fieldset>
									</div>
								</div>
								
								
								<div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>Time Of Birth:</legend>
											
										<table>
										<tr>
										<th>
									
											
	
						<div class="form-holder">
											
											 <select name="hour" class="form-control text">
			                       <option value="">Hour</option>
	             	                               <option value="1hr">1hr</option>
	<option value="2hr ">2hr</option>
	<option value="3hr ">3hr </option>
	<option value="4hr ">4hr </option>
	<option value="5hr ">5hr</option>
	<option value="6hr ">6hr</option>
	<option value="7hr ">7hr</option>
	<option value="8hr ">8hr</option>
	<option value="9hr ">9hr</option>
	<option value="10hr ">10hr</option>
	<option value="11hr ">11hr</option>
	<option value="12hr ">12hr</option>
	</th>
</div>

<th>
<div class="form-holder">
											<!-----<legend>Height</legend>-->
											 <select name="minute" class="form-control text">
			                       <option value="">Minute</option>
	                               <option value="1min">1min</option>
	<option value="2min">2min </option>
	<option value="3min">3min </option>
	<option value="4min">4min</option>
	<option value="5min">5min</option>
	<option value="6min">6min</option>
	<option value="7min">7min</option>
	<option value="8min">8min </option>
	<option value="9min">9min</option>
	<option value="10min">10min</option>
	<option value="11min">11min</option>
	<option value="12min">12min</option>
	<option value="13min">13min</option>
    <option value="14min">14min</option>
<option value="15min">15min</option>
<option value="16min">16min</option>
<option value="17min">17min</option>
<option value="18min">18min</option>
<option value="19min">19min</option>
<option value="20min">20min</option>
<option value="21min">21min</option>
<option value="22min">22min</option>
<option value="23min">23min</option>
<option value="24min">24min</option>
<option value="25min">25min</option>
<option value="26min">26min</option>
<option value="27min">27min</option>
<option value="28min">28min</option>
<option value="29min">29min</option>
<option value="30min">30min</option>
<option value="31min">31min</option>
<option value="32min">32min</option>
<option value="33min">33min</option>
<option value="34min">34min</option>
<option value="35min">35min</option>
<option value="36min">36min</option>
<option value="37min">37min</option>
<option value="38min">38min</option>
<option value="39min">39min</option>
<option value="40min">40min</option>
<option value="41min">41min</option>
<option value="42min">42min</option>
<option value="43min">43min</option>
<option value="44min">44min</option>
<option value="45min">45min</option>
<option value="46min">46min</option>
<option value="47min">47min</option>
<option value="48min">48min</option>
<option value="49min">49min</option>
<option value="50min">50min</option>
<option value="51min">51min</option>
<option value="52min">52min</option>
<option value="53min">53min</option>
<option value="54min">54min</option>
<option value="55min">55min</option>
<option value="56min">56min</option>
<option value="57min">57min</option>
<option value="58min">58min</option>
<option value="59min">59min</option>
<option value="00min">00min</option>


	
	
	
</select>
						</th>
						<th>
						<div class="form-holder">
											
											 <select name="am_pm" class="form-control text">
			                       <option value="">select</option>
	                               <option value=" AM">AM</option>
	<option value=" PM">PM </option>
	</th>
			</tr>
	</table>
			</div>
								
								
								
								
								
								<div class="form-row">
									<div class="form-holder form-holder-2">
										
											<legend>Manglik:</legend>
											<select name="manglik" class="form-control text">
											
											<option value="Select">SELECT</option>
											
	                                        <option value="Yes">Yes</option>
	                                        <option value="No">No</option>
											
	                                        </select>
											
											</div>
											</div>
											
										
								
								
								
								<div class="form-row">
									<div class="form-holder form-holder-2">
										
											<legend>Rashi:</legend>
											<select name="rashi" class="form-control text">
											
											<option value="Select">SELECT</option>
											
	                                        <option value="Aries_Mesha">Aries(Mesha)</option>
	                                        <option value="Taurus_Vrishabha">Taurus(Vrishabha)</option>
											<option value="Gemini_Mithuna">Gemini(Mithuna)</option>
											<option value="Cancer_Karka">Cancer(Karka)</option>
											<option value="Leo_Singha">Leo(Singha)</option>
											<option value="Virgo_Kanya">Virgo(Kanya)</option>
										    <option value="Libra_Tula">Libra(Tula)</option>
										    <option value="Scorpio_Vrushchika">Scorpio(Vrushchika)</option>
										    <option value="Sagittarius_Dhanu">Sagittarius(Dhanu)</option>
											<option value="Capricorn_Makara">Capricorn(Makara)</option>
										    <option value="Aquarius_Kumbha">Aquarius(Kumbha)</option>
										    <option value="Pisces_Meena">Pisces(Meena)</option>
											
											
	                                        </select>
									</div>
								
								</div>
								
								
								<div class="form-row">
									<div class="form-holder form-holder-2">
										
											<legend>Nakshatra:</legend>
											<select name="nakshatra" class="form-control text">
											
											<option value="Select">SELECT</option>
											
	                                        <option value="ashwini">Ashwini</option>
											<option value="bharani">Bharani</option>
											<option value="krittika">Krittika</option>
											<option value="rohini">Rohini</option>
											<option value="mrigashirsha ">Mrigashirsha</option>
											<option value="ardra">Ardra</option>
											<option value="punarvasu">Punarvasu</option>
											<option value="pushya">Pushya</option>
											
											 <option value="ashlesha">Ashlesha</option>
											<option value="magha">Magha</option>
											<option value="purva phalguni">Purva Phalguni</option>
											<option value="uttara phalguni">Uttara Phalguni</option>
											<option value="hasta">Hasta</option>
											<option value="chitra">Chitra</option>
											<option value="svati">Svati</option>
											<option value="visakha">Visakha</option>
											
											 <option value="anuradha">Anuradha</option>
											<option value="jyeshtha">Jyeshtha</option>
											<option value="mula">Mula</option>
											<option value="purva ashadha">Purva Ashadha</option>
											<option value="uttara ashadha">Uttara Ashadha</option>
											<option value="sravana">Sravana</option>
											<option value="dhanishta">Dhanishta</option>
											<option value="shatabhisha">Shatabhisha</option>
											
											<option value="Purva bhadrapada">Purva Bhadrapada</option>
											<option value="uttara bhadrapada">Uttara Bhadrapada</option>
											<option value="revati">Revati</option>
											
											</select>
									</div>
								</div>
								
								
								
								<div class="form-row">
									<div class="form-holder form-holder-2">
										
											<legend>Do u require horoscope match with your partner??</legend>
											<select name="want_horoscope_match" class="form-control text">
											
											<option value="Select">SELECT</option>
											
	                                        <option value="Must">Must</option>
	                                        <option value="No">No</option>
											<option value="Does not Matter">Does not Matter</option>
											
	                                        </select>
										
											</div>
											</div>
											<br>
		 <a href=' personal_information.php' class='btn active  btn-primary' style='background-color:green';>Previous</font></a>

&nbsp;&nbsp;&nbsp;
<input type="submit" name="submit"  class='btn active  btn-danger' value="Save and Next"  style="background-color:blue;"/>
		 <!--<input type="submit" name="submit" value="Save and Next"  style="background-color:#2eb82e;"/>-->
  </div>
</div>
</form>
</body>
</html>