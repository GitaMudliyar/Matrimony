<?php 
include "header.php";
?>
<center>
<div class='well text-center'><h2 style='color:red'>Partner's Username Not Found!!!</h2>
<p><a href='share_story.php'><div class='well text-center'>
		<h4 style='color:navy'>Click Here to Change Partner's Username</h4>
   </a></p></div>
</center>
