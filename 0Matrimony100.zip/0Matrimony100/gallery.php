<?php
include "header.php";
//require "dbi.php";
?>
<!DOCTYPE html>

<?php 
//include "header.php";
?> 
<html> 

<head> 
	<title>Wedding-Gallery</title> 
	<link rel="stylesheet"
		type="text/css"
		href="lightbox2/dist/css/lightbox.min.css"> 
	<script src= 
"lightbox2/dist/js/lightbox-plus-jquery.min.js"> 
	</script> 
	<style> 
		body { 
			text-align: center; 
			background:url(images/nb.jpg);

background-size:cover;
		} 
		img{
			border: 1px solid black;
		}
		
		h2 { 
			color: purple; 
		} 

		.gallery { 
			margin: 10px 40px; 
		} 
		
		.gallery img { 
			width: 200px; 
			height: 200px; 
			transition: 1s; 
			padding: 5px; 
		} 
		
		.gallery img:hover { 
			filter: drop-shadow(4px 4px 6px gray); 
			transform: scale(1.1); 
		} 

	</style> 
</head> 

<body > 
	
	<div class="gallery"> 
		<a href= 
"images/try1.jpg"
		data-lightbox="mygallery"> 
			<img src= 
"images/try1.jpg"> 
		</a> 
		<a href= 
"images/try2.jpg"
		data-lightbox="mygallery"> 
			<img src= 
"images/try2.jpg"> 
		</a> 
		<a href= 
"images/try3.jpg"
		data-lightbox="mygallery"> 
			<img src= 
"images/try3.jpg"> 
		</a> 
		<a href= 
"images/try6.jpg"
		data-lightbox="mygallery"> 
			<img src= 
"images/try6.jpg"> 
		</a> 
		<a href= 
"images/try14.jpg"
		data-lightbox="mygallery"> 
			<img src= 
"images/try14.jpg"> 
		</a> 
		<a href= 
"images/try8.jpg"
		data-lightbox="mygallery"> 
			<img src= 
"images/try8.jpg"> 
		</a> 
		
		<a href= 
"images/carouse1.jpg"
		data-lightbox="mygallery"> 
			<img src= 
"images/carouse1.jpg"> 
		</a> 
		
		<a href= 
"images/trial.jpg"
		data-lightbox="mygallery"> 
			<img src= 
"images/trial.jpg"> 
		</a> 
		
		<a href= 
"images/try13.jpg"
		data-lightbox="mygallery"> 
			<img src= 
"images/try13.jpg"> 
		</a> 
		
		<a href= 
"images/try15.jpg"
		data-lightbox="mygallery"> 
			<img src= 
"images/try15.jpg"> 
		</a>
		<a href= 
"images/try16.jpg"
		data-lightbox="mygallery"> 
			<img src= 
"images/try16.jpg"> 
		</a>
		<a href= 
"images/try17.jpg"
		data-lightbox="mygallery"> 
			<img src= 
"images/try17.jpg"> 
		</a>
		<a href= 
"images/try18.jpg"
		data-lightbox="mygallery"> 
			<img src= 
"images/try18.jpg"> 
		</a>
		
		<a href= 
"images/try19.jpg"
		data-lightbox="mygallery"> 
			<img src= 
"images/try19.jpg"> 
		</a>
		
	</div> 
	<h2><b><i>Made For Each Other</i></b></h2> 
	<h4><b><i>To a Lifetime of Adventures Together</i></b> <h4>
</body> 

</html> 
