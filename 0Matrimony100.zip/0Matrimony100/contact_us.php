<?php
include "header.php";
//require "dbi.php";
?>
<!DOCTYPE html>
<html lang="en">
<?php
//include "header.php";
?>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>My First Bootstrap Application</title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">

</head>
<style>



.button {
  border: none;
  color: white;
  padding: 5px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  transition-duration: 0.4s;
  cursor: pointer;
}

.button1 {
  background-color: DodgerBlue; 
  color: black; 
  <!--border: 2px solid #4CAF50;-->
}

.button1:hover {
  background-color: DodgerBlue;
  color: white;
}
.bg{
   background-image: url("img/back");
  background-repeat: no-repeat;
  background-size: cover;

}
.responsive {
  width: 1400px;
  height: 300px;
}

.responsive1 {
  width: 100%;
  height: 300px;
}

</style>
<!--</style>-->

<body style="background-image:url('images/nb3.jpg'); background-size:cover;">
<form action="act_contact.php" method="post">



<img src="images/C6.jpg" width="1200" height="200" class="responsive1">

<br><br><br>
<div class="container" >

<div class="table-responsive" >
<table class="table table-hover table-bordered table-striped">
<th>
<div class="form-group">

<input type="hidden" class="form-control input-sm" name="cid" />

                 <label for="nameField">Name</label>
                 <input type="text" class="form-control input-sm" name="name" required placeholder="User Name" />
                 </div>
				 
				 
				 <div class="form-group">
                 <label for="nameField">Date</label>
                 <input type="text" class="form-control input-sm" name="u_date" value= "<?php echo date("y-m-d");?>" readonly />
                 </div>
				 <div class="form-group">
                 <label for="nameField">Email</label>
                 <input type="Email" class="form-control input-sm" name="e_mail" required placeholder="Enter Email" />
                 </div>
				 <div class="form-group">
                 <label for="nameField">Subject</label>
                 <input type="text" class="form-control input-sm" name="subject" required placeholder="Subject" />
                 </div>
				 <div class="form-group">
                 <label for="nameField">Message</label>
                 <input type="text" class="form-control input-sm" name="message" required placeholder="Enter here" />
                 </div>
				 
				<button class="button button1">Submit</button>
</th>
<th style="width:400px"><center><h4><u><b><i>Spark Technologies </i></b></u></h4><br><br>
          <h4><u>Office Address:</u></h4>
		  Flat No -6, 'Krishnasmruti',<br>
		   Govt. Colony, Vishrambag,<br>
		   Sangli, 416410<br><br>
		   <h4><u>Call Us:</u></h4>
		    7499212234, 9595909041<br><br>
			
			 <h4><u>Email:</u></h4>
			 contact@sparktechsoft.co.in
		  
           

</center></th>

<!--</th>

</th>

</th>

<th>City</th>-->

<tr>


</table>
</div>

</div>

<center><h3>View on Map</h3></center><br>
<center>

<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d122189.8734698753!2d74.51405940668576!3d16.85443471524121!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bc10c8187f060eb%3A0x37911f53cdc1ddb3!2sSangli%2C+Maharashtra!5e0!3m2!1sen!2sin!4v1491388946089" width="600" height="450" frameborder="0" style="border:0" allowfullscreen></iframe>
</center></div>
</form>
<script src="js/jquery.js"></script>

<script src="js/bootstrap.js"></script>

</html>