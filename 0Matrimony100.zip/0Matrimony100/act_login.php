<?php
include "header.php";
include "dbi.php";

$uname=$_POST["uname"];
$pwd=$_POST["pwd"];
$captcha=$_POST["captcha"];
$n3=$_POST["n3"];

//echo $captcha."Captcha<br>" ;
//echo "n3=".$n3."<br>";

if($captcha == $n3)
{	
	$query = "select * from login where uname='$uname' and pwd=md5('$pwd')";

	$result = mysqli_query($con,$query) or die(mysqli_error($con));

	if($row=mysqli_fetch_array($result))
	{
		$role = strtolower($row["role"]);

		$_SESSION["uname"] = $row["uname"];
		$_SESSION["role"] = $role;

		if($role=="member")
			header("location:member.php");	//auto-redirect
		else if($role=="admin")
			header("location:admin.php");
		else
			header("location:index.php");

	}
	else
	{
		echo "<div class='well text-center'>";
		echo "<h3>Invalid Credentials</h3>";
		echo "<p><a href='login.php'>Try Again</a></p>";
		echo "</div>";
	}
	include "footer.php";
}

else
{
	echo "<center><div class='well text-center'><h1 style='color:red'>Invalid Captcha!!!</h1>";
	//echo "<div class='well text-center'><h2 style='color:maroon'>Thank You! For Your Feedback</h2>";
	echo "<p><h3><a href='login.php'  style='color:navy'>Try Again</a></h3></p></div></div></center>";
}
?>