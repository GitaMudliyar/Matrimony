<?php
include "header.php";   // session started in header file - session_start();
include "dbi.php";
//$uname=$_POST["uname"];
//$about_self=$_POST["about_self"];

$country_of_birth=$_POST["country_of_birth"];
$city_of_birth=$_POST["city_of_birth"];

$hour=$_POST["hour"];
$minute=$_POST["minute"];
$am_pm=$_POST["am_pm"];

$time_of_birth=$hour.$minute.$am_pm;
$manglik=$_POST["manglik"];
$rashi=$_POST["rashi"];
$nakshatra=$_POST["nakshatra"];
$want_horoscope_match=$_POST["want_horoscope_match"];


mysqli_query($con,"update astro_details set country_of_birth='$country_of_birth',city_of_birth='$city_of_birth',time_of_birth='$time_of_birth',manglik='$manglik',rashi='$rashi',nakshatra='$nakshatra',want_horoscope_match='$want_horoscope_match' where uname='$uname'") or die(mysqli_error($con));
if(mysqli_affected_rows($con) > 0)
{
	//echo "<div class='well text-center'><h2 style='color:green'>Success: Astro Details Updated!</h2>";
	//echo "<p><a href='education_and_career.php'>Back To Panel</a></p></div>";
	header("location:education_and_career.php");	
}

//include "footer.php";
?>

