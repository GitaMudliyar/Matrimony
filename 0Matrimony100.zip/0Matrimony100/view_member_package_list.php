<?php
include "header.php";
require "dbi.php";
?>
<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}

tr:hover{
	background-color:FloralWhite;
}

table{
	width:95%;
}

</style>

<?php
$pm_id = $_GET["pm_id"];
$package_type = $_GET["package_type"];


//include "header.php";
//include "dbi.php";


//$skill=$_GET["sk"];

//$query = "select * from worker_profile where w_uname in (select w_uname from v_skills where service_type='$sk')";
$query = "select * from package_type where pm_id='$pm_id'";
//echo $query;

//$skill=strtoupper($skill);
$result=mysqli_query($con,$query);
echo "<p><center><a href='package_list.php'> Back </a></center></p>";
//echo "<h2 class='text-center'>$skill</h2>";
echo '<div class="table-responsive">';
echo "<p style='color:red;'><b><h3><center>".$package_type."</center></h3></b></p>";
echo '<table border>';
echo "<tr bgcolor='DeepPink'><th><center>Sr. No. </center></th><th><center>User ID</center></th>";
echo "<th><center>Name</center></th></tr>";

$cnt=0;

while($row=mysqli_fetch_array($result))
{
	$cnt++;
	$uname=$row["uname"];
	$m_nm = $row["m_nm"];

	echo "<tr>";
	echo "<td>".$cnt."</td>";
	//echo "<td>".$nm."</td>";
	echo "<td>".$row["uname"]."</td>";
	echo "<td>".$row["m_nm"]."</td>";
	
	
	echo "</tr>";
	
}
echo "<div><font color='deepPink'><center><b><h4 style='color:crimson'> $cnt Proile Exist</h4></b></center></font> ";

echo "</table></div>";

mysqli_close($con);

?>