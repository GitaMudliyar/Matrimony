<?php
include "header.php";
require "dbi.php";
?>
<style>
th,td{
	background-color:#FFEFD5;
	padding:15px;
	text-align:left;
	border-bottom:1px solid Darkgray;
	height:50px;
	text-align:center;
}

tr:hover{
	background-color:FloralWhite;
}
th{
	background-color:#F52887;
}

table{
	background-color:#FFD700;
	width:95%;
}

</style>
<?php
//include "header.php";
//require "dbi.php";

//echo $uname;


//$f_uname=$_GET["uname"];
$mdate=date("Y-m-d");

$query="select * from interest where  f_uname='$uname'";

$result = mysqli_query($con,$query) or die(mysqli_error($con));

echo "<center>";

//echo "<p><a href='new_cat.php'>New Category</a></p>";
echo "<div class='table-responsive'>";
echo "<table border='1'>";
echo "<tr bgcolor='RoyalBlue'><th><center>Name</center></th><th><center>Sended Request On</center></th>";
echo "<th><center>Name</center></th></tr>";
//$cnt=0;

while($row=mysqli_fetch_array($result))
{
	$mdate=$row["mdate"];
	$t_uname=$row["t_uname"];

	echo "<tr>";
	echo "<td>&nbsp;".$row["t_uname"]."</td>";
	echo "<td>&nbsp;".$row["mdate"]."</td>";
	echo "<td>&nbsp;&nbsp;&nbsp;<a href='remove_sent_interest.php?t_uname=$t_uname' class='btn active  btn-primary' style='background-color:#00a3cc';>Now Not Interested</font></a>";
	echo "</td>";

	echo "</tr>";
}

echo "</table>";
echo "</div>";
echo "<br>";
echo "<p><a href='member.php' class='btn btn-danger btn-block'>Back To Panel</a></p>";

echo "<center>";

mysqli_close($con);
include "footer.php";
?>
