<?php
include "header.php";   // session started in header file - session_start();
include "dbi.php";
//$uname=$_POST["uname"];
//$about_self=$_POST["about_self"];
$e_educational_level=$_POST["e_educational_level"];
$e_educational_field=$_POST["e_educational_field"];
$e_annual_income=$_POST["e_annual_income"];
$e_family_status=$_POST["e_family_status"];




mysqli_query($con,"update education_and_career set e_educational_level='$e_educational_level' ,e_educational_field='$e_educational_field',e_annual_income='$e_annual_income',e_family_status='$e_family_status' where uname='$uname'") or die(mysqli_error($con));
if(mysqli_affected_rows($con) > 0)
{
	//echo "<div class='well text-center'><h2 style='color:green'>Success: Education And Career Updated!</h2>";
	//echo "<p><a href='hobbies_and_traits.php'>Back To Panel</a></p></div>";
	header("location:hobbies_and_traits.php");	
}

//include "footer.php";
?>

