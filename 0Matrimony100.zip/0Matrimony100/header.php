<?php

include "top_header.php";
session_start();

$uname = isset($_SESSION["uname"])?$_SESSION["uname"]:"";
$role = isset($_SESSION["role"])?$_SESSION["role"]:"Guest";

?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Reshim Gathi</title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link href="css/styles.css" rel="stylesheet">

<style>

body{
	background:url(images/nb1.jpg);
	 background-size: cover;
}
div{
	<!--background-color: coral;-->
}
li {
  color: green;
}

	

</style>
</head>
<body>


    <div class="navbar navbar-inverse">
	<div class="container-fluid" style="background-color:DarkGray;">
	<div class="navbar-header" style="background-color:DarkGrey;">
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mynavbar-content">
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		</button>

	<b><a class="navbar-brand active" href="gallery.php"><font style="font-family:'Lucida Handwriting'"color="#ffff00" size="6px">Reshim Gathi</font></a></b>
	</div>
		<div class="collapse navbar-collapse" id="mynavbar-content" style="background-color:DarkGrey;">
			<ul class="nav navbar-nav">
				<li class><a href="index.php"><font color="black">Home</a></font></li>
				<li class="dropdown">
				  <a href="successful.php" class="dropdown-toggle" data-toggle="dropdown" style="background-color:DarkGrey;"><font color="Black"> About Us</font><b class="caret"></b></a>
					<ul class="dropdown-menu">
						<li><a href="gallery.php"><font color="black">Gallery</font></a></li>
						<!--<li><a href="successful.php"><font color="black">Our Successful Stories</font></a></li>-->
						<li><a href="successful_stories2.php"><font color="black">Our Successful Stories</font></a></li>
						<!--<li><a href="#">Designing Team</a></li>-->
						<li class="divider"></li>
						<li><a href="rules.php"><font color="black">Rules</font></a></li>
						<!--<li><a href="#">Registration</a></li>-->
					</ul>
				</li>
				
				<li><a href="contact_us.php"><font color="black">Contact Us</font></a></li>
				<li><a href="feedback.php"><font color="black">Feedback</font></a></li>
				<li><a href="registration.php"><font color="black">New Registration</font></a></li>

							<li>

<?php

		if($role=="admin")
		{
			//echo "<li><a style='color:black' href='admin.php'>Admin</a></li>	";
			 echo "<a href='admin.php' class='dropdown-toggle' data-toggle='dropdown' style='background-color:DarkGrey;'><font color='Black'> Admin</font><b class='caret'></b></a>";
		 
		echo "<ul class='dropdown-menu'>";
		echo "<li><a href='admin.php'><font color='black'>Admin</font></a></li>";
		echo "<li><a href='admin_package_to_be_renewed.php'><font color='black'>Package To Be Renewed</font></a></li>";
		//echo "<li><a href='active_participant_list.php'>Active Participants</a>";
		echo "</li>";
		echo "<li class='divider'></li>";
		echo "<li><a href='admin_blocked_list.php'><font color='black'>Blocked List</font></a></li>";
		echo "<li><a href='admin_like_list.php'>Matched Interest</a></li>";
		echo "</ul>";
			
		}
		else if($role=="member")
		{
			//echo "<li><a style='color:black' href='member.php'>Member</a></li>";
			
		 echo "<a href='member.php' class='dropdown-toggle' data-toggle='dropdown' style='background-color:DarkGrey;'><font color='Black'> Member</font><b class='caret'></b></a>";
		 
		echo "<ul class='dropdown-menu'>";
		echo "<li><a href='member.php'><font color='black'>Member</font></a></li>";
		echo "<li><a href='search_filter.php'><font color='black'>Search Partner</font></a></li>";
		//echo "<li><a href='#'>Designing Team</a></li>";
		echo "<li class='divider'></li>";
		echo "<li><a href='blocked_list.php'><font color='black'>Blocked List</font></a></li>";
		echo "<li><a href='interest_sent_list.php'><font color='black'>Favourites</font></a></li>";
		//echo "<li><a href=''>My Album</a></li>";
		echo "</ul>";
		//echo "</li>";
		}
		/*else if($role=="worker")
		{
			echo "<li><a href='worker.php'>Worker</a></li>";
		}*/


		if(empty($uname))
			echo "<li> <a style='background:LavenderBlush' href='login.php'><b>Login</b></a></li>	";
		
		else
		{
			
			echo "<li><a style='background:LavenderBlush' href='logout.php'><b>Logout $uname</b></a></li>";
		}
		?>
		
		
			</li>
				
				
			</ul>	
		</div>
	</div>
</div>