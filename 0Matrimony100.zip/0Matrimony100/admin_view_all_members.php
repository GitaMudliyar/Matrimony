<?php
include "header.php";
require "dbi.php";
?> 
<style>
th,td{
	background-color:#FFEFD5;
	padding:15px;
	text-align:left;
	border-bottom:1px solid Darkgray;
	height:50px;
	text-align:center;
	
}

tr:hover{
	<!--background-color:FloralWhite;-->
}

table{
	background-color:#FFD700;
	width:95%;
}

</style>

<?php
//include "header.php";
//require "dbi.php";
  
$query1="select * from view_profile_match";
//echo $query1;

$result1 = mysqli_query($con,$query1) or die(mysqli_error($con));

echo "<center>";

//echo "<p><a href='new_cat.php'>New Category</a></p>";
echo "<div class='table-responsive'>";
echo "<table>";
/*echo "<tr bgcolor='RoyalBlue'><th>";
echo "<th><center>Picture</center></th><center>First Name</center></th><th><center>Last Name</center>";
echo "</th><th><center>Gender</center></th><th><center>DOB</center></th><th><center>Height</center></th><th><center>City</center></th><th><center>Manglik</center></th><th><center>Caste</center></th><th><center>Annual Income</center></th></tr>";
*/
//$cnt=0;

while($row=mysqli_fetch_array($result1))
{
	//$cnt++;
	//$id=$row["cpid"];
	$uname=$row["uname"];
	$nm = $row["fname"]." ".$row["lname"];
	$fname=$row["fname"];
	$lname=$row["lname"];
	//$gender=$row["gender"];
	$dob=$row["dob"];
	$height=$row["height"];
	$city=$row["city"];
	$manglik=$row["manglik"];
	$caste=$row["caste"];
	$annual_income=$row["annual_income"];

	echo "<tr>";
	echo "<font color='white'>";
	//echo "<td align='center'>$cnt</td>";
		echo "<td>";
	
		
		$pull="select * from profile_image where uname='$uname'";
			$res = mysqli_query($con,$pull) or die(mysqli_error($con));
			
			//$res=$db->query($pull);
        $pics=$res->fetch_assoc();
         
			
		
echo "<img src='profile_pics/$pics[url]' width='200' height='200' class='doubleborder'/>";
//echo "<a href='profile_pics/pic$uname.png'><img src='profile_pics/pic$uname.png' height='200px' width='200px' /></a>";
	//echo "<a href='file_upload.php?uname=$uname'><img src='profile_pics/pic$uname.png' width='150px' width='150px'  /></a>";
	echo "</td>";
	/*echo "<td>&nbsp;Name:- ".$row["fname"]." ".$row["lname"]." </br>";
	echo "&nbsp;Gender:- ".$row["gender"]."</br>";*/


	//echo "</tr>";
	echo "<td style='text-align:right'>Name&nbsp;&nbsp;<br>Gender&nbsp;&nbsp;<br>DOB&nbsp;&nbsp;<br>Height&nbsp;&nbsp;<br>City&nbsp;&nbsp;<br>Manglik&nbsp;&nbsp;<br>Caste&nbsp;&nbsp;<br>Annual Income&nbsp;&nbsp;<br></td>";
	echo "<td style='text-align:left'>".$nm."<br>".$row["gender"]."<br>".$row["dob"]."<br>".$row["height"]."</br>".$row["city"]."</br>".$row["manglik"]."</br>".$row["caste"]."</br>".$row["annual_income"]."</br></td>";
	
    echo "<td ><a href='view_read_more.php?uname=$uname' class='btn active  btn-warning'>Read More</a></td>";
	
	echo "<td ><a href='send_message_to_member.php?uname=$uname&nm=$nm&fname=$fname&lname=$lname' class='btn btn-primary'>Send Message</a></td>";
	//echo $nm;
	echo "<td ><a href='del_member.php?uname=$uname&nm=$nm' class='btn active  btn-warning'>Delete User</a></td>";
	
		//echo "&nbsp;&nbsp;";
		//echo "&nbsp;<a href='edit_cat.php?uname=$uname' class='btn btn-primary'>Edit</a>";
		//echo "<td><a href='send_message_to_member.php? uname=$uname>Send Message</a>";
			
	
	//echo "</td>";
		//echo "<td>";

	//echo "&nbsp;<a href='del_member.php?m_uname=$m_uname&nm=$nm'>&nbsp;&nbsp;&nbsp;&nbsp;Remove</a></td>";
	echo "</tr>";
}

 
echo "</table>";
echo "</div>";

//echo "all executed";
echo "<br>";
echo "<p><a href='admin.php' class='btn btn-danger btn-block'>Back To Panel</a></p>";

echo "<center>";

mysqli_close($con);
include "footer.php";
?>
