<?php
include "header.php";
require "dbi.php";
?>
<style>
th,td{
	background-color:#FFEFD5;
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}

tr:hover{
	background-color:FloralWhite;
}
tr,th{
	background-color:ChartReuse;
}

table{
	background-color:#FFD700;
	width:95%;
}
img
{
	border-radius:50%;
	border: 5px solid navy;
}

</style>

<?php
//include "header.php";   // session started in header file - session_start();
//include "dbi.php";

$query_ = "select * from personal_information where uname='$uname'"; 
$query1_ = "select * from profile_details where uname='$uname'";
$query2_ = "select * from family_details where uname='$uname'";
$query3_ = "select * from astro_details where uname='$uname'";
$query4_ = "select * from education_and_career where uname='$uname'";
$query5_ = "select * from hobbies_and_traits where uname='$uname'"; 
$query6_ = "select * from about_myself where uname='$uname'";

$result_=mysqli_query($con,$query_);
$result1_=mysqli_query($con,$query1_);
$result2_=mysqli_query($con,$query2_);
$result3_=mysqli_query($con,$query3_);
$result4_=mysqli_query($con,$query4_);
$result5_=mysqli_query($con,$query5_);
$result6_=mysqli_query($con,$query6_);


//Personal Information

while($row=mysqli_fetch_array($result_))
{
	$uname=$row["uname"];
	$created_for=$row["created_for"];
	$fname = $row["fname"];
	$lname=$row["lname"];
	$e_email=$row["e_email"];
	$phone=$row["phone"];
	$dob=$row["dob"];
}
$query16="insert into temp_personal_information(uname,created_for,fname,lname,e_email,phone,dob) values('$uname','$created_for','$fname','$lname','$e_email','$phone','$dob')";
//Profile Details
while($row=mysqli_fetch_array($result1_))
{
$uname=$row["uname"];	
$gender=$row["gender"];
$marital_status=$row["marital_status"];
$height=$row["height"];
$caste=$row["caste"];
$sub_caste=$row["sub_caste"];
$gotra=$row["gotra"];
$diet=$row["diet"];
$smoke=$row["smoke"];

$personal_values=$row["personal_values"];
$complexion=$row["complexion"];
$body_type=$row["body_type"];
$special_cases=$row["special_cases"];
$residency_status=$row["residency_status"];
$language=$row["language"];
//$education_field=$row["education_field"];
$aadhar=$row["aadhar"];
$country=$row["country"];
$city=$row["city"];
$working_with=$row["working_with"];
$working_as=$row["working_as"];
$annual_income=$row["annual_income"];

$prefer_working_partner=$row["prefer_working_partner"];
}
$query26="insert into temp_profile_details (gender,uname,marital_status,height,caste,sub_caste,gotra,diet,smoke,personal_values,complexion,body_type,special_cases,residency_status,language,aadhar,country,city,working_with,working_as,annual_income,prefer_working_partner)values('$gender','$uname','$marital_status','$height','$caste','$sub_caste','$gotra','$diet','$smoke','$personal_values','$complexion','$body_type','$special_cases','$residency_status','$language','$aadhar','$country','$city','$working_with','$working_as','$annual_income','$prefer_working_partner')";


//Family Details
while($row=mysqli_fetch_array($result2_))
{
$family_values=$row["family_values"];
$fathers_status=$row["fathers_status"];
$mothers_status=$row["mothers_status"];
$no_of_brothers=$row["no_of_brothers"];
$no_of_sisters=$row["no_of_sisters"];
$native_place=$row["native_place"];
$family_description=$row["family_description"];
$body_weight=$row["body_weight"];
$blood_group=$row["blood_group"];
$primary_mobile_no=$row["primary_mobile_no"];
$secondary_mobile_no=$row["secondary_mobile_no"];
$address=$row["address"];
$f_city=$row["f_city"];
$state=$row["state"];
$f_country=$row["f_country"];
}
$query36="insert into temp_family_details(uname,family_values,fathers_status,mothers_status,no_of_brothers,no_of_sisters,native_place,family_description,body_weight,blood_group,primary_mobile_no,secondary_mobile_no,address,f_city,state,f_country) values('$uname','$family_values','$fathers_status','$mothers_status','$no_of_brothers','$no_of_sisters','$native_place','$family_description','$body_weight','$blood_group','$primary_mobile_no','$secondary_mobile_no','$address','$f_city','$state','$f_country')";

//Astro Details
while($row=mysqli_fetch_array($result3_))
{
$country_of_birth=$row["country_of_birth"];
$city_of_birth=$row["city_of_birth"];
$time_of_birth=$row["time_of_birth"];
$manglik=$row["manglik"];
$rashi=$row["rashi"];
$nakshatra=$row["nakshatra"];
$want_horoscope_match=$row["want_horoscope_match"];
}
$query46="insert into temp_astro_details(uname,country_of_birth,city_of_birth,time_of_birth,manglik,rashi,nakshatra,want_horoscope_match) values('$uname','$country_of_birth','$city_of_birth','$time_of_birth','$manglik','$rashi','$nakshatra','$want_horoscope_match')";


//Education and Career
while($row=mysqli_fetch_array($result4_))
{
		$e_educational_level=$row["e_educational_level"];
$e_educational_field=$row["e_educational_field"];
$e_annual_income=$row["e_annual_income"];
$e_family_status=$row["e_family_status"];
}
$query56="insert into temp_education_and_career(uname,e_educational_level,e_educational_field,e_annual_income,e_family_status) values('$uname','$e_educational_level','$e_educational_field','$e_annual_income','$e_family_status')";

//Hobbies and Traits
while($row=mysqli_fetch_array($result5_))
{
$h_describe=$row["h_describe"];
$h_activities=$row["h_activities"];
}
$query66="insert into temp_hobbies_and_traits(uname,h_describe,h_activities) values('$uname','$h_describe','$h_activities')";
/*about_myself*/

while($row=mysqli_fetch_array($result6_))
{
	$about_self=$row["about_self"];
//echo $about_self."df";	
}


$query76="insert into temp_about_myself(uname,about_self) values('$uname','$about_self')";

mysqli_query($con,$query16) or die(mysqli_error($con));
mysqli_query($con,$query26) or die(mysqli_error($con));
mysqli_query($con,$query36) or die(mysqli_error($con));
mysqli_query($con,$query46) or die(mysqli_error($con));
mysqli_query($con,$query56) or die(mysqli_error($con));
mysqli_query($con,$query66) or die(mysqli_error($con));
mysqli_query($con,$query76) or die(mysqli_error($con));

 ?>






<?php
//include "header.php";   // session started in header file - session_start();
//include "dbi.php";

$delete_for=$_POST["delete_for"];


    $query1="delete from login where uname='$uname'";
    $query2 = "delete from personal_information where uname='$uname'";
	$query3 = "delete from profile_details where uname='$uname'";
	$query4 = "delete from family_details where uname='$uname'";
	$query5 = "delete from astro_details where uname='$uname'";
	$query6 = "delete from education_and_career where uname='$uname'";
	$query7 = "delete from hobbies_and_traits where uname='$uname'";
	$query8 = "delete from about_myself where uname='$uname'";
		//$query9 = "delete from interest where uname='$uname'";
		
	

	

	mysqli_query($con,$query1) or die(mysqli_error($con));
	mysqli_query($con,$query2) or die(mysqli_error($con));
	mysqli_query($con,$query3) or die(mysqli_error($con));
	mysqli_query($con,$query4) or die(mysqli_error($con));
	mysqli_query($con,$query5) or die(mysqli_error($con));
	mysqli_query($con,$query6) or die(mysqli_error($con));
	mysqli_query($con,$query7) or die(mysqli_error($con));
	mysqli_query($con,$query8) or die(mysqli_error($con));
	//mysqli_query($con,$query9) or die(mysqli_error($con));
	
	
	
	
	
mysqli_query($con,"update delete_profile set delete_for='$delete_for' where uname='$uname' ")or die(mysqli_error($con));

if($delete_for=='Found My Partner From ReshimGathi')
{
if(mysqli_affected_rows($con) > 0)
{
	//$query="select * from delete_profile where (delete_for <> 'Found My Partner From ReshimGathi' and uname='$uname')";	
//$result=mysqli_query($con,$query);
echo "<div class='well text-center'><h2 style='color:green'>Success: Your Profile Deleted!</h2>";
echo "<a href='share_story.php'><div class='well text-center'><h2 style='color:navy'> Share Your Story Here....</h2></a>";

	echo "<p><a href='login.php'>Back To Panel</a></p></div>";
}
}
else
{
	echo "<div class='well text-center'><h2 style='color:green'>Your Profile Deleted!</h2>";
}

include "footer.php";
?>