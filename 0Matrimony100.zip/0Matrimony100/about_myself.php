<?php
include "header.php";
require "dbi.php";
?>
<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
}

table{
	width:95%;
}


</style>

<body>

<?php 
//include "header.php"; 
//include "validate_member.php";

?>
<form action="update_about_myself.php" method="post">

<div class='table-responsive' >
<table border='0'>

  <th>
  <!--
    <br>
  <font color="navy">
<b><h4><a href="personal_information.php" id="aa"  class='btn active  btn-primary'   style="background-color:crimson";><span></span>
	<span></span><span></span><span></span>01 Personal Information&nbsp;
	</a></h4></b>
	<br>
	<h4><a href="profile_details.php" id="aa" class='btn active  btn-primary' style="background-color:crimson">02 Profile Details
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		
	<h4><a href="family_details.php" id="aa" class='btn active  btn-primary'style="background-color:crimson">03 Family Details
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
	
	<h4><a href="astro_details.php" id="aa" class='btn active  btn-primary'style="background-color:crimson">04 Astro Details
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>

	<h4><a href="education_and_career.php" id="aa" class='btn active  btn-primary'style="background-color:crimson">05 Education And Career</a></h4><br>

	<h4><a href="hobbies_and_traits.php" id="aa" class='btn active  btn-primary'style="background-color:crimson">06 Hobbies and Traits
	&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		<h4><a href="about_myself.php" id="aa" class='btn active  btn-primary'style="background-color:pink"><font color="navy"> 07 About Myself</font>
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		
		<h4><a href="expectation.php" id="aa" class='btn active  btn-primary'style="background-color:crimson"> 08 My Expectations
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		
		<h4> <a href="upload_photo.php"id="aa" class='btn active  btn-primary'style="background-color:crimson">09 Upload Profile Photo&nbsp;&nbsp;</a></h4><br>
    
	</font>
	
	
  </div></th><th>
  -->
  		<?php
//include "dbi.php";

if(!empty($uname))
{
	$result = mysqli_query($con,"select * from about_myself where uname='$uname'");

	if($row=mysqli_fetch_array($result))
	{
		
$about_self=$row["about_self"];
//$h_activities=$row["h_activities"];

	}
	else
	{
		$about_self="";
	}

}


?>
  

 <!--   <h2>Column 2</h2>
    <p>Some text..</p>-->
	
	<div class="wizard-header">
<h2>
			            	
			            	<span class="step-text">About Myself</span>
			            </h2>
			                	<div class="wizard-header">
									<h3 class="heading">About Myself</h3>
									<p>Please enter your infomation and proceed to the next step so we can build your accounts.</p>
								</div>
								<div class="form-row">
			                		About Myself:<br><br>
										
										
   <textarea rows = "7" cols = "50" name = "about_self" style="text-align:left-side;">&nbsp;&nbsp
        
         </textarea>
		 
		 <br>
                <br>                        
             
			                	</div>
							</div>		 <br>
							<a href=' personal_information.php' class='btn active  btn-primary' style='background-color:green';>Previous</font></a>
&nbsp;&nbsp;&nbsp;

<input type="submit" name="submit"  class='btn active  btn-danger' value="Save and Next"  style="background-color:blue;"/>
		 
		 <!--<input type="submit" name="submit" value="Save and Next"  style="background-color:#2eb82e;"/>-->
  </div>
</div></th>
</form>
</body>
</html>
