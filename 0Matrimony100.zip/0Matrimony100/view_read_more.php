<?php
include "header.php";
require "dbi.php";
?>
<style>
th,td{
	background-color:#FFEFD5;
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}

tr:hover{
	background-color:FloralWhite;
}
tr,th{
	background-color:ChartReuse;
}

table{
	background-color:#FFD700;
	width:95%;
}
img
{
	border-radius:50%;
	border: 5px solid navy;
}

</style>

<?php
//include "header.php";   // require "header.php";
//include "dbi.php";
$uname=$_GET["uname"];
//$sid=$_GET["sid"];

$query = "select * from personal_information where uname='$uname'"; 
$query1 = "select * from profile_details where uname='$uname'";
$query2 = "select * from family_details where uname='$uname'";
$query3 = "select * from astro_details where uname='$uname'";
$query4 = "select * from education_and_career where uname='$uname'";
$query5 = "select * from hobbies_and_traits where uname='$uname'"; 
$query6 = "select * from about_myself where uname='$uname'";
//$query = "select * from personal_information where uname='$uname'";



//$skill=strtoupper($skill);
$result=mysqli_query($con,$query);
$result1=mysqli_query($con,$query1);
$result2=mysqli_query($con,$query2);
$result3=mysqli_query($con,$query3);
$result4=mysqli_query($con,$query4);
$result5=mysqli_query($con,$query5);
$result6=mysqli_query($con,$query6);

//echo "<p><center><a href='view_matches.php'> Back </a></center></p>";
//echo "<h2 class='text-center'>$uname</h2>";
$pull="select * from profile_image where uname='$uname'";
			$res = mysqli_query($con,$pull) or die(mysqli_error($con));
			
			//$res=$db->query($pull);
$pics=$res->fetch_assoc();
	
				//echo "<td>";
				echo "<center><img src='profile_pics/$pics[url]' height='200px' width='200px' /><center>";
		
	
			//echo "</td>";
 
	//echo "<center><a href='/pic$uname.png'><img src='profile_pics/pic$uname.png' height='250px' width='230px' /></a></center>";

	echo "<center><a href='view_gallery.php?uname=$uname'><h3>Click Here to View Gallery</h3></a></center>";
echo "<br>";
//echo "<br>";
echo "<center>";
echo '<div class="table-responsive">';
echo '<table border>';
echo "<tr bgcolor='ChartReuse'><th><center>Personal Details</center></th>";
echo "<th><center>Profile Details</center></th></tr>";
//echo "<th><center>.....</center></th>";

//$cnt=0;
/*personal_information*/

while($row=mysqli_fetch_array($result))
{
	//$cnt++;
	$uname=$row["uname"];
	$nm = $row["fname"]." ".$row["lname"];
	$e_email=$row["e_email"];
	$dob=$row["dob"];




	echo "<tr>";
	
	//echo "<td>".$cnt."</td>";
	echo "<td>Name:-&nbsp;&nbsp;".$nm."<br><br>";
	echo "Email:-&nbsp;&nbsp;".$row["e_email"]."<br><br>";
	echo "DOB:-&nbsp;&nbsp;".$row["dob"]."<br><br></td>";
	
	//echo "<td>&nbsp;<a href='assign_work.php?sid=$sid&nm=$nm&skill=$skill&w_nm=$w_uname'>Assign Work</a></td>";
//echo "$w_uname";
	//echo "</tr>";
	
}

/*profile_details*/
while($row=mysqli_fetch_array($result1))
{
	//$cnt++;
	//$uname=$row["uname"];
	//$nm = $row["fname"]." ".$row["lname"];
	
$gender=$row["gender"];
$marital_status=$row["marital_status"];
$height=$row["height"];
$caste=$row["caste"];
$sub_caste=$row["sub_caste"];
$gotra=$row["gotra"];
$diet=$row["diet"];
$smoke=$row["smoke"];

$personal_values=$row["personal_values"];
$complexion=$row["complexion"];
$body_type=$row["body_type"];
$special_cases=$row["special_cases"];
$residency_status=$row["residency_status"];
$language=$row["language"];
//$education_field=$row["education_field"];
$country=$row["country"];
$city=$row["city"];
$working_with=$row["working_with"];
$working_as=$row["working_as"];
$annual_income=$row["annual_income"];

$prefer_working_partner=$row["prefer_working_partner"];




	//echo "<tr>";
	
	//echo "<td>".$cnt."</td>";
	//echo "<td>Name:-&nbsp;&nbsp;".$nm."<br><br>";
	
	echo "<td> <br><br> Gender:-&nbsp;&nbsp;".$row["gender"]."<br><br>";
	echo "Marital Status:-&nbsp;&nbsp;".$row["marital_status"]."<br><br>";
	echo "Height:-&nbsp;&nbsp;".$row["height"]."<br><br>";
	echo "Caste:-&nbsp;&nbsp;".$row["caste"]."<br><br>";
	echo "Sub Caste:-&nbsp;&nbsp;".$row["sub_caste"]."<br><br>";
	echo "Gotra:-&nbsp;&nbsp;".$row["gotra"]."<br><br>";
	echo "Diet:-&nbsp;&nbsp;".$row["diet"]."<br><br>";
	echo "Smoke:-&nbsp;&nbsp;".$row["smoke"]."<br><br>";
	echo "Personal Values:-&nbsp;&nbsp;".$row["personal_values"]."<br><br>";
	echo "Body Type:-&nbsp;&nbsp;".$row["body_type"]."<br><br>";
	echo "Special Cases:-&nbsp;&nbsp;".$row["special_cases"]."<br><br>";
	echo "Residency Status:-&nbsp;&nbsp;".$row["residency_status"]."<br><br>";
	echo "Languages Known:-&nbsp;&nbsp;".$row["language"]."<br><br>";
	//echo "Eduacational Field:-&nbsp;&nbsp;".$row["education_field"]."<br><br>";
	echo "Country:-&nbsp;&nbsp;".$row["country"]."<br><br>";
	echo "City:-&nbsp;&nbsp;".$row["city"]."<br><br>";
	echo "Working With:-&nbsp;&nbsp;".$row["working_with"]."<br><br>";
	echo "working As:-&nbsp;&nbsp;".$row["working_as"]."<br><br>";
	echo "Annual Income:-&nbsp;&nbsp;".$row["annual_income"]."<br><br>";
	echo "Prfer Working Partner:-&nbsp;&nbsp;".$row["prefer_working_partner"]."<br><br></td>";
	
	//echo "<td>&nbsp;<a href='assign_work.php?sid=$sid&nm=$nm&skill=$skill&w_nm=$w_uname'>Assign Work</a></td>";
//echo "$w_uname";
	echo "</tr>";
	
	
}


echo "</table></div>";


echo "</center>";


echo "<br>";

echo "<center>";




echo '<div class="table-responsive">';
echo '<table border>';
echo "<tr bgcolor='ChartReuse'><th><center>Family Details</center></th>";
echo "<th><center>Astro Details</center></th></tr>";
//echo "<th><center>.....</center></th>";

//$cnt=0;
/*family_details*/
while($row=mysqli_fetch_array($result2))
{
	//$cnt++;
	$family_values=$row["family_values"];
$fathers_status=$row["fathers_status"];
$mothers_status=$row["mothers_status"];
$no_of_brothers=$row["no_of_brothers"];
$no_of_sisters=$row["no_of_sisters"];
$native_place=$row["native_place"];
$family_description=$row["family_description"];
$body_weight=$row["body_weight"];
$blood_group=$row["blood_group"];
$primary_mobile_no=$row["primary_mobile_no"];
$secondary_mobile_no=$row["secondary_mobile_no"];
$address=$row["address"];
$f_city=$row["f_city"];
$state=$row["state"];
$f_country=$row["f_country"];
	echo "<tr>";
	//echo "<td>".$cnt."</td>";
	//echo "<td>Name:-&nbsp;&nbsp;".$nm."<br><br>";
	echo "<td><br><br>Family Values:-&nbsp;&nbsp;".$row["family_values"]."<br><br>";
	echo "Fathers Status:-&nbsp;&nbsp;".$row["fathers_status"]."<br><br>";
	echo "Mothers Status:-&nbsp;&nbsp;".$row["mothers_status"]."<br><br>";
	echo "No.Of Brothers:-&nbsp;&nbsp;".$row["no_of_brothers"]."<br><br>";
	echo "No.Of Sisters:-&nbsp;&nbsp;".$row["no_of_sisters"]."<br><br>";
	echo "native Place:-&nbsp;&nbsp;".$row["native_place"]."<br><br>";
	echo "Family Description:-&nbsp;&nbsp;".$row["family_description"]."<br><br>";
	echo "Body Weight:-&nbsp;&nbsp;".$row["body_weight"]."<br><br>";
	echo "Blood Group:-&nbsp;&nbsp;".$row["blood_group"]."<br><br>";
	//echo "Primary Mob No:-&nbsp;&nbsp;".$row["primary_mobile_no"]."<br><br>";
	//echo "Secondary Mob No:-&nbsp;&nbsp;".$row["secondary_mobile_no"]."<br><br>";
	echo "Address:-&nbsp;&nbsp;".$row["address"]."<br><br>";
	echo "City:-&nbsp;&nbsp;".$row["f_city"]."<br><br>";
	echo "State:-&nbsp;&nbsp;".$row["state"]."<br><br>";
	echo "Country:-&nbsp;&nbsp;".$row["f_country"]."<br><br></td>";
	
	//echo "<td>&nbsp;<a href='assign_work.php?sid=$sid&nm=$nm&skill=$skill&w_nm=$w_uname'>Assign Work</a></td>";
//echo "$w_uname";
	//echo "</tr>";
	
}

/*astro_details*/
while($row=mysqli_fetch_array($result3))
{
	//$nm = $row["fname"]." ".$row["lname"];
	$country_of_birth=$row["country_of_birth"];
$city_of_birth=$row["city_of_birth"];
$time_of_birth=$row["time_of_birth"];
$manglik=$row["manglik"];
$rashi=$row["rashi"];
$nakshatra=$row["nakshatra"];
$want_horoscope_match=$row["want_horoscope_match"];



	//echo "<tr>";
	
	//echo "<td>".$cnt."</td>";
	//echo "<td>Name:-&nbsp;&nbsp;".$nm."<br><br>";
	echo "<td>Country Of Birth:-&nbsp;&nbsp;".$row["country_of_birth"]."<br><br>";
	echo "City Of Birth:-&nbsp;&nbsp;".$row["city_of_birth"]."<br><br>";
	echo "Time Of Birth:-&nbsp;&nbsp;".$row["time_of_birth"]."<br><br>";
	echo "Manglik:-&nbsp;&nbsp;".$row["manglik"]."<br><br>";
	echo "Rashi:-&nbsp;&nbsp;".$row["rashi"]."<br><br>";
	echo "Nakshatra:-&nbsp;&nbsp;".$row["nakshatra"]."<br><br>";
	echo "I Want Horoscope Match:-&nbsp;&nbsp;".$row["want_horoscope_match"]."<br><br></td>";
	
	//echo "<td>&nbsp;<a href='assign_work.php?sid=$sid&nm=$nm&skill=$skill&w_nm=$w_uname'>Assign Work</a></td>";
//echo "$w_uname";
	echo "</tr>";
	
	
}


echo "</table></div>";

echo "</center>";
echo "<br>";
echo "<center>";

echo '<div class="table-responsive">';
echo '<table border>';
echo "<tr bgcolor='ChartReuse'><th><center>Education And Career</center></th>";
echo "<th><center>Hobbies and Traits</center></th></tr>";
//echo "<th><center>.....</center></th>";

//$cnt=0;
/*education_and_career*/
while($row=mysqli_fetch_array($result4))
{

	$e_educational_level=$row["e_educational_level"];
$e_educational_field=$row["e_educational_field"];
$e_annual_income=$row["e_annual_income"];
$e_family_status=$row["e_family_status"];

	echo "<td><br><br>Educational Level:-&nbsp;&nbsp;".$row["e_educational_level"]."<br><br>";
	echo "Educational Field:-&nbsp;&nbsp;".$row["e_educational_field"]."<br><br>";
	echo "Annual Income:-&nbsp;&nbsp;".$row["e_annual_income"]."<br><br>";
	echo "Family Status:-&nbsp;&nbsp;".$row["e_family_status"]."<br><br></td>";
	
	//echo "<td>&nbsp;<a href='assign_work.php?sid=$sid&nm=$nm&skill=$skill&w_nm=$w_uname'>Assign Work</a></td>";
//echo "$w_uname";
	//echo "</tr>";
	
	
}

/*hobbies_and_traits*/
while($row=mysqli_fetch_array($result5))
{
	//$cnt++;
	//$uname=$row["uname"];
	//$nm = $row["fname"]." ".$row["lname"];
	$h_describe=$row["h_describe"];
	$h_activities=$row["h_activities"];




	//echo "<tr>";
	
	//echo "<td>".$cnt."</td>";
	//echo "<td>Name:-&nbsp;&nbsp;".$nm."<br><br>";
	echo "<td>Description:-&nbsp;&nbsp;".$row["h_describe"]."<br><br>";
	echo "About Like are:-&nbsp;&nbsp;".$row["h_activities"]."<br><br></td>";
	
	//echo "<td>&nbsp;<a href='assign_work.php?sid=$sid&nm=$nm&skill=$skill&w_nm=$w_uname'>Assign Work</a></td>";
//echo "$w_uname";
	echo "</tr>";
	
	
}


echo "</table></div>";

echo "</center>";
echo "<center>";
echo "<br>";


echo '<div class="table-responsive">';
echo '<table border>';
echo "<tr bgcolor='ChartReuse'><th><center>About Myself</center></th></tr>";
//echo "<th><center>Photo</center></th></tr>";
//echo "<th><center>.....</center></th>";

//$cnt=0;
/*about_myself*/

while($row=mysqli_fetch_array($result6))
{
	$about_self=$row["about_self"];

	echo "<td><br><br>&nbsp;&nbsp;".$row["about_self"]."<br><br></td>";
	//echo "About Like are:-&nbsp;&nbsp;".$row["h_activities"]."<br><br></td>";
	
	//echo "<td>&nbsp;<a href='assign_work.php?sid=$sid&nm=$nm&skill=$skill&w_nm=$w_uname'>Assign Work</a></td>";
//echo "$w_uname";
	echo "</tr>";
	
	
}


echo "</table></div>";
echo "</center>";
echo "<br>";


 ?>


 
 <?php
include "footer.php";   // require "header.php";
 ?>