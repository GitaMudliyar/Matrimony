<?php
include "header.php";
require "dbi.php";
?>
<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
}

table{
	width:95%;
}

</style>

<script type="text/javascript">

	
	function changeDropdown()
{
	var country=document.getElementById("mySelect").value;
	if(country=="India")
	{
		document.getElementById("state").style.visibility="visible";
	 document.getElementById("txtOther").style.visibility="hidden";
	}
	 else 
	{
		document.getElementById("txtOther").style.visibility="visible";
		document.getElementById("state").style.visibility="hidden";
	}
}
	
	
</script>


</head>

<head>
	<meta charset="utf-8">
	<!-- Mobile Specific Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!-- Font-->
	<link rel="stylesheet" type="text/css" href="css/opensans-font.css">
	<link rel="stylesheet" type="text/css" href="fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">
	<!-- Main Style Css -->
    <link rel="stylesheet" href="css/style.css"/>
</head>
<body>

<?php 
//include "header.php"; 
//include "validate_member.php";

?>
<form action="update_family_details.php" method="post">
<div class='table-responsive' >
<table border='0'>

<th><!--
  <font color="navy">
<b><h4><a href="personal_information.php" id="aa"  class='btn active  btn-primary'   style="background-color:crimson";><span></span>
	<span></span><span></span><span></span>01 Personal Information&nbsp;
	</a></h4></b>
	<br>
	<h4><a href="profile_details.php" id="aa" class='btn active  btn-primary' style="background-color:crimson">02 Profile Details
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		
	<h4><a href="family_details.php" id="aa" class='btn active  btn-primary'style="background-color:pink"><font color="navy">03 Family Details</font>
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
	
	<h4><a href="astro_details.php" id="aa" class='btn active  btn-primary'style="background-color:crimson">04 Astro Details
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>

	<h4><a href="education_and_career.php" id="aa" class='btn active  btn-primary'style="background-color:crimson">05 Education And Career</a></h4><br>

	<h4><a href="hobbies_and_traits.php" id="aa" class='btn active  btn-primary'style="background-color:crimson">06 Hobbies and Traits
	&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		<h4><a href="about_myself.php" id="aa" class='btn active  btn-primary'style="background-color:crimson"> 07 About Myself
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		
		<h4><a href="expectation.php" id="aa" class='btn active  btn-primary'style="background-color:crimson"> 08 My Expectations
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		
		<h4> <a href="upload_photo.php"id="aa" class='btn active  btn-primary'style="background-color:crimson">09 Upload Profile Photo&nbsp;&nbsp;</a></h4><br>
    
	</font>
    

  </th><th>-->
  
  		<?php
//include "dbi.php";

if(!empty($uname))
{
	$result = mysqli_query($con,"select * from family_details where uname='$uname'");

	if($row=mysqli_fetch_array($result))
	{
	
//$about_self=$row["about_self"];
//$h_activities=$row["h_activities"];

$family_values=$row["family_values"];
$fathers_status=$row["fathers_status"];
$mothers_status=$row["mothers_status"];
$no_of_brothers=$row["no_of_brothers"];
$no_of_sisters=$row["no_of_sisters"];
$native_place=$row["native_place"];
$family_description=$row["family_description"];
$body_weight=$row["body_weight"];
$blood_group=$row["blood_group"];
$primary_mobile_no=$row["primary_mobile_no"];
$secondary_mobile_no=$row["secondary_mobile_no"];
$address=$row["address"];
$f_city=$row["f_city"];
$state=$row["state"];
$f_country=$row["f_country"];







	}
	else
	{
		//$about_self="";
		
$family_values="";
$fathers_status="";
$mothers_status="";
$no_of_brothers="";
$no_of_sisters="";
$native_place="";
$family_description="";
$body_weight="";
$blood_group="";
$primary_mobile_no="";
$secondary_mobile_no="";
$address="";
$f_city="";
$state="";
$f_country="";	
		
		
	}

}


?>
  
  <div class="column">
 <!--   <h2>Column 2</h2>
    <p>Some text..</p>-->
	
	<div class="wizard-header">
									<h3 class="heading"><b>Family Details</b></h3>
									<p>Please enter your infomation and proceed to the next step so we can build your accounts.</p>
								</div>
								
								<div class="form-row">
									<div class="form-holder form-holder-2">
										
											<legend>Family Values:</legend>
											<select name="family_values" class="form-control text">
											<option value="Select">SELECT</option>
											
											<option value="Traditional">Traditional</option>
											
											 <option value="Moderate">Moderate</option>
	                                 <option value="Liberal">Liberal</option>
	                                  </select>
									  
									  </div>
									  </div>
									  
									  
									  <div class="form-row">
									<div class="form-holder form-holder-2">
										
											<legend>Fathers Status:</legend>
											<select name="fathers_status" class="form-control text">
											
											<option value="Select">SELECT</option>
											
	                                        <option value="Employed">Employed</option>
	                                        <option value="Business">Business</option>
											<option value="Professional">Professional</option>
	                                        <option value="Retired">Retired</option>
											<option value="Not Employed">Not Employed</option>
											<option value="Passed Away">Passed Away</option>
	                                       
	                                        </select>
									
									  </div>
									 
									  
									  
									  
									<div class="form-holder form-holder-2">
									
											<legend>Mothers Status:</legend>
											<select name="mothers_status" class="form-control text">
											
											<option value="Select">SELECT</option>
											
	                                        <option value="Homemakers">Homemaker</option>
	                                        <option value="Employed">Employed</option>
											<option value="Business">Business</option>
	                                        <option value="Professional">Professional</option>
											<option value="Retired">Retired</option>
											<option value="Passed Away">Passed Away</option>
	                                       
	                                        </select>
											
											</div>
											</div>
											
											
											<div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>No Of Brothers:</legend>
											<input type="text" class="form-control" value="<?php echo $no_of_brothers;?>" id="brothers" name="no_of_brothers" placeholder="NO OF BROTHERS" required>
										</fieldset>
									</div>
								
								
								
								
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>No Of Sisters:</legend>
											<input type="text" class="form-control" value="<?php echo $no_of_sisters;?>" id="no_of_sisters" name="no_of_sisters" placeholder="NO OF SISTERS" required>
										</fieldset>
									</div>
								</div>
								

								<div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>Native Place:</legend>
											<input type="text" class="form-control" id="Place" value="<?php echo $native_place;?>" name="native_place" placeholder="ENTER PLACE NAME"  style='text-transform:uppercase' required>
										</fieldset>
									</div>
								</div>
								
									  <div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>Family Description:</legend>
											<input type="text" class="form-control" id="FD" value="<?php echo $family_description;?>" name="family_description" placeholder="ENTER FAMILY DESCRIPTION"  style='text-transform:uppercase' required>
										</fieldset>
									</div>
								</div>
								
								
								 <div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>Weight in Kg:</legend>
											<input type="text" class="form-control" id="Place" value="<?php echo $body_weight;?>" name="body_weight" placeholder="Enter Body Weight" required>
										</fieldset>
									</div>
								
								
								
								 <div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>Blood Group:</legend>
											<!--<input type="text" class="form-control" id="Place" name="blood_group" placeholder="Enter Blood Group" required>-->
											 <select name="blood_group" class="form-control text">
			                       <option value="">Blood Group</option>
	                               
	<option value="A+ ve">A +ve</option>
	<option value="A- ve">A -ve</option>
	<option value="B+ ve">B +ve</option>
	<option value="B- ve">B -ve</option>
	<option value="O+ ve">O +ve</option>
	<option value="O- ve">O -ve</option>
	<option value="AB+ ve">AB +ve</option>
	<option value="AB- ve">AB -ve</option>
	<option value="Bombay Blood Group">Bombay Blood Group</option>
	
	
	
	
	
</select>
										</fieldset>
									</div>
								</div>
								
								
								</div> 
								
								
								 <div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>Primary Mobile Number:</legend>
											<input type="tel" id="phone" value="<?php echo $primary_mobile_no;?>" name="primary_mobile_no" placeholder="1234567890" pattern="[0-9]{3}[0-9]{2}[0-9]{3}[0-9]{2}" class="form-control" required><br>
										</fieldset>
									</div>
								
								
								
								
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>Secondary Mobile Number:</legend>
											<input type="tel" id="phone" name="secondary_mobile_no" value="<?php echo $secondary_mobile_no;?>" placeholder="1234567890" pattern="[0-9]{3}[0-9]{2}[0-9]{3}[0-9]{2}" class="form-control" required><br>
										</fieldset>
									</div>
								</div>
								
								
								
								
								
								
								<div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>Address:</legend>
											<address><input type="text" class="form-control" value="<?php echo $address;?>" id="Place" name="address" placeholder="ENTER ADDRESS"  style='text-transform:uppercase' required></address>
										</fieldset>
									</div>
								
								
								
								<div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>City:</legend>
											<input type="text" class="form-control" id="Place" value="<?php echo $f_city;?>" name="f_city" placeholder="ENTER CITY"  style='text-transform:uppercase' required>
										</fieldset>
									</div>
								</div>
								</div>
								
								
								
								
								<div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>Country:</legend>
											<select id = "mySelect" name="f_country" onchange = "changeDropdown(this.value);">

											
											<option value="Select">Select</option>
											<option value="India">India</option>
										 
	                                        <option value="other">Other</option>
											</select>
										</fieldset>
									</div>
									
									
									<div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>State/UT:</legend>
											<!--<input type="text" class="form-control" id="state" name="state" placeholder="Enter State" required>-->
											<select id = "state" name="state" onchange = "changeDropdown(this.value);">

											
											<option value="Select">Select</option>
											<option value="Andhra Pradesh">Andhra Pradesh</option>
											<option value="Arunachal Pradesh">Arunachal Pradesh</option>
											<option value="Asom(Assam)">Asom(Assam)</option>
											<option value="Bihar">Bihar</option>
											<option value="Karnataka">Karnataka</option>
											<option value="Kerala">Kerala</option>
											<option value="Chhattisgarh">Chhattisgarh</option>
											<option value="Uttar Pradesh">Uttar Pradesh</option>
											<option value="Goa">Goa</option>
											<option value="Gujarat">Gujarat</option>
											<option value="Haryana">Haryana</option>
											<option value="Himachal Pradesh">Himachal Pradesh</option>
											<option value="Jammu and Kashmir">Jammu and Kashmir</option>
											<option value="Jharkhand">Jharkhand</option>
											<option value="West Bengal">West Bengal</option>
											<option value="Madhya Pradesh">Madhya Pradesh</option>
											<option value="Maharashtra">Maharashtra</option>
											<option value="Manipur">Manipur</option>
											<option value="Meghalay">Meghalay</option>
											<option value="Mizoram">Mizoram</option>
											<option value="Nagaland">Nagaland</option>
											<option value="Orissa">Orissa</option>
											<option value="Punjab">Punjab</option>
											<option value="Rajasthan">Rajasthan</option>
											<option value="Sikkim">Sikkim</option>
											<option value="Tamil-Nadu">Tamil-Nadu</option>
											<option value="Telangana">Telangana</option>
										    <option value="Uttarakhand/Uttaranchal">Uttarakhand/Uttaranchal</option>
											<option value="Andaman and Nicobar">Andaman and Nicobar</option>
											<option value="Pondicherry">Pondicherry</option>
											<option value="Dadar and Nagar Haveli">Dadar and Nagar Haveli</option>
											<option value="Delhi">Delhi</option>
											<option value="Chandigarh">Chandigarh</option>
											<option value="Lakshadweep">Lakshadweep</option>
											
											</select>
											
										</fieldset>
									</div>
								</div>

<input type="text" id="txtOther"  />
<br><br>
									
									<br>
									
									<a href=' personal_information.php' class='btn active  btn-primary' style='background-color:green';>Previous</font></a>
&nbsp;&nbsp;&nbsp;

<input type="submit" name="submit"  class='btn active  btn-danger' value="Save and Next"  style="background-color:blue;"/>
									
									<!--<input type="submit" name="submit" value="Save and Next"  style="background-color:#2eb82e;"/>-->
									
	 </div>
</div></th>
</form>
</body>
</html>