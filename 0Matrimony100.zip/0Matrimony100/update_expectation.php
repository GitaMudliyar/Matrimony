<?php
include "header.php";
require "dbi.php";


//$eid=$_POST["eid"];
//$uname=$_POST["uname"];
$marital_status=$_POST["marital_status"];
$inch=$_POST["inch"];
$feet=$_POST["feet"];

$height=$inch.$feet;
$caste=$_POST["caste"];
$gotra=$_POST["gotra"];
$city=$_POST["city"];
$manglik=$_POST["manglik"];
$rashi=$_POST["rashi"];
$nakshatra=$_POST["nakshatra"];
$e_educational_level=$_POST["e_educational_level"];
$e_educational_field=$_POST["e_educational_field"];
//$name=$fname+$lname;

mysqli_query($con,"update expectation set marital_status='$marital_status',height='$height',caste='$caste',gotra='$gotra',city='$city',manglik='$manglik',rashi='$rashi',nakshatra='$nakshatra',e_educational_level='$e_educational_level',e_educational_field='$e_educational_field' where uname='$uname'") or die(mysqli_error($con));
if(mysqli_affected_rows($con) > 0)
{
	//echo "<div class='well text-center'><h2 style='color:green'>Success: Photo Updated!</h2>";
	//echo "<p><a href='upload_photo.php'>Back To Panel</a></p></div>";
	header("location:upload_photo.php");	
	//echo"success";
	
}
else
	
	{
		echo "fail";
	}
//include "footer.php";
?>
