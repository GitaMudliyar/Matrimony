<?php
include "header.php";
?>
<style>
body{
	background-image: url("images/nb.jpg");
	 background-size: cover;
}

</style>
<body>
<div class="panel panel-primary" style="max-width:300px;margin:auto">
		<div class="panel-heading">
			Forgot Your Password?
		</div>

		<div class="panel-body panel-center">
	<!--	<form class="form" action="act_forgot_password.php" method="post">
	-->	
	<form class="form" action="act_forgot_password.php" method="post">

<div class="form-group">
<label for="nameField">User Name</label>
<input type="text" class="form-control input-sm" name="uname" required placeholder="Enter User Name" />
</div>
<!--
<div class="form-group">
<label for="emailField">Date Of Birth</label>
<input type="date" class="form-control" name="dob" required placeholder=" Enter date of birth" />
</div>-->
<div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>Phone Number</legend>
<!--<input type="number" class="form-control" id="phone" maxLength="10" name="phone" value="<?php //echo $phone;   ?>" placeholder="+1 888-999-7777" required>-->


<input type="tel" id="phone" name="phone" placeholder="9876543210" pattern="[0-9]{3}[0-9]{2}[0-9]{3}[0-9]{2}" class="form-control" required><br>
	
</fieldset>
										</fieldset>
									</div>
								</div>


<div class="form-group">
<label for="emailField">Email</label>
<input type="email" class="form-control" name="e_email" required placeholder="Enter Email here" required>
</div>

<input type="submit" class="btn btn-primary btn-block" value="Change Password" /> 

</form>
		</div>
		<div class="panel-footer text-center">
		
		<a href="registration.php">Create  an Account</a><br>
		<a href="login.php">Already have an account?Login here..</a><br>
		<a href="index.php">Cancel</a>
		</div>

		<!--<div class="panel-footer text-center">-->
		
<!--<a href="registration.php"> Create  an Account</a>	<br>		
<a href="login.php">Already have an account?Login here.. </a><br>
<a href="index.php"> Cancel</a>-->	

		

	</div>

</body>
<?php
include "footer.php";
?>




