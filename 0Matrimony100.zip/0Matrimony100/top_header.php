
<p style="color:blue;text-align:right;">
<a href="https://accounts.google.com/ServiceLogin/signinchooser?service=mail&passive=true&rm=false&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&ss=1&scc=1&ltmpl=default&ltmplcache=2&emr=1&osid=1&flowName=GlifWebSignIn&flowEntry=AddSession">
<img style="border-radius:50%; border: 2px solid hotpink;" src="images/icon_gmail.png" height="50px" width="50px"/></a>

<a href="https://www.facebook.com/">
<img style="border-radius:50%; border: 2px solid hotpink;" src="images/icon_facebook.png" height="50px" width="50px"/></a>
<a href="https://twitter.com/login?lang=en-gb">
<img style="border-radius:50%; border: 2px solid hotpink;" src="images/icon_twitter.png" height="50px" width="50px"/></a>
</p>
