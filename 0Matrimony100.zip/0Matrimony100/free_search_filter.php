<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
* {
  box-sizing: border-box;
}

/* Create two equal columns that floats next to each other */
.column1 {
  float: left;
  width: 48%;
  padding: 10px;
  padding-left:30px;
  height: 800px; /* Should be removed. Only for demonstration Numbers*/
}
.column {
  float: left;
  width: 48%;
  padding: 10px;
  padding-right: 20px;
  height: 800px; /* Should be removed. Only for demonstration */
}

/* Clear floats after the columns */

.row:after {
  content: "";
  display: table;
  clear: both;
}
h4{
	padding-left:50px;
}
</style>
</head>
<body>

<?php 
include "header.php"; 
include "dbi.php";
//include "validate_member.php";
$query45 = "select * from package_type where uname='$uname'";
$result45=mysqli_query($con,$query45);
//echo "<p style='color:red;'><b><h3><center>".$package_type."</center></h3></b></p>";

while($row=mysqli_fetch_array($result45))
{
	if(!isset($_POST["pm_id"]))
	$pm_id=$row["pm_id"];
}



echo "<form action='act_free_search_filter.php' method='post'>";

echo "<div class='row' width='80%'>";

 echo"<center><h3>Search</h3>";
 echo "<font color='white'><input type='submit' class='btn active  btn-primary' name='Find' value='Find' style='background-color:#2eb82e;'/></font>";
	
	echo "<a href='view_free_matches.php' class='btn active  btn-primary'> View All Matches</a>  </center>";
	/*
   	 
 if($pm_id>1)
     {
        ///echo "<font color='white'><input type='submit' class='btn active  btn-primary' name='Find' value='Find' style='background-color:#2eb82e;'/></font>";
		 
		 echo "<a href='act_search_filter.php' class='btn active  btn-primary' style='background-color:#2eb82e;'/> Find</a>  </center>";
		echo "<a href='view_matches.php' class='btn active  btn-primary'> View All Matches</a>  </center>";
		
		
	 }
	 
 
 else
	 
	 {
		 //echo "<font color='white'><input type='submit' class='btn active  btn-primary' name='Find' value='Find' style='background-color:#2eb82e;'/></font>";
		echo "<a href='act_free_search_filter.php' class='btn active  btn-primary' style='background-color:#2eb82e;'/> Find</a>  </center>";
	    echo "<a href='view_free_matches.php' class='btn active  btn-primary'> View All Matches</a>  </center>";
	 }

	*/
?>
  
  		
  
  <div class="column1">
  
<div class="form-holder">
										<!--<fieldset>-->
											<legend>Marital Status</legend>
											<select name="marital_status" class="form-control text">
											
											<option value="">Select</option>
											
											 <option value="Never Married">Never Married</option>
	                                 <option value="Divorced">Divorced</option>
	                                 <option value="Widowed">Widowed</option>
	                                 <option value="Awaiting Divorce">Awaiting Divorce</option>
	                                  <option value="Relative">Relative</option>
	                                  <option value="Annulled">Annulled</option>
	                                  </select>
									 <!-- </fieldset>-->
									
										
								</div>
									<br>
									
																		<div class="form-holder form-holder-2">
										<fieldset>
											<legend>Caste/Sect:</legend>
											<input type="text" class="form-control" id="caste" name="caste" placeholder="Enter Caste" >

                                    						</fieldset>
									</div><br>
									
										<div class="form-holder form-holder-2">
										<fieldset>
											<legend>City Living In</legend>
											<input type="text" class="form-control" id="city" name="city" placeholder="City Living In" >
										</fieldset>
									</div><br>
									
									
									
										<div class="form-row">
									<div class="form-holder form-holder-2">
										
											<legend>Manglik:</legend>
											<select name="manglik" class="form-control text">
											
											<option value="">Select</option>
											
	                                        <option value="Yes">Yes</option>
	                                        <option value="No">No</option>
											
	                                        </select>
											
											</div>
											</div><br>
											
										
								
								
								
								<div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>Rashi:</legend>
											<input type="text" class="form-control" id="rashi" name="rashi" placeholder="Enter Rashi Name" >
										</fieldset>
									</div>
								
								</div><br>
								
								
								<div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>Nakshatra:</legend>
											<input type="text" class="form-control" id="nakshatra" name="nakshatra" placeholder="Nakshatra" >
										</fieldset>
									</div>
								</div><br>
								
							
								
    
  </div>
  
  
  
  <div class="column">
						 <div class="form-row">
							<!--		<div class="form-holder form-holder-2">
										
											<legend>Education Level:</legend>
											<select name="education_level" class="form-control text">
			 <option value="">Select</option>
	<option value="Bachelors">Bachelors</option>
	<option value="Masters">Masters</option>
	<option value="Doctorate">Doctorate</option>
	<option value="Diploma">Diploma</option>
	<option value="Undergraduate">Undergraduate</option>
	<option value="Associates Degree">Associates Degree</option>
	<option value="Honours Degree">Honours Degree</option>
	<option value="Trade School">Trade School</option>
	<option value="High School">High School</option>
	<option value="Less than high school ">Less than high school </option>
	<option value="Graduate">Graduate</option>
	
  </select>
                                        
                                    
                                    
	</div><br>
	
	
	
	
							
	<div class="form-holder form-holder-2">
										
											<legend>Education Field:</legend>
											<select name="education_field" class="form-control text">
			 <option value="">Select</option>
	<option value="Advertising/Marketing">Advertising/Marketing</option>
	<option value="Administrative Services">Administrative Services</option>
	<option value="Architecture">Architecture</option>
	<option value="Armed Forces">Armed Forces</option>
	<option value="Arts">Arts</option>
	<option value="Commerce">Commerce</option>
	<option value="Computers/IT">Computers/IT</option>
	<option value="Technical Education">Technical Education</option>
	<option value="Engineering/Technology">Engineering/Technology</option>
    <option value="Fashion">Fashion</option>
	<option value="Finance">Finance</option>
	<option value="Fine Arts">Fine Arts</option>
	<option value="Home Science">Home Science</option>
	<option value="Law">Law</option>
	<option value="Management">Management</option>
	<option value="Science">Science</option>

</select>

                                </div><br>
								
						
	
		<div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>Language:</legend>
											<input type="text" class="form-control" id="Place" name="language" placeholder="Enter language Name" >
										</fieldset>
									</div>
								
								</div><br>
	-->							
		

	<div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>Annual Income:</legend>
											<input type="text" class="form-control" id="annual_income" name="annual_income" placeholder="Annual Income " >
										</fieldset>
									</div>
									</div><br>
		
								<div class="form-holder">
									
											<legend>Height</legend>
											 <select name="height" class="form-control text">
			                       <option value="">Select</option>
	                               <option value="4ft 6in-137cm">4ft 6in-137cm</option>
	<option value="4ft 7in-139cm">4ft 7in-139cm</option>
	<option value="4ft 8in-142cm">4ft 8in-142cm</option>
	<option value="4ft 10in-147cm">4ft 10in-147cm</option>
	<option value="4ft 11in-149cm">4ft 11in-149cm</option>
	<option value="5ft 0in-152cm">5ft 0in-152cm</option>
	<option value="5ft 1in-154cm">5ft 1in-154cm</option>
	<option value="5ft 2in-157cm">5ft 2in-157cm</option>
	<option value="5ft 3in-160cm">5ft 3in-160cm</option>
	<option value="5ft 4in-165cm">5ft 4in-165cm</option>
	<option value="5ft 5in-167cm">5ft 5in-167cm</option>
	<option value="5ft 6in-170cm">5ft 6in-170cm</option>
	<option value="5ft 7in-172cm">5ft 7in-172cm</option>
	<option value="5ft 8in-175cm">5ft 8in-175cm</option>
	<option value="5ft 9in-177cm">5ft 9in-177cm</option>
	<option value="5ft 10in-180cm">5ft 10in-180cm</option>
	<option value="5ft 11in-182cm">5ft 11in-182cm</option>
	
	
</select>
			
			</div>
			
			
			                  </div><br>
								
								<div class="form-row">
									<div class="form-holder form-holder-2">
										
										<legend>Diet:</legend>
											<select name="diet" class="form-control text">
			 <option value="">Select</option>
	<option value="Veg">Veg</option>
	<option value="Non veg">Non Veg</option>
	<option value="Ocansionally Non Veg">Ocansionally Non Veg</option>
	<option value="Jain">Jain</option>
	</select>
	
                                </div>
                                                
                               </div> <br>
								
				
									<div class="form-holder form-holder-2">
									
											<legend>Smoke:</legend>
											<select name="smoke" class="form-control text">
			 <option value="">Select</option>
	<option value="yes">Yes</option>
	<option value="No">No</option>
	<option value="Occasionally">Occasionally</option>
	
	</select>
                                        
                                    
											
									</div><br>
									
									
									
									
									<div class="form-holder form-holder-2">
										
											<legend>Complexion:</legend>
											<select name="complexion" class="form-control text">
			 <option value="">Select</option>
	<option value="Fair">Fair</option>
	<option value="Very Fair">Very Fair</option>
	<option value="Dark">Dark</option>
	<option value="Wheatish">Wheatish</option>
	</select>
                                </div><br>
                                
                               </div>
    
									
									
							 </div>
	
								
								
								
								

									
  </div>
</div>
<!--</form>-->
</body>
</html>
