<?php
include "header.php";
include "dbi.php";
$uname=$_SESSION["uname"];
$db=new mysqli('localhost','websited_reshim','Reshim@123','websited_reshim_gathi');

if(!empty($uname))
{
	$result = mysqli_query($con,"select * from gallery2 where uname='$uname'");
}


?>


  
 <div class="column">
<!--  style="background-color:ghostWhite;">-->
  
  <?php
/*$user="sanjay"; //you can fetch username here*/
//$db=new mysqli('localhost','root',"",'db_reshim_gathi');
if($db->connect_errno){
echo $db->connect_error;
}

$pull="select * from gallery2 where uname='$uname'";
$allowedExts = array("jpg", "jpeg", "gif", "png","JPG");
$extension = @end(explode(".", $_FILES["file"]["name"]));
if(isset($_POST['pupload'])){
if ((($_FILES["file"]["type"] == "image/gif")
|| ($_FILES["file"]["type"] == "image/jpeg")
|| ($_FILES["file"]["type"] == "image/JPG")
|| ($_FILES["file"]["type"] == "image/png")
|| ($_FILES["file"]["type"] == "image/pjpeg"))
&& ($_FILES["file"]["size"] < 2097152)
&& in_array($extension, $allowedExts))
{
if ($_FILES["file"]["error"] > 0)
{
echo "Return Code: " . $_FILES["file"]["error"] . "<br>";
}
else
{
echo '<div class="plus">';
echo "<h3><center>Uploaded Successully</center></h3>";
echo '</div>';
/*echo"<br/><b><u>Image Details</u></b><br/>";

echo "Name: " . $_FILES["file"]["name"] . "<br/>";
echo "Type: " . $_FILES["file"]["type"] . "<br/>";
echo "Size: " . ceil(($_FILES["file"]["size"] / 1024)) . " KB";*/

if (file_exists("album_photos/album2/" . $_FILES["file"]["name"]))
{
unlink("album_photos/album2/" . $_FILES["file"]["name"]);
}
else{
$pic=$_FILES["file"]["name"];
$conv=explode(".",$pic);
//$ext=$conv['1'];
move_uploaded_file($_FILES["file"]["tmp_name"],"album_photos/album2/". $uname."."."png");
//echo "Stored in as: " . "profile_pics/".$uname.".".$ext;
$url=$uname."."."png";

$query="update gallery2 set url='$url', lastUpload=now() where uname='$uname'";
if($upl=$db->query($query)){
//echo "<h3><center>Saved to Database successfully</center></h3>";

}
}
}
}else{
echo "<center>File Size Limit Crossed 1 MB Use Picture Size less than 1 MB</center>";
}
}
?>
<form action="" method="post" enctype="multipart/form-data">
<?php
$res=$db->query($pull);
$pics=$res->fetch_assoc();
echo '<div class="imgLow">';
echo "<center><img src='album_photos/album2/$pics[url]' alt='picture2' width='300' height='300' class='doubleborder'/></center></div>";

echo "<h4><center><a href='album_photo.php'>Back to Panel</a></center></h4>";
?>
<center><input type="file" name="file" /></center>
<center><input type="submit" name="pupload" class="button" value="Upload"/></center>
</form>
  
  
 