<?php
include "header.php";
$uname = $_POST["uname"];
$name=$_FILES["file"]["name"];
$tmp_name=$_FILES["file"]["tmp_name"];
$type=$_FILES["file"]["type"];
$error=$_FILES["file"]["error"];
$file_size = $_FILES['file']['size'];

if($error==0 && ($file_size < 2097152))
{
	if($type=="image/png" || $type=="image/jpeg")
	{
		$loc="album_photos/album2/pic$uname.png";
		move_uploaded_file($tmp_name,$loc);

		echo "<center><p><a href='album_photo.php'>Back To List</a></p>";

		echo "<br/>Success: File Uploaded:<p><img src='$loc' height='400px' width='400px'/></p></center>";
	}
	else
		echo "<center><p style='color:red'>Error: Invalid File Type. Expected .jpg or .png Only</p></center>";

}
else
	echo "<center><p style='color:red'>Error: Cannot Upload File,Size Exceeds..</p></center>";


?>
