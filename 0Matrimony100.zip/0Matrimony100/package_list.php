<?php
include "header.php";
require "dbi.php";
?>
<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}

tr:hover{
	background-color:FloralWhite;
}

table{
	width:95%;
}

</style>

<?php
//include "header.php";
//require "dbi.php";

$query="select * from package_master order by pm_id";

$result = mysqli_query($con,$query) or die(mysqli_error($con));

echo "<center>";

echo "<p><a href='new_package.php'>New Package</a></p>";

echo '<div class="table-responsive">';
echo '<table border>';
echo "<tr bgcolor='DeepPink'><th><center>Sr. No.</center></th><th><center>Package</center></th>";
echo "<th><center>Price</center></th><th><center>Discount</center></th>";
echo "<th><center>Total Cost</center></th>";
echo "<th><center>Duration<br>In Month(s)</center><th><center>Chat Limit</center></th></th><th><center>Action</center></th>";
//echo "<th><center>Image</center></th></tr>";

$cnt=0;

while($row=mysqli_fetch_array($result))
{
	$cnt++;
	$pm_id=$row["pm_id"];
	$package_type=$row["package_type"];
	$price=$row["price"];
	$discount=$row["discount"];
	$duration=$row["duration"];
	$chat_limit=$row["chat_limit"];
	
	$total1=$price*($discount/100);
	$total=$price-$total1;

	echo "<tr>";
	echo "<td align='center'>$cnt</td>";
	echo "<td>&nbsp;".$row["package_type"]."</td>";
	echo "<td>&nbsp;".$row["price"]."</td>";
	echo "<td>&nbsp;".$row["discount"]."</td>";
		echo "<td>&nbsp;".$total."</td>";
	echo "<td>&nbsp;".$row["duration"]."</td>";
    echo "<td>&nbsp;".$row["chat_limit"]."</td>";
	echo "<td>";
	echo "&nbsp;<a href='edit_package.php?pm_id=$pm_id'>Edit</a>";
	echo "&nbsp;<a href='del_package.php?pm_id=$pm_id'>Delete</a>";
	echo "&nbsp;<a href='view_member_package_list.php?pm_id=$pm_id&package_type=$package_type'>Members</a>";
	echo "</td>";


	/*echo "<th>";
	echo '<a href="file_upload_home.php?sid=<?php echo $sid; ?>"><img src="home_pics/pic<?php echo $sid; ?>.png" width="50px" height="50px"/></a>';
	echo "</th>";*/
	echo "</tr>";
}

echo "</table></div>";

echo "<p><a href='admin_view_all_members.php'>View All Members</a></p>";

echo "<center>";

mysqli_close($con);
?>