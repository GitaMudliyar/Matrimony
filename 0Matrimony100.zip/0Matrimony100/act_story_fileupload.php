<?php
include "header.php";
include "dbi.php";
//$uname = $_POST["uname"];
//$partner_name=$_POST["partner_name"];
//$share_your_story=$_POST["share_your_story"];
$name=$_FILES["file"]["name"];
$tmp_name=$_FILES["file"]["tmp_name"];
$type=$_FILES["file"]["type"];
$error=$_FILES["file"]["error"];


       /*  mysqli_query($con,"update share_story set partner_name='$partner_name',share_your_story='$share_your_story'  where uname='$uname'") or die(mysqli_error($con));
              if(mysqli_affected_rows($con) > 0)
           {
	echo "<div class='well text-center'><h2 style='color:green'>Success!</h2>";
echo "<p><a href='upload_photo.php'>Back To Panel</a></p></div>";
          }


*/
if($error==0)
{
	if($type=="image/png" || $type=="image/jpeg")
	{
		$loc="share_story_pics/pic$uname.png";
		move_uploaded_file($tmp_name,$loc);

		echo "<center><p><a href='index.php'>Back To List</a></p>";

		echo "<center><H4 > <a href='logout.php' style='color:maroon'>Done... Click Here</a></h4></center>";
		
		echo "<p style='color:navy'>Success: File Uploaded:</p><p><img  src='$loc' height='350px' width='350px' style='border-radius:50%; border: 2px solid hotpink;'/></p></center>";
	
	
		
	}
	else
		echo "<center><p style='color:Maroon'>Error: Invalid File Type. Expected .jpg or .png Only</p></center>";

}
else
	echo "<center><p style='color:Maroon'>Error: Cannot Upload File</p></center>";

?>




<?php /*
//include "header.php";   // session started in header file - session_start();
//include "dbi.php";
//$uname=$_POST["uname"];

//$share_your_story=$_POST["share_your_story"];

mysqli_query($con,"update share_story set partner_name='$partner_name',share_your_story='$share_your_story'  where uname='$uname'") or die(mysqli_error($con));
if(mysqli_affected_rows($con) > 0)
{
	echo "<div class='well text-center'><h2 style='color:green'>Success!</h2>";
	//echo "<p><a href='upload_photo.php'>Back To Panel</a></p></div>";
}

//include "footer.php";*/
?>



