<?php
include "header.php";
require "dbi.php";

$f_uname=$_GET["f_uname"];
//$from=$_POST["uname"];
$t_uname=$_GET["uname"];

//echo $f_uname;

$query="update interest set comment='dislike' where f_uname='$f_uname' and t_uname='$uname'";
//echo $query;
mysqli_query($con,$query) or die(mysqli_error($con));

if(mysqli_affected_rows($con) > 0)
{
	//header("location:view_matches.php");
	//echo "Success";
	echo "<div class='well text-center'><h2 style='color:red'>Dislike $f_uname!</h2>";
	echo "<p><a href='member.php'>Back To List</a></p></div>";
}
else{
echo "<div class='well text-center'><h2 style='color:hotPink'>Already Disliked!! </h2>";
	echo "<p><a href='view_matches.php'>Back To List</a></p></div>";
}
?>