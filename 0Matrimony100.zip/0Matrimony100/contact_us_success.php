<?php 
include "header.php";
?>
<center>
<div class='well text-center'><h2 style='color:green'>Message Sent!!!</h2>
<div class='well text-center'><h2 style='color:maroon'>Thank You! We will contact you soon.....</h2>
<p><a href='index.php'>Back</a></p></div>
</center>
