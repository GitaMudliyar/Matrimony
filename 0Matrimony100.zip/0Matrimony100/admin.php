<?php
include "header.php";

require "validate_admin.php";
?>
<html><head>
<style>
div.solid{
		border-style:solid;
	}
</style></head>

<h1 style="color:dark gray">Welcome Admin</h1>


<table class="table table-striped table-bordered table-hover table-condensed " >
  <div class="list-group table-responsive solid ">
	<!--<a href="admin_profile.php" class="list-group-item">Update My Profile</a>-->
	<a href="admin_search_filter.php" class="list-group-item">View all Members</a>
	<a href="package_list.php" class="list-group-item">Package(s)</a>
	<a href="a_newly_registered_members.php" class="list-group-item">Newly Registered Members</a>
	<a href="a_received_messages.php" class="list-group-item">Inbox</a>
	<a href="a_sent_messages.php" class="list-group-item">Outbox</a>
	<a href="view_deleted_profiles.php" class="list-group-item">View Shared Stories</a>
	<a href="contact_select.php" class="list-group-item">View All Contact</a>
	<a href="feedback_select.php" class="list-group-item">View All Feedback</a>
  </div>

</table>



</html>
<?php
include "footer.php";
?>
