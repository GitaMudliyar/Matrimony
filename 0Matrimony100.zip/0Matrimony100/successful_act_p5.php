

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Succesful Matches</title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link href="css/styles.css" rel="stylesheet">
</head>
<style>
body{
background-image:url('images/bg1.jpg');
background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;

}
table {
  border-collapse: collapse;
  border-spacing: 0;
  width: 100%;
  border: 1px solid #ddd;
  background-color:White;
  
}

th, td {
  text-align: left;
  padding: 8px;
}
tr.big {
  line-height: 200%;
 font-family: Arial, Helvetica, sans-serif;
}
h1{
<!--background-color:floralWhite;-->

}
</style>
<body>

<center><h1  style="color:white;"><b> Our Successful Story</b></h1></center><br>
<div class="container">
  <div class="row">
	<div class="col-xs-6">
		<div class="thumbnail">
		<img src="./images/p5.jpg" height="600px" width="400px">
			<div class="caption">
				<center><h3><b>John Weds Kiyara</b></h3></center>
		
			</div>
		</div>
	</div>
	<div class="col-xs-6">
		<div class="thumbnail">
			<div class="caption">
				
				
				<h3><p>On 19-12-20</p></h3>
				<p><b><h4>JOHN ANTHONY,PUNE Weds KIYARA DOE,MUMBAI</h4></b></p>
			</div>
			</div>
			
	<div style="overflow-x:auto;">
			<table border="1px">
			  <tr>  <td> <b><h3>Marriage Of this Groom & Bride</h3></b></td></tr>
			   <tr class="big"><td><h4>&nbsp;&nbsp; We trust choosing your soul mate is a big and important decision, and hence effort towards giving a simple and safe matchmaking occurrence for you and your family. The purpose behind making maratha matrimony site online is to connect people with other having same interest and habit. You can find a perfect match of your Maratha caste or particular interest. </h4></td></tr>
			
			</table>
			</div>
			</div>
			

	</div>
</div>
</body>	
	