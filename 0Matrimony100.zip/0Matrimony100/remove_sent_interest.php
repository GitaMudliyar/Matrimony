<?php
include "header.php";
require "dbi.php";

$f_uname=$_SESSION["uname"];
$t_uname=$_GET["t_uname"];

$mdate=date("Y-m-d");
	
$query1="select * from interest where f_uname='$f_uname' and t_uname='$t_uname'";
//echo $query1;

/*$result1=mysqli_query($con,$query1);

while($row=mysqli_fetch_array($result1))
{
	//if(!isset($_POST["pm_id"]))
	$uid=$row["uid"];
	echo $uid;
}*/
//mysqli_query($con,$query1) or die(mysqli_error($con));

	if(mysqli_affected_rows($con) > 0)
	{
		echo "<div class='well text-center'><h2 style='color:maroon'>Already Sent!</h2>";
		echo "<p><a href='view_matches.php'>Back To List</a></p></div>";
	}
else
{
//$query="insert into interest(f_uname,t_uname,mdate) values('$f_uname','$t_uname','$mdate')";

    $query = "delete from interest where f_uname='$f_uname' and t_uname='$t_uname'";

mysqli_query($con,$query) or die(mysqli_error($con));

	if(mysqli_affected_rows($con) > 0)
	{	
		echo "<div class='well text-center'><h2 style='color:red'>Not Interested!</h2>";
		echo "<p><a href='member.php'>Back</a></p></div>";
	}

}

?>