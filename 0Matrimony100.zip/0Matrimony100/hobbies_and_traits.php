<?php
include "header.php";
require "dbi.php";
?>
<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
}

table{
	width:95%;
}


</style>

<head>
	<meta charset="utf-8">
	<title>Hobbies and Traits</title>
	<!-- Mobile Specific Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!-- Font-->
	<link rel="stylesheet" type="text/css" href="css/opensans-font.css">
	<link rel="stylesheet" type="text/css" href="fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">
	<!-- Main Style Css -->
    <link rel="stylesheet" href="css/style.css"/>
</head>
<body>

<?php 
//include "header.php"; 
//include "validate_member.php";

?>
<form action="update_hobbies_and_traits.php" method="post">

<div class='table-responsive' >
<table border='0'>
  <th>
<!--
  <font color="navy">
<b><h4><a href="personal_information.php" id="aa"  class='btn active  btn-primary'   style="background-color:crimson";><span></span>
	<span></span><span></span><span></span>01 Personal Information&nbsp;
	</a></h4></b>
	<br>
	<h4><a href="profile_details.php" id="aa" class='btn active  btn-primary' style="background-color:crimson">02 Profile Details
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		
	<h4><a href="family_details.php" id="aa" class='btn active  btn-primary'style="background-color:crimson">03 Family Details
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
	
	<h4><a href="astro_details.php" id="aa" class='btn active  btn-primary'style="background-color:crimson">04 Astro Details
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>

	<h4><a href="education_and_career.php" id="aa" class='btn active  btn-primary'style="background-color:crimson">05 Education And Career</a></h4><br>

	<h4><a href="hobbies_and_traits.php" id="aa" class='btn active  btn-primary'style="background-color:pink"><font color="navy">06 Hobbies and Traits</font>
	&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		<h4><a href="about_myself.php" id="aa" class='btn active  btn-primary'style="background-color:crimson"> 07 About Myself
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		
		<h4><a href="expectation.php" id="aa" class='btn active  btn-primary'style="background-color:crimson"> 08 My Expectations
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		
		<h4> <a href="upload_photo.php"id="aa" class='btn active  btn-primary'style="background-color:crimson">09 Upload Profile Photo&nbsp;&nbsp;</a></h4><br>
    
	</font>
	
	
  </div>
  </th></th>-->
  
  		<?php
//include "dbi.php";


if(!empty($uname))
{
	$result = mysqli_query($con,"select * from hobbies_and_traits where uname='$uname'");

	if($row=mysqli_fetch_array($result))
	{
		
$h_describe=$row["h_describe"];
$h_activities=$row["h_activities"];

	}
	else
	{
		$h_describe=""; $h_activities="";
	}

}


?>
  
  <div class="column">
 <!--   <h2>Column 2</h2>
    <p>Some text..</p>-->
	
	<div class="wizard-header">
									<h3 class="heading"><b>Hobbies and Traits</b></h3>
									<p>Please enter your infomation and proceed to the next step so we can build your accounts.</p>
								</div>
						
			                		 <div class="form-row">
									<!--<div class="form-holder form-holder-2">-->
										
											<legend>My family and Friend Describe Me As:</legend><br>
										
   <textarea rows = "3" cols = "50" name = "h_describe" style="text-align:left-side;">
        
         </textarea>
		 
		 
		 <div class="form-row">
									<!--<div class="form-holder form-holder-2">-->
										
	<legend>I Like These Activities:</legend><br>
										
											<!--<form action="#">-->
   <textarea rows = "3" cols = "30" name = "h_activities" style="text-align:left-side;">&nbsp;&nbsp
        
         </textarea>
		 <br><br>
		 
		 <a href=' personal_information.php' class='btn active  btn-primary' style='background-color:green';>Previous</font></a>

&nbsp;&nbsp;&nbsp;
<input type="submit" name="submit"  class='btn active  btn-danger' value="Save and Next"  style="background-color:blue;"/>
		 
		 <!--<input type="submit" name="submit" value="Save and Next"  style="background-color:#2eb82e;"/>-->
  </div>
</div></th>
</form>
</body>
</html>
