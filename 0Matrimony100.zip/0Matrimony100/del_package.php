<?php
include "header.php";
require "dbi.php";
?>
<?php
//include "header.php";
$pm_id= $_GET["pm_id"];

//require "dbi.php";
$query="select * from package_type where pm_id=$pm_id";

$result=mysqli_query($con,$query) or die(mysqli_error($con));

if(mysqli_num_rows($result) > 0)
{
	echo "<center><h2 style='color:red'>Member Exist. Cannot Delete Package</h2>";
	echo "<p><a href='package_list.php'>Back to List</a></p></center>";
	exit;
}

$query="select * from package_master where pm_id=$pm_id";

$result=mysqli_query($con,$query) or die(mysqli_error($con));

if($row=mysqli_fetch_array($result))
{
	$package_type=$row["package_type"];
}
else
{
	
	echo "<center><h2>Package Not Found</h2>";
	echo "<p><a href='package_list.php'>Back to List</a></p></center>";
	exit;
}

?>
<html>
<body>
<center>
<p><a href='package_list.php'>Back to List</a></p>

<form action="delete_package.php" method="post">

<?php
	echo "<h2 style='color:red'>Delete Package: $package_type @ PM_ID: $pm_id</h2>";
	echo "<h2>Are You Sure?</h2>";

?>

<input type="hidden" name="pm_id" value="<?php echo $pm_id; ?>" />


<input type="submit"  value="Confirm Delete"/>

</form>
</center>
</body>
</html>