<?php
include "header.php";
require "dbi.php";
?>
<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
}

table{
	width:95%;
}

h4{
	padding-left:50px;
}
#aa{
	color:white;
}
/*	position:relative;
	display:inline-block;
	padding:15px 30px;
	text-decoration:none;
	font-size:24px;
	overflow:hidden;
	transition:0.2s;
	
}*/

#aa:hover
{
	color:white;
	background:#2196f3;
	box-shadow: 0 0 10px #2196f3, 0 0 40px #2196f3, 0 0 80px #2196f3;
	transition-delay:-1s;
}

/*

a span
{
	position:absolute;
	display:block;
}

a span:nth-child(1)
{
	top:0;
	left:0%;
	width:100%;
	height:2px;
	background:linear-gradient(90deg,transparent,#2196f3);
}*/

</style>
</head>
<body>

<?php 
//include "header.php"; 
//include "validate_member.php";

?>
<form action="update_personal_information.php" method="post">
<div class='table-responsive' >
<table border='0'>

<th>
<!--<div class="row" width="80%">
  <div class="column1"><br><br>-->
  <font color="navy">
<b><h4><a href="personal_information.php" id="aa"  class='btn active  btn-primary'   style="background-color:pink";><span></span>
	<span></span><span></span><span></span><font color="navy">01 Personal Information&nbsp;</font></a></h4></b>
	<br>
	<h4><a href="profile_details.php" id="aa" class='btn active  btn-primary' style="background-color:crimson">02 Profile Details
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		
	<h4><a href="family_details.php" id="aa" class='btn active  btn-primary'style="background-color:crimson">03 Family Details
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
	
	<h4><a href="astro_details.php" id="aa" class='btn active  btn-primary'style="background-color:crimson">04 Astro Details
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>

	<h4><a href="education_and_career.php" id="aa" class='btn active  btn-primary'style="background-color:crimson">05 Education And Career</a></h4><br>

	<h4><a href="hobbies_and_traits.php" id="aa" class='btn active  btn-primary'style="background-color:crimson">06 Hobbies and Traits
	&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		<h4><a href="about_myself.php" id="aa" class='btn active  btn-primary'style="background-color:crimson"> 07 About Myself
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		
		<h4><a href="expectation.php" id="aa" class='btn active  btn-primary'style="background-color:crimson"> 08 My Expectations
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		
		<h4> <a href="upload_photo.php"id="aa" class='btn active  btn-primary'style="background-color:crimson">09 Upload Profile Photo&nbsp;&nbsp;</a></h4><br>
    
	</font>
    
  <!--</div>-->
  </th><th>
  
  		<?php
//include "dbi.php";

if(!empty($uname))
{
	$result = mysqli_query($con,"select * from personal_information where uname='$uname'");

	if($row=mysqli_fetch_array($result))
	{
	
$created_for=$row["created_for"];	
$fn=$row["fname"];
$ln=$row["lname"];

$e_email=$row["e_email"];
$phone=$row["phone"];
$dob=$row["dob"];

//$udt=date("Y-m-d");
	}
	else
	{
		$created_for=""; $fn=""; $ln=""; $e_email=""; $phone=""; $dob=""; //$udt="";
	}

}

?>


  
 <!--   <h2>Column 2</h2>
    <p>Some text..</p>-->
	

			                	<div class="wizard-header">
									<h3 class="heading"><strong>Personal Infomation</strong></h3>
									<strong><p>Please enter your infomation and proceed to the next step so we can build your accounts.  </p>
</strong>							
							</div>
								<div class="form-row"> 
									<div class="form-holder">
										
											<legend>Create Profile For</legend>
											<!--<input type="text" class="form-control" id="first-name" name="first-name" placeholder="First Name" required>-->
											<select name="created_for" id="created_for" style='text-transform:uppercase'>
											<option value="Select">SELECT</option>
											<option value="self">Self</option>
											<option value="son">Son</option>
											<option value="daughter">Daughter</option>
											<option value="relative_friend">Relative/Friend</option>
											<option value="brother">Brother</option>
											<option value="sister">Sister</option>
											<option value="client_marriage_bureau">Client-Marriage Bureau</option>
										</select>
										
									</div>
									</div>
									<div class="form-row">
									<div class="form-holder">
									<!--<input type="hidden" class="form-control" id="rid" name="rid">
										--><fieldset>
											<legend>First Name</legend>
											<input type="text" class="form-control" id="fname" value="<?php echo $fn;?>" name="fname" placeholder="FIRST NAME"  style='text-transform:uppercase' required>
										</fieldset>
									</div>
									<div class="form-holder">
										<fieldset>
											<legend>Last Name</legend>
											<input type="text" class="form-control" id="lname" name="lname" value="<?php echo $ln;?>" placeholder="Last Name"  style='text-transform:uppercase' required>
										</fieldset>
									</div>
								</div>
								<div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>Your Email</legend>
											<input type="email" name="e_email" id="e_email"  class="form-control" value="<?php echo $e_email;?>" placeholder="EXAMPLE@GMAIL.COM" required>
											<!--<input type="email" class="form-control" id="e_email" name="e_email" value="// echo $ln;>" placeholder="eamp" required>-->
										</fieldset>
									</div>
								</div>
								<div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>Phone Number</legend>
<!--<input type="number" class="form-control" id="phone" maxLength="10" name="phone" value="<?php //echo $phone;   ?>" placeholder="+1 888-999-7777" required>-->


<input type="tel" id="phone" name="phone" value="<?php echo $phone;?>" placeholder="9876543210" pattern="[0-9]{3}[0-9]{2}[0-9]{3}[0-9]{2}" class="form-control" required><br>
	
</fieldset>
										</fieldset>
									</div>
								</div>
																			<!--<div class="form-row form-row-date">
									<div class="form-holder form-holder-2">
										<label class="special-label">Birth Date:</label>
										<input type="date" id="dob" name="dob" value="<?php //echo $dob;?>">-->
										
										



												<div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>Birth Date</legend>
											<input type="date" id="dob" name="dob" value="<?php echo $dob;?>" required><br><br>
											<input type="submit" name="submit"  class='btn active  btn-danger' value="Save and Next"  style="background-color:blue;"/>
											
			</th>								
											<script>


public static function isBirthDate($date)
	{
		if (empty($date) || $date == '0000-00-00')
			return false;
		if (preg_match('/^([0-9]{4})-((?:0?[1-9])|(?:1[0-2]))-((?:0?[1-9])|(?:[1-2][0-9])|(?:3[01]))([0-9]{2}:[0-9]{2}:[0-9]{2})?$/', $date, $birth_date))
		{
		    if (date('Y')-$birth_date[1]<=18)
		        return false;  
			if ($birth_date[1] > date('Y') && $birth_date[2] > date('m') && $birth_date[3] > date('d'))
				return false;
			return true;
		}
		return false;
	}
</script>

											
											
																				
										</fieldset>
									</div>
								</div>
						
										<br><br>
										
										
										<!--<input type="submit" onclick="ValidateDOB();" name="submit" value="Save and Next"  style="background-color:#2eb82e;"/>-->
									</div>
								</div>
								
  </div>
</div>
</form>
</body>
</html>