<?php
include "header.php";   // session started in header file - session_start();
include "dbi.php";
//$uname=$_POST["uname"];

$family_values=$_POST["family_values"];
$fathers_status=$_POST["fathers_status"];
$mothers_status=$_POST["mothers_status"];
$no_of_brothers=$_POST["no_of_brothers"];
$no_of_sisters=$_POST["no_of_sisters"];
$native_place=$_POST["native_place"];
$family_description=$_POST["family_description"];
$body_weight=$_POST["body_weight"];
$blood_group=$_POST["blood_group"];
$primary_mobile_no=$_POST["primary_mobile_no"];
$secondary_mobile_no=$_POST["secondary_mobile_no"];
$address=$_POST["address"];
$f_city=$_POST["f_city"];
$state=$_POST["state"];
$f_country=$_POST["f_country"];


mysqli_query($con,"update family_details set family_values='$family_values',fathers_status='$fathers_status',mothers_status='$mothers_status',no_of_brothers='$no_of_brothers',no_of_sisters='$no_of_sisters',native_place='$native_place' ,family_description='$family_description',
body_weight='$body_weight',blood_group='$blood_group',primary_mobile_no='$primary_mobile_no',secondary_mobile_no='$secondary_mobile_no',address='$address',f_city='$f_city',state='$state',f_country='$f_country' where uname='$uname'") or die(mysqli_error($con));
if(mysqli_affected_rows($con) > 0)
{
	//echo "<div class='well text-center'><h2 style='color:green'>Success:Family Details Updated!</h2>";
	//echo "<p><a href='astro_details.php'>Back To Panel</a></p></div>";
	header("location:astro_details.php");	
}

//include "footer.php";
?>
