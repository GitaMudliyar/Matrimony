<?php
include "header.php";   // session started in header file - session_start();
include "dbi.php";
//$uname=$_POST["uname"];
$about_self=$_POST["about_self"];

mysqli_query($con,"update about_myself set about_self='$about_self'  where uname='$uname'") or die(mysqli_error($con));
if(mysqli_affected_rows($con) > 0)
{
	//echo "<div class='well text-center'><h2 style='color:green'>Success: Photo Updated!</h2>";
	//echo "<p><a href='upload_photo.php'>Back To Panel</a></p></div>";
	header("location:expectation.php");	
	
}

//include "footer.php";
?>

