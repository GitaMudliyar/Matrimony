<?php
include "header.php";
require "dbi.php";
?>
<style>
th,td{
	background-color:#FFEFD5;
	padding:15px;
	text-align:left;
	border-bottom:1px solid Darkgray;
	height:50px;
	text-align:center;
	
}

tr:hover{
	background-color:FloralWhite;
}

table{
	background-color:#FFD700;
	width:95%;
}

</style>


<?php
//include "header.php";
//require "dbi.php";
 //$uname=$_SESSION['uname']; 
 $caste=$_POST['caste'];
 //$gender = isset($_POST['gender']) ? $_POST['gender'] : 0;
 $gender=$_POST['gender'];
 $city=$_POST['city'];
 $marital_status=$_POST['marital_status'];
 $manglik=$_POST['manglik'];
 $rashi=$_POST['rashi'];
 $nakshatra=$_POST['nakshatra'];
 $annual_income=$_POST['annual_income'];
 //$education_level=$_POST['education_level'];
 //$education_field=$_POST['education_field'];
 $height=$_POST['height'];
 $diet=$_POST['diet'];
 $smoke=$_POST['smoke'];
 $complexion=$_POST['complexion'];
 
 //echo $gender." dd";

//$username = $_SESSION['uname'];
// $gender = mysqli_fetch_object(mysqli_query($con, "SELECT * FROM profile_details WHERE uname = '$username'"))->gender;


//$query44 = "select * from profile_details";
//$query45 = "select * from package_type where uname='$uname'";

//$result45=mysqli_query($con,$query45);


/*while($row=mysqli_fetch_array($result45))
{
	if(!isset($_POST["pm_id"]))
	$pm_id=$row["pm_id"];
}*/



?>
</center>




<?php


/*$query1="select * from view_profile_match where gender<>'$gender' AND caste= '$caste' AND city='$city' and marital_status='$marital_status' 
AND manglik='$manglik' AND rashi='$rashi' AND nakshatra='$nakshatra' AND annual_income>='$annual_income' AND education_level='$education_level' 
AND education_field='$education_field' AND height='$height' AND diet='$diet' AND smoke='$smoke' AND complexion='$complexion'";
*/
$cnt=0;
 
$query = "select * from view_profile_match where gender = '$gender'";
 
if($caste != "" ) {
	 $caste = $_POST['caste'];
	$query .= " AND caste = '$caste' ";
	
}

if($city != "" ) {
	 $city = $_POST['city'];
	$query .= " AND city = '$city' ";
	
}

if($marital_status != "" ) {
	 $marital_status = $_POST['marital_status'];
	$query .= " AND marital_status = '$marital_status' ";
	
}
if($manglik != "" ) {
	 $manglik = $_POST['manglik'];
	$query .= " AND manglik = '$manglik' ";
	
}

if($rashi != "" ) {
	 $rashi = $_POST['rashi'];
	$query .= " AND rashi = '$rashi' ";
	
}

if($nakshatra!= "" ) {
	 $nakshatra = $_POST['nakshatra'];
	$query .= " AND nakshatra = '$nakshatra' ";
	
}
if($annual_income != "" ) {
	 $annual_income = $_POST['annual_income'];
	$query .= " AND annual_income= '$annual_income' ";
	
}
/*
if($education_level != "" ) {
	 $education_level = $_POST['education_level'];
	$query .= " AND education_level = '$education_level' ";
	
}

if($education_field != "" ) {
	 $education_field = $_POST['education_field'];
	$query .= " AND education_field = '$education_field' ";
	
}
*/
if($height != "" ) {
	 $height = $_POST['height'];
	$query .= " AND height = '$height' ";
	
}

if($diet!= "" ) {
	 $diet = $_POST['diet'];
	$query .= " AND diet = '$diet' ";
	
}
if($smoke != "" ) {
	 $smoke= $_POST['smoke'];
	$query .= " AND smoke = '$smoke' ";
	
}
if($complexion != "" ) {
	 $complexion = $_POST['complexion'];
	$query .= " AND complexion = '$complexion' ";
	
}



//echo $query;
$result1 = mysqli_query($con,$query) or die(mysqli_error($con));

echo "<center>";

//echo "<p><a href='new_cat.php'>New Category</a></p>";
echo "<div class='table-responsive'>";
echo "<table>";

	while($row=mysqli_fetch_array($result1))
	{
		//while($row=mysqli_fetch_array($result11))
		//{
			//$cnt++;
			//$id=$row["cpid"];
			$uname=$row["uname"];
			$fname=$row["fname"];
			$lname=$row["lname"];
			//$gender=$row["gender"];
			$dob=$row["dob"];
			$height=$row["height"];
			$city=$row["city"];
			$manglik=$row["manglik"];
			$caste=$row["caste"];
			$annual_income=$row["annual_income"];

			$t_nm=$row["fname"]." ".$row["lname"];
			echo "<tr>";
			echo "<font color='white'>";
	
				echo "<td>";
				echo "<a href='profile_pics/pic$uname.png'><img src='profile_pics/pic$uname.png' height='200px' width='200px' /></a>";
		
	
			echo "</td>";
	
	echo "<td style='text-align:right'>Name&nbsp;&nbsp;<br>Gender&nbsp;&nbsp;<br>DOB&nbsp;&nbsp;<br>Height&nbsp;&nbsp;<br>City&nbsp;&nbsp;<br>Manglik&nbsp;&nbsp;<br>Caste&nbsp;&nbsp;<br>Annual Income&nbsp;&nbsp;<br></td>";
	echo "<td style='text-align:left'>".$row["fname"]." ".$row["lname"]."<br>".$row["gender"]."<br>".$row["dob"]."<br>".$row["height"]."</br>".$row["city"]."</br>".$row["manglik"]."</br>".$row["caste"]."</br>".$row["annual_income"]."</br></td>";
/*	
	    echo "<td >&nbsp;<a href='view_read_more.php?uname=$uname' class='btn active  btn-warning'>Read More</a>";
		 echo "&nbsp;&nbsp;&nbsp;<a href='send_interest.php?uname=$uname' class='btn active  btn-primary'>Interested</a>";
	
	echo "&nbsp;&nbsp;&nbsp;<a href='m_send_message_m.php?uname=$uname&t_nm=$t_nm&pm_id=$pm_id' class='btn active  btn-primary' style='background-color:#2eb82e';>Send Message</font></a>";
		 
	*/
	echo "</td></tr>";
		//}
	}


echo "</table>";
echo "</div>";


echo "<br>";
echo "<p><a href='admin.php' class='btn btn-danger btn-block'>Back To Panel</a></p>";

echo "<center>";

mysqli_close($con);
include "footer.php";
?>
