<?php
include "header.php";
require "dbi.php";


$pm_id=$_POST["pm_id"];
//echo $pm_id;
$from=$_POST["m_nm"];
//$from=$_POST["m_nm"];
//$to=$_POST["nm"];
$f_uname=$_POST["uname"];

$t_uname=$_POST["t_uname"];
$to_u=$_POST["t_nm"];
$mdate=$_POST["mdate"];
$subject=$_POST["subject"];
$contents=$_POST["contents"];
$f_status = '';
//$sid=$_POST["sid"];
//$sk=$_POST["sk"];

//echo $f_uname;
$query2="select * from package_master where pm_id ='$pm_id'";
$result2=mysqli_query($con,$query2);

while($row=mysqli_fetch_array($result2))
{
	//if(!isset($_POST["chat_limit"]))
	$chat_limit=$row["chat_limit"];
}
//echo $chat_limit;
$query3="select * from message where (f_uname ='$uname' and t_uname='$t_uname') or (f_uname='$t_uname' and t_uname='$uname') ";
//and t_uname='$t_uname'";
// and f_status <> 1 and t_status <> 1";
//echo $query3;
$result3=mysqli_query($con,$query3);
$cnt=1;
$message_count = 0;

while($row=mysqli_fetch_array($result3))
{
	//$f_uname=$row["f_uname"];
	//$t_uname=$row["t_uname"];
	$message_count=$row["message_count"];
	$f_status=$row["f_status"]; 
	$t_status=$row["t_status"];

		
}
	



	//echo "Hya to";

//echo $message_count;

if($chat_limit > $message_count) 
{
		$cnt=$message_count+1;
	
	if($f_status ==1 and $t_status==1)
	{
		echo "<div class='well text-center'><h2 style='color:red'>Unable To Send Message</h2>";
	echo "<p><a href='member.php'>Back To Panel</a></p></div>";	
	}
	else
	{
			//echo "Message Sent $f_status $t_status";
		$query="insert into message(f_uname,from_u,t_uname,to_u,mdate,subject,contents,message_count) values('$f_uname','$from','$t_uname','$to_u','$mdate','$subject','$contents','$cnt')";
	
		mysqli_query($con,$query) or die(mysqli_error($con));
	
		if(mysqli_affected_rows($con) > 0)
		{
			$remaining=$chat_limit-$cnt;
	
			echo "<div class='well text-center'><h2 style='color:green'>Success: Message Sent!</h2>";
			echo "<div class='well text-center'><h3 style='color:navy'>Now You Have only $remaining Messages To Send...!</h3>";
			echo "<p><a href='member.php'>Back To Panel</a></p></div>";
		}
	}
}	

	else 
	{
	 
		echo "<div class='well text-center'><h2 style='color:green'>You Can't Send Any Messages</h2>";
		echo "<div class='well text-center'><h2 style='color:red'>Limit Exceeded</h2>";
		//header("location:member.php");
		echo "<p><a href='member.php'>Back To Panel</a></p></div>";	
	}
	//}
/*}
else
{
	echo "<div class='well text-center'><h2 style='color:green'>Unable To Send Message</h2>";
	echo "<p><a href='member.php'>Back To Panel</a></p></div>";	
}*/

?>