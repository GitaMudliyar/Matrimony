<?php
include "header.php";
require "dbi.php";
?>
<style>
th,td{
	background-color:#FFEFD5;
	padding:15px;
	text-align:left;
	border-bottom:1px solid Darkgray;
	height:50px;
	text-align:center;
	
}

tr:hover{
	background-color:FloralWhite;
}

table{
	background-color:#FFD700;
	width:95%;
}

</style>


<?php
//include "header.php";
//require "dbi.php";
 $uname=$_SESSION['uname'];
 //print_r($_SESSION);
$username = $_SESSION['uname'];
 $gender = mysqli_fetch_object(mysqli_query($con, "SELECT * FROM profile_details WHERE uname = '$username'"))->gender;
// echo $gender;




$query45 = "select * from package_type where uname='$uname'";
$result45=mysqli_query($con,$query45);
//echo "<p style='color:red;'><b><h3><center>".$package_type."</center></h3></b></p>";

while($row=mysqli_fetch_array($result45))
{
	if(!isset($_POST["pm_id"]))
	$pm_id=$row["pm_id"];
}
/*echo $pm_id;

$query46 = "select * from package_master where pm_id <= '$pm_id'";
echo $query46;
*/


$filter = isset($_POST["filter"])?$_POST["filter"]:"";
$btn = isset($_POST["btn"])?$_POST["btn"]:"";

if(empty($filter) || $btn=="Show All")
{
	$cnt=0;

	$query11="select * from view_profile_match where gender<>'$gender' and pm_id=1   order by uid";
	$result11 = mysqli_query($con,$query11) or die(mysqli_error($con));
	$filter="";
	
	echo "<center>";
		
	//$cnt=0;

//echo "<p><a href='new_cat.php'>New Category</a></p>";
echo "<div class='table-responsive'>";
echo "<table>";
	
		while($row=mysqli_fetch_array($result11))
		{
			$cnt++;
			//$id=$row["cpid"];
			$uname=$row["uname"];
			$fname=$row["fname"];
			$lname=$row["lname"];
			//$gender=$row["gender"];
			$dob=$row["dob"];
			$height=$row["height"];
			$city=$row["city"];
			$manglik=$row["manglik"];
			$caste=$row["caste"];
			$annual_income=$row["annual_income"];
			$t_nm = $row["fname"]." ".$row["lname"];
			
//echo "$fname $lname";

			echo "<tr>";
			echo "<font color='white'>";
			/*$db=new mysqli('localhost','root',"",'db_reshim_gathi');
if($db->connect_errno){
echo $db->connect_error;
}*/

			$pull="select * from profile_image where uname='$uname'";
			$result = mysqli_query($con,$pull) or die(mysqli_error($con));
			
			//$res=$db->query($pull);
$pics=$result->fetch_assoc();
			
				echo "<td>";
				//echo "<a href='profile_pics/$pics[url]'><img src='profile_pics/$pics[url]' height='200px' width='200px' /></a>";
		
	          echo "<img src='profile_pics/$pics[url]' height='200px' width='200px' />";
			echo "</td>";
	
	echo "<td style='text-align:right'>Name&nbsp;&nbsp;<br>Gender&nbsp;&nbsp;<br>DOB&nbsp;&nbsp;<br>Height&nbsp;&nbsp;<br>City&nbsp;&nbsp;<br>Manglik&nbsp;&nbsp;<br>Caste&nbsp;&nbsp;<br>Annual Income&nbsp;&nbsp;<br></td>";
	echo "<td style='text-align:left'>".$row["fname"]." ".$row["lname"]."<br>".$row["gender"]."<br>".$row["dob"]."<br>".$row["height"]."</br>".$row["city"]."</br>".$row["manglik"]."</br>".$row["caste"]."</br>".$row["annual_income"]."</br></td></tr>";
	
	    /*echo "<td >&nbsp;<a href='view_read_more.php?uname=$uname' class='btn active  btn-warning'>Read More</a>";
		echo "&nbsp;&nbsp;&nbsp;<a href='send_interest.php?uname=$uname' class='btn active  btn-primary'>Interested</a>";
		echo "&nbsp;&nbsp;&nbsp;<a href='m_send_message_m.php?uname=$uname&t_nm=$t_nm&pm_id=$pm_id' class='btn active  btn-primary' style='background-color:#2eb82e';>Send Message</font></a>";
		echo "&nbsp;<font color='white' class='btn active  btn-primary' style='background-color:black';>" . getPercentage($con, $uname, $username) . "%" . "</font>";
	
	echo "</td></tr>";*/
	//echo "</table>";
	
		}

//echo $cnt;	
echo "<div><font color='deepPink'><h2 style='color:crimson'>$cnt Profile Match Your Requirements</font></h2>";	

}

else
{
	$query11="select * from view_profile_match where caste like '%$filter%' and gender<> '$gender' and pm_id=1  order by uid";
}

//$res1 =mysqli_query($con,$query11) or die(mysqli_error($con));
$result11 = mysqli_query($con,$query11) or die(mysqli_error($con));

echo "<center>";

function getPercentage($con, $uname, $username) {
	
	$per = 0;
	$userExpectation = mysqli_fetch_object(mysqli_query($con, "SELECT * FROM expectation WHERE uname = '$username'"));
	$matchExpetation = mysqli_fetch_object(mysqli_query($con, "SELECT * FROM view_expectation WHERE uname = '$uname'"));
	
	$maritalStatus = $userExpectation->marital_status;
	if($maritalStatus == $matchExpetation->marital_status && $maritalStatus<>"") {
		$per += 10;
		
	}
	
	
	$height = $userExpectation->height;
	if($height == $matchExpetation->height  && $height<>"") {
		$per += 10;
		
	}
	
	$caste = $userExpectation->caste;
	if($caste == $matchExpetation->caste && $caste<>"") {
		$per += 10;
		
	}
	
	$gotra = $userExpectation->gotra;
	if($gotra == $matchExpetation->gotra  && $gotra<>"") {
		$per += 10;
		
	}
	
	$city = $userExpectation->city;
	if($city == $matchExpetation->city  && $city<>"") {
		$per += 10;
		
	}
	

	
	$manglik= $userExpectation->manglik;
	if($manglik == $matchExpetation->manglik && $manglik<>"") {
		$per += 10;
		
	}
	
	$rashi = $userExpectation->rashi;
	if($rashi == $matchExpetation->rashi  && $rashi<>"") {
		$per += 10;
		
	}
	
	$nakshatra = $userExpectation->nakshatra;
	if($nakshatra == $matchExpetation->nakshatra && $nakshatra<>"") {
		$per += 10;
		
	}
	
	$e_educational_level = $userExpectation->e_educational_level;
	if($e_educational_level == $matchExpetation->e_educational_level  && $e_educational_level<>"") {
		$per += 10;
		
	}
	$e_educational_field = $userExpectation->e_educational_field;
	if($e_educational_field == $matchExpetation->e_educational_field  && $e_educational_field<>"") {
		$per += 10;
		
	}
	
	return $per;
	
	
}

mysqli_close($con);
//include "footer.php";
?>
