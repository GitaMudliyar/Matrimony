<?php
include "header.php";
include "validate_member.php";
include "dbi.php";
?>
<html>
<body>
<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}
th{
	color:white;
}

table{
	width:95%;
}

</style>
<center>




<form action="album1_act_fileupload.php" method="post">
<div class="table-responsive">

<table border >

<tr>
<td>

<a href="album1_file_upload.php?uname=<?php echo $uname; ?>"><img src="album_photos/album1/<?php echo $uname; ?>.png" width="200px" height="200px"/></a>
 
	<br>	 

<br><a href="album1_file_upload.php?uname=<?php echo $uname; ?>" style="background-color:MidnightBlue" class='btn active  btn-warning'>Upload</a>

</td>

<td>

<a href="album2_file_upload.php?uname=<?php echo $uname; ?>"><img src="album_photos/album2/<?php echo $uname; ?>.png" width="200px" height="200px"/></a>
	<br>
<br><a href='album2_file_upload.php?uname=<?php echo $uname; ?>' style="background-color:deepPink;" class='btn active  btn-warning'>Upload</a> 
</td>


<td>

<a href="album3_file_upload.php?uname=<?php echo $uname; ?>"><img src="album_photos/album3/<?php echo $uname; ?>.png" width="200px" height="200px"/></a>
		<br> 

<br><a href='album3_file_upload.php?uname=<?php echo $uname; ?>' style="background-color:MidnightBlue" class='btn active  btn-warning'>Upload</a>
</td>

</tr>

<p><a href='member.php'>Back</a></p>

<?php

mysqli_close($con);
?>

</div>
</form>
</center>
</body>
</html>