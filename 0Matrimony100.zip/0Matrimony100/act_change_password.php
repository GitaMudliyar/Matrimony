<?php
include "header.php";   // session started in header file - session_start();
include "dbi.php";
$uname=$_POST["uname"];
$npwd=$_POST["npwd"];
$cpwd=$_POST["cpwd"];


if(empty($uname) || empty($npwd))
{
	echo "<div class='well text-center'><h2 style='color:red'>Error: UserName/ Password Required !</h2>";
	echo "<p><a href='registration.php'>Try Again</a></p></div>";
	include "footer.php";
	return;
}

if($npwd!=$cpwd)
{
	echo "<div class='well text-center'><h2 style='color:red'>Error: Passwords Mismatch!</h2>";
	echo "<p><a href='forgot_password.php'>Try Again</a></p></div>";
	include "footer.php";
	return;
}



$query="update login set pwd=md5('$npwd')  where uname='$uname'";
//echo $query;
$result=mysqli_query($con,$query);

if(mysqli_affected_rows($con) > 0)
{
	echo "<div class='well text-center'><h2 style='color:green'>Success: Password Changed!</h2>";
	echo "<p><a href='login.php'>Click here to login..</a></p></div>";
	//header("location:login.php");	
}


//$query45 = "select * from package_type where uname='$uname'";


?>


<?php



//include "footer.php";
?>

