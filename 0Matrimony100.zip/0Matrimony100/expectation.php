<?php
include "header.php";
require "dbi.php";
?>
<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
}

table{
	width:95%;
}


</style>

<head>
	<meta charset="utf-8">
	<!-- Mobile Specific Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!-- Font-->
	<link rel="stylesheet" type="text/css" href="css/opensans-font.css">
	<link rel="stylesheet" type="text/css" href="fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">
	<!-- Main Style Css -->
    <link rel="stylesheet" href="css/style.css"/>
</head>
<body>

<?php
//include "header.php";
?>
<form action="update_expectation.php" method="post">

<div class='table-responsive' >
<table border='0'>

<th><!--
  <font color="navy">
<b><h4><a href="personal_information.php" id="aa"  class='btn active  btn-primary'   style="background-color:crimson";><span></span>
	<span></span><span></span><span></span>01 Personal Information&nbsp;
	</a></h4></b>
	<br>
	<h4><a href="profile_details.php" id="aa" class='btn active  btn-primary' style="background-color:crimson">02 Profile Details
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		
	<h4><a href="family_details.php" id="aa" class='btn active  btn-primary'style="background-color:crimson">03 Family Details
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
	
	<h4><a href="astro_details.php" id="aa" class='btn active  btn-primary'style="background-color:crimson">04 Astro Details
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>

	<h4><a href="education_and_career.php" id="aa" class='btn active  btn-primary'style="background-color:crimson">05 Education And Career</a></h4><br>

	<h4><a href="hobbies_and_traits.php" id="aa" class='btn active  btn-primary'style="background-color:crimson">06 Hobbies and Traits
	&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		<h4><a href="about_myself.php" id="aa" class='btn active  btn-primary'style="background-color:crimson"> 07 About Myself
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		
		<h4><a href="expectation.php" id="aa" class='btn active  btn-primary'style="background-color:pink"> <font color="navy">08 My Expectations</font>
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		
		<h4> <a href="upload_photo.php"id="aa" class='btn active  btn-primary'style="background-color:crimson">09 Upload Profile Photo&nbsp;&nbsp;</a></h4><br>
    
	</font>
    
  </div>
  </th><th>-->
<?php
//include "dbi.php";
//require "validate_member.php";

if(!empty($uname))
{
	$result = mysqli_query($con,"select * from expectation where uname='$uname'");

	if($row=mysqli_fetch_array($result))
	{

$marital_status=$row["marital_status"];
$height=$row["height"];
$caste=$row["caste"];
//$sub_caste=$row["sub_caste"];
$gotra=$row["gotra"];
$city=$row["city"];
$manglik=$row["manglik"];

$rashi=$row["rashi"];
$nakshatra=$row["nakshatra"];
$e_educational_level=$row["e_educational_level"];
$e_educational_field=$row["e_educational_field"];

	}
	else
	{
$marital_status="";
$height="";
$caste="";

$gotra="";
$city="";
$manglik="";

$rashi="";
$nakshatra="";
$e_educational_level="";
$e_educational_field="";
	}

}


?>
  
  <div class="column">
 <!--   <h2>Column 2</h2>
    <p>Some text..</p>-->
	
	<div class="wizard-header">
									<h3 class="heading"><b>My Expectations</b></h3>
									<p>Please enter your infomation and proceed to the next step so we can build your accounts.</p>
								</div>
								
								
<div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
										
										<!--<fieldset>-->
											<legend>Marital Status</legend>
											<select name="marital_status" class="form-control text">
											
											<option value="Select">SELECT</option>
											
											 <option value="Never Married">Never Married</option>
	                                 <option value="Divorced">Divorced</option>
	                                 <option value="Widowed">Widowed</option>
	                                 <option value="Awaiting Divorce">Awaiting Divorce</option>
	                                  <option value="Relative">Relative</option>
	                                  <option value="Annulled">Annulled</option>
	                                  </select>
									 <!-- </fieldset>-->
									
									</fieldset>
									</div>
								</div>
									<div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>Height:</legend>
											
										<table>
										<tr>
										<th>
									
											
	
						<div class="form-holder">
											
											 <select name="feet" class="form-control text">
			                       <option value="">Feet</option>
								                               <option value="4 ft">4 ft</option>
	<option value="5 ft">5 ft </option>
	<option value="6 ft">6 ft </option>
	<option value="7 ft">7 ft </option>
	<option value="8 ft">8 ft</option>
	<option value="9 ft">9 ft</option>
	<option value="10 ft">10 ft</option>
	  
	</th>
</div>

<th>
<div class="form-holder">
											<!-----<legend>Height</legend>-->
											 <select name="inch" class="form-control text">
			                       <option value="">Inch</option>
	  
									     <option value="1 in">1 in</option>
	<option value="2 in">2 in </option>
	<option value="3 in">3 in </option>
	<option value="4 in">4 in</option>
	<option value="5 in">5 in</option>
	<option value="6 in">6 in</option>
	<option value="7 in">7 in</option>
	<option value="8 in">8 in </option>
	<option value="9 in">9 in</option>
	<option value="10 in">10 in</option>
	<option value="11 in">11 in</option>
	<option value="12 in">12 in</option>

	
	
	
</select>
		
			</tr>
	</table>
			</div>

			  
								<div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>Caste/Sect:</legend>
											<!--<input type="text" class="form-control" id="phone" name="caste" placeholder="Enter Cast" required>-->
                                            <select name="caste" class="form-control text">
			                       <option value="">Caste</option>
	                               <option value="Hinduism">Hinduism</option>
	<option value="Buddhism">Buddhism</option>
	<option value="Jainism">Jainism</option>
	<option value="Sikhim">Sikhim</option>
	<option value="Islam">Islam</option>
	<option value="Christianity">Christianity</option>
	<option value="Judaism">Judaism</option>
	<option value="Other Religions">Other Religions</option>
	</select>
	
	
	      						</fieldset>
									</div>
									
									
						<div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>Gotra/Gotram:</legend>
											<input type="text" class="form-control" id="phone" name="gotra"  value="<?php echo $gotra;?>" placeholder="ENTER GOTRA/GOTRAM" required>

			
	</fieldset>
                                </div>
                                
                              
							   </div>
                                				<div class="form-holder form-holder-2">
										<fieldset>
											<legend>City Living In</legend>
											<input type="text" class="form-control" id="phone" name="city" value="<?php echo $city;?>" placeholder="City Living In"  style='text-transform:uppercase' required>
										</fieldset>
									</div>
								</div>
								
									<div class="form-row">
									<div class="form-holder form-holder-2">
										
											<legend>Manglik:</legend>
											<select name="manglik" class="form-control text">
											
											<option value="Select">SELECT</option>
											
	                                        <option value="Yes">Yes</option>
	                                        <option value="No">No</option>
											
	                                        </select>
											
											</div>
											</div>
																			
								<div class="form-row">
									<div class="form-holder form-holder-2">
										
											<legend>Rashi:</legend>
											<select name="rashi" class="form-control text">
											
											<option value="Select">SELECT</option>
											
	                                        <option value="Aries_Mesha">Aries(Mesha)</option>
	                                        <option value="Taurus_Vrishabha">Taurus(Vrishabha)</option>
											<option value="Gemini_Mithuna">Gemini(Mithuna)</option>
											<option value="Cancer_Karka">Cancer(Karka)</option>
											<option value="Leo_Singha">Leo(Singha)</option>
											<option value="Virgo_Kanya">Virgo(Kanya)</option>
										    <option value="Libra_Tula">Libra(Tula)</option>
										    <option value="Scorpio_Vrushchika">Scorpio(Vrushchika)</option>
										    <option value="Sagittarius_Dhanu">Sagittarius(Dhanu)</option>
											<option value="Capricorn_Makara">Capricorn(Makara)</option>
										    <option value="Aquarius_Kumbha">Aquarius(Kumbha)</option>
										    <option value="Pisces_Meena">Pisces(Meena)</option>
											
											
	                                        </select>
									</div>
								
								</div>
								
								
								<div class="form-row">
									<div class="form-holder form-holder-2">
										
											<legend>Nakshatra:</legend>
											<select name="nakshatra" class="form-control text">
											
											<option value="Select">SELECT</option>
											
	                                        <option value="ashwini">Ashwini</option>
											<option value="bharani">Bharani</option>
											<option value="krittika">Krittika</option>
											<option value="rohini">Rohini</option>
											<option value="mrigashīrsha">Mrigashīrsha</option>
											<option value="ardra">Ardra</option>
											<option value="punarvasu">Punarvasu</option>
											<option value="pushya">Pushya</option>
											
											 <option value="ashlesha">Ashlesha</option>
											<option value="magha">Magha</option>
											<option value="purva phalguni">Purva Phalguni</option>
											<option value="uttara phalguni">Uttara Phalguni</option>
											<option value="hasta">Hasta</option>
											<option value="chitra">Chitra</option>
											<option value="svati">Svati</option>
											<option value="visakha">Visakha</option>
											
											 <option value="anuradha">Anuradha</option>
											<option value="jyeshtha">Jyeshtha</option>
											<option value="mula">Mula</option>
											<option value="purva ashadha">Purva Ashadha</option>
											<option value="uttara ashadha">Uttara Ashadha</option>
											<option value="sravana">Sravana</option>
											<option value="dhanishta">Dhanishta</option>
											<option value="shatabhisha">Shatabhisha</option>
											
											<option value="Purva bhadrapada">Purva Bhadrapada</option>
											<option value="uttara bhadrapada">Uttara Bhadrapada</option>
											<option value="revati">Revati</option>
											
											</select>
									</div>
								</div>
								
																
			                		 <div class="form-row">
									<div class="form-holder form-holder-2">
										
											<legend>Education Level:</legend>
											<select name="e_educational_level" class="form-control text">
			 <option value="Select">SELECT</option>
	<option value="Bachelors">Bachelors</option>
	<option value="Masters">Masters</option>
	<option value="Doctorate">Doctorate</option>
	<option value="Diploma">Diploma</option>
	<option value="Undergraduate">Undergraduate</option>
	<option value="Associates Degree">Associates Degree</option>
	<option value="Honours Degree">Honours Degree</option>
	<option value="Trade School">Trade School</option>
	<option value="Occasionally">High School</option>
	<option value="High School">Less than high school </option>
	<option value="Graduate">Graduate</option>
	
  </select>
                                        
                                    
                                    
	</div>
	</div>
	
	
	<div class="form-row">
							
	<div class="form-holder form-holder-2">
										
											<legend>Education Field:</legend>
											<select name="e_educational_field" class="form-control text">
			 <option value="Select">SELECT</option>
	<option value="Advertising/Marketing">Advertising/Marketing</option>
	<option value="Administrative Services">Administrative Services</option>
	<option value="Architecture">Architecture</option>
	<option value="Armed Forces">Armed Forces</option>
	<option value="Arts">Arts</option>
	<option value="Commerce">Commerce</option>
	<option value="Computers/IT">Computers/IT</option>
	<option value="Education">Education</option>
	<option value="Engineering/Technology">Engineering/Technology</option>
    <option value="Fashion">Fashion</option>
	<option value="Finance">Finance</option>
	<option value="Fine Arts">Fine Arts</option>
	<option value="Home Science">Home Science</option>
	<option value="Law">Law</option>
	<option value="Management">Management</option>
	<option value="Science">Science</option>

</select>

                                </div>
                                
                           </div>
						   
						<br>
		 <a href=' personal_information.php' class='btn active  btn-primary' style='background-color:green';>Previous</font></a>

&nbsp;&nbsp;&nbsp;
<input type="submit" name="submit"  class='btn active  btn-danger' value="Save and Next"  style="background-color:blue;"/>
		 <!--<input type="submit" name="submit" value="Save and Next"  style="background-color:#2eb82e;"/>-->
  </div>
</div></th>
</form>
</body>
</html>
