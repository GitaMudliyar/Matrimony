<?php
include "header.php";
require "dbi.php";
?>
<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}

tr:hover{
	background-color:FloralWhite;
}

table{
	width:95%;
}

</style>

<?php
$pm_id= $_GET["pm_id"];
//include "header.php";
//require "dbi.php";


$query="select * from package_master where pm_id=$pm_id";

$result=mysqli_query($con,$query) or die(mysqli_error($con));

if($row=mysqli_fetch_array($result))
{
	$package_type=$row["package_type"];
	$price=$row["price"];
	$discount=$row["discount"];
	$duration=$row["duration"];
	$chat_limit=$row["chat_limit"];
	
}
else
{
	echo "<center><h2>Package Not Found</h2>";
	echo "<p><a href='package_list.php'>Back to List</a></p></center>";
	exit;
}

?>
<html>

<body>
<center>
<p><a href='package_list.php'>Back to List</a></p>


<form action="update_package.php" method="post">
<div class="table-responsive">
<table>
<tr bgcolor='deepPink'><td colspan="2" align='center'>
UPDATE PACKAGE
</td>
</tr>

<tr>
<td>PACKAGE ID:</td>
<td><input type="text" name="pm_id" readonly value="<?php echo $pm_id; ?>" /></td>
</tr>

<tr>
<td>Enter Package:</td>
<td><input type="text" name="package_type" value="<?php echo $package_type; ?>" /></td>
</tr>

<tr>
<td>Enter Price:</td>
<td><input type="text" name="price" value="<?php echo $price; ?>" /></td>
</tr>

<tr>
<td>Enter Percentage of Discount:</td>
<td><input type="text" name="discount" value="<?php echo $discount; ?>" /></td>
</tr>

<tr>
<td>Enter Duration:</td>
<td><input type="text" name="duration" value="<?php echo $duration; ?>" /></td>
</tr>

<tr>
<td>Enter Chat Limit:</td>
<td><input type="text" name="chat_limit" value="<?php echo $chat_limit; ?>" /></td>
</tr>

<tr bgcolor='thistle'><td colspan="2" align='center'>
<input type="submit"  value="Update Package"/>
</td>
</tr>

</table></div>
</form>
</center>
</body>
</html>