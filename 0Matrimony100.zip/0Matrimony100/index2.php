<?php
//include "header.php";
?>

<html>

<meta name='viewport' content='width=device-width, initial-scale=1'>
<script src='https://kit.fontawesome.com/a076d05399.js'></script>




<style>

.table{
	font-size:20px;
}


.label {
  color: white;
  padding: 8px;
  font-family: Arial;
}

.label {
	background-color: #2196F3;
	} 



     .bg{
   background-image: url("img/back102");
  background-repeat: no-repeat;
	 background-size: cover;}
	 </style>
<br>
<body style="background-image:url('images/nb3.jpg'); background-size:cover;">

<center>
		<p class="thumbnail">
		<center>
		<img src="images/ricon2.png" height="100px" width="100px">
		</center>
		</p>
</center>

<center>
<div><h2 style='color:#DB3082'><p>Reshimgathi.com - Join 3 Million Members With photos</p></h2></div>
</center>
<br>

<div style=font-size:20px; id="wik"><center>
<p>Reshimgathi, one of India's best known brands and the world's largest matrimonial service was founded with a simple objective</p> to help people find happiness.
 The company pioneered online matrimonials in 2020 and continues to lead the exciting
 matrimony category after more than a year.
 <p>By redefining the way Indian brides and grooms meet for marriage, Reshimgathi has created a world-renowned service that has touched over 2 million people. </p>
 </center>
 </div>
 <form>
 <form><!-- action="/about_us.php">--><br><br>
 <center><span class="label Trusted by Millions" style=font-size:22px;>Trusted by Millions</span></center>
  <!--<label style=font-size:27px; for="Trusted by Millions">Trusted by Millions</label>-->
 </form>
 <br><br>
 <div class="table-responsive" >
 <center>
<table class="table table-hover table-bordered table-striped">

 <!--<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
    <table>
    <tr>
    <td>Text <span align="right"><i class="fa fa-toggle-on"></i></span></td>
      <td>Test</td>
    </tr>
    </table>
-->


 <td><img src="images/index2_1.png" height="30px" width="30px"/></td>&nbsp;
 <td width="400px">Best Matches</td>
 <td><img src="images/index2_3.png" height="30px" width="30px"/></td>&nbsp;
 <td width="400px">Max Responce</td>&nbsp;
 <td><img src="images/index2_2.png" height="30px" width="30px"/></td>&nbsp;
 <td width="400px"> 100% Privacy</td>
</table>
</center> 
 <!--<div class="container">
  <div class="row">
	<div class="col-xs-6"><p style='color:darkSlategray'>
				<h3>Our Vision</h3>
				To provide customers with home repair service experience that delights 
				them and become their best-handy-friend.
				<p>
				We also provide Employement Opportunities 
				
				</p>
	</div>

	
	<div class="col-xs-6">
		
			<div class="caption">
			<p style='color:darkSlategray'>
				<h3>Our Values</h3>
				We believe in our processes and in our people who lead them. 
				We enjoy the power of empowerment and delegation.
				</p>
			</div>-->
		</a>
	</div>
  </div>

</div>

 
 
 
 
 
 
</center>
</center>
</body>
</html>
<script src= "js/myjQuery.js"> </script> 
<?php
include "footer_main.php"
?>