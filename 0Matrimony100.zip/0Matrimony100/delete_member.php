<?php
include "header.php";
require "dbi.php";
?>
<?php
//require "dbi.php";
//include "header.php";
$uname= $_GET["uname"];
$nm=$_GET["nm"];
//echo $uname;

//$query="delete from login where uname='$uname'";
 $query1="delete from login where uname='$uname'";
 //echo $query1;
    $query2 = "delete from personal_information where uname='$uname'";
	
	// echo $query2;
	$query3 = "delete from profile_details where uname='$uname'";
	 //echo $query3;
	 
	$query4 = "delete from family_details where uname='$uname'";
	 //echo $query4;
	$query5 = "delete from astro_details where uname='$uname'";
	 //echo $query5;
	$query6 = "delete from education_and_career where uname='$uname'";
	 //echo $query6;
	$query7 = "delete from hobbies_and_traits where uname='$uname'";
	 //echo $query7;
	$query8 = "delete from about_myself where uname='$uname'";
	 //echo $query8;
	$query9 = "delete from interest where f_uname='$uname' or t_uname='$uname'";
	 //echo $query9;
	  
	  
		//$query9 = "delete from delete_profile where uname='$uname'";
		
	
	mysqli_query($con,$query1) or die(mysqli_error($con));
	mysqli_query($con,$query2) or die(mysqli_error($con));
	mysqli_query($con,$query3) or die(mysqli_error($con));
	mysqli_query($con,$query4) or die(mysqli_error($con));
	mysqli_query($con,$query5) or die(mysqli_error($con));
	mysqli_query($con,$query6) or die(mysqli_error($con));
	mysqli_query($con,$query7) or die(mysqli_error($con));
	mysqli_query($con,$query8) or die(mysqli_error($con));
	mysqli_query($con,$query9) or die(mysqli_error($con));

//mysqli_query($con,$query) or die(mysqli_error($con));

if(mysqli_affected_rows($con) > 0)
{
	echo "<div class='well text-center'><h2 style='color:green'>Success: User Deleted!</h2>";
	echo "<p><a href='admin.php' class='btn btn-primary'>Back To List</a></p></div>";
}
else
{
	echo "<div class='well text-center'><h2 style='color:green'>Success: User Deleted!</h2>";
	echo "<p><a href='admin.php' class='btn btn-primary'>Back To List</a></p></div>";
}	
	
include "footer.php"; 
?>