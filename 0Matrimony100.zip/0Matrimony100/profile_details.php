<?php
include "header.php";
require "dbi.php";
?>
<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
}

table{
	width:95%;
}


</style>

<head>
	<meta charset="utf-8">
	<title>Profile Details</title>
	<!-- Mobile Specific Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!-- Font-->
	<link rel="stylesheet" type="text/css" href="css/opensans-font.css">
	<link rel="stylesheet" type="text/css" href="fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">
	<!-- Main Style Css -->
    <link rel="stylesheet" href="css/style.css"/>
</head>
<body>

<?php 
//include "header.php"; 
//include "validate_member.php";

?>
<form action="update_profile_details.php" method="post">

<div class='table-responsive' >
<table border='0'>

<th>  <!--
  <font color="navy">
<b><h4><a href="personal_information.php" id="aa"  class='btn active  btn-primary'   style="background-color:crimson";><span></span>
	<span></span><span></span><span></span>01 Personal Information&nbsp;
	</a></h4></b>
	<br>
	<h4><a href="profile_details.php" id="aa" class='btn active  btn-primary' style="background-color:pink"><font color="navy">02 Profile Details</font>
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		
	<h4><a href="family_details.php" id="aa" class='btn active  btn-primary'style="background-color:crimson">03 Family Details
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
	
	<h4><a href="astro_details.php" id="aa" class='btn active  btn-primary'style="background-color:crimson">04 Astro Details
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>

	<h4><a href="education_and_career.php" id="aa" class='btn active  btn-primary'style="background-color:crimson">05 Education And Career</a></h4><br>

	<h4><a href="hobbies_and_traits.php" id="aa" class='btn active  btn-primary'style="background-color:crimson">06 Hobbies and Traits
	&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		<h4><a href="about_myself.php" id="aa" class='btn active  btn-primary'style="background-color:crimson"> 07 About Myself
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		
		<h4><a href="expectation.php" id="aa" class='btn active  btn-primary'style="background-color:crimson"> 08 My Expectations
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		
		<h4> <a href="upload_photo.php"id="aa" class='btn active  btn-primary'style="background-color:crimson">09 Upload Profile Photo&nbsp;&nbsp;</a></h4><br>
    
	</font>
    
  </th><th>
  -->
  
  		<?php
//include "dbi.php";
//require "validate_member.php";

if(!empty($uname))
{
	$result = mysqli_query($con,"select * from profile_details where uname='$uname'");

	if($row=mysqli_fetch_array($result))
	{
$gender=$row["gender"];
$marital_status=$row["marital_status"];
$height=$row["height"];
$caste=$row["caste"];
$sub_caste=$row["sub_caste"];
$gotra=$row["gotra"];
$diet=$row["diet"];
$smoke=$row["smoke"];

$personal_values=$row["personal_values"];
$complexion=$row["complexion"];
$body_type=$row["body_type"];
$special_cases=$row["special_cases"];
$residency_status=$row["residency_status"];
//$education_level=$row["education_level"];
//$education_field=$row["education_field"];
$aadhar=$row["aadhar"];
$language=$row["language"];


$country=$row["country"];
$city=$row["city"];
$working_with=$row["working_with"];
$working_as=$row["working_as"];
$annual_income=$row["annual_income"];

$prefer_working_partner=$row["prefer_working_partner"];
	}
	else
	{
$gender="";
$marital_status="";
$height="";
$caste="";
$sub_caste="";
$gotra="";
$diet="";
$smoke="";

$personal_values="";
$complexion="";
$body_type="";
$special_cases="";
$residency_status="";
$education_level="";
$education_field="";
$country="";
$city="";
$working_with="";
$working_as="";
$annual_income="";
$prefer_working_partner="";

	}

}


?>
  
  <div class="column">
  
   <!--<div class="inner">-->
			                	<div class="wizard-header">
									<h3 class="heading"><b>Profile Details</b></h3>
									<p>Please enter your infomation and proceed to the next step so we can build your accounts.
									</p>
									</div>
										
                              <div class="form-row">
							  
							  <div class="form-holder">
										<!--<fieldset>-->
											<legend>Gender</legend>
											<select name="gender" class="form-control text" required>
											
											<option value="Select">SELECT</option>
											
											 <option value="Male">Male</option>
	                                 <option value="Female">Female</option>
	                                 
	                                  </select>
									 <!-- </fieldset>-->
									
										
									</div>
							  
							   <div class="form-row">
									<div class="form-holder">
										<!--<fieldset>-->
											<legend>Marital Status</legend>
											<select name="marital_status" class="form-control text">
											
											<option value="Select">SELECT</option>
											
											 <option value="Never Married">Never Married</option>
	                                 <option value="Divorced">Divorced</option>
	                                 <option value="Widowed">Widowed</option>
	                                 <option value="Awaiting Divorce">Awaiting Divorce</option>
	                                  <option value="Relative">Relative</option>
	                                  <option value="Annulled">Annulled</option>
	                                  </select>
									 <!-- </fieldset>-->
									
										
									</div>
									<div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>Height:</legend>
											
										<table>
										<tr>
										<th>
									
											
	
						<div class="form-holder">
											
											 <select name="feet" class="form-control text">
			                       <option value="">Feet</option>
								                               <option value="4 ft">4 ft</option>
	<option value="5 ft">5 ft </option>
	<option value="6 ft">6 ft </option>
	<option value="7 ft">7 ft </option>
	<option value="8 ft">8 ft</option>
	<option value="9 ft">9 ft</option>
	<option value="10 ft">10 ft</option>
	  
	</th>
</div>

<th>
<div class="form-holder">
											<!-----<legend>Height</legend>-->
											 <select name="inch" class="form-control text">
			                       <option value="">Inch</option>
	  
									     <option value="1 in">1 in</option>
	<option value="2 in">2 in </option>
	<option value="3 in">3 in </option>
	<option value="4 in">4 in</option>
	<option value="5 in">5 in</option>
	<option value="6 in">6 in</option>
	<option value="7 in">7 in</option>
	<option value="8 in">8 in </option>
	<option value="9 in">9 in</option>
	<option value="10 in">10 in</option>
	<option value="11 in">11 in</option>
	<option value="12 in">12 in</option>

	
	
	
</select>
		
			</tr>
	</table>
			</div>

			  
								<div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>Caste/Sect:</legend>
											<!--<input type="text" class="form-control" id="phone" name="caste" placeholder="Enter Cast" required>-->
                                            <select name="caste" class="form-control text">
			                       <option value="">Caste</option>
	                               <option value="Hinduism">Hinduism</option>
	<option value="Buddhism">Buddhism</option>
	<option value="Jainism">Jainism</option>
	<option value="Sikhim">Sikhim</option>
	<option value="Islam">Islam</option>
	<option value="Christianity">Christianity</option>
	<option value="Judaism">Judaism</option>
	<option value="Other Religions">Other Religions</option>
	</select>
	
	
	      						</fieldset>
									</div>
									
								
								
								
                                	<div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>Subcaste:</legend>
											<input type="text" class="form-control" id="phone" name="sub_caste"  value="<?php echo $sub_caste;?>" placeholder="ENTER SUBCASTE"  style='text-transform:uppercase' required>

			
	</fieldset>
                                </div>
                                
                               </div>
							    </div>
							   
						<div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>Gotra/Gotram:</legend>
											<input type="text" class="form-control" id="phone" name="gotra"  value="<?php echo $gotra;?>" placeholder="ENTER GOTRA/GOTRAM" required>

			
	</fieldset>
                                </div>
                                
                              
							   </div>
                                					
								
                                					
								
								
								<div class="form-row">
									<div class="form-holder form-holder-2">
										
										<legend>Diet:</legend>
											<select name="diet" class="form-control text">
			 <option value="Select">SELECT</option>
	<option value="Veg">Veg</option>
	<option value="Non veg">Non Veg</option>
	<option value="Ocansionally Non Veg">Ocansionally Non Veg</option>
	<option value="Jain">Jain</option>
	</select>
	
                                </div>
                                                
                                
								
				
									<div class="form-holder form-holder-2">
									
											<legend>Smoke:</legend>
											<select name="smoke" class="form-control text">
			 <option value="Select">SELECT</option>
	<option value="yes">Yes</option>
	<option value="No">No</option>
	<option value="Occasionally">Occasionally</option>
	
	</select>
                                        
                                    
											
									</div>
							 </div>
								
								<div class="form-row">
									<div class="form-holder form-holder-2">
										
											<legend>Personal Values:</legend>
											<select name="personal_values" class="form-control text">
			 <option value="Select">SELECT</option>
	<option value="Traditional">Traditional</option>
	<option value="Moderate">Moderate</option>
	<option value="Liberal">Liberal</option>
	
	</select>
                                        
                                    
											
									</div>
								
								
								
								
									<div class="form-holder form-holder-2">
										
											<legend>Complexion:</legend>
											<select name="complexion" class="form-control text">
			 <option value="Select">SELECT</option>
	<option value="Fair">Fair</option>
	<option value="Very Fair">Very Fair</option>
	<option value="Dark">Dark</option>
	<option value="Wheatish">Wheatish</option>
	</select>
                                </div>
                                
                               </div>
                                
                                
							
								
								<div class="form-row">
									<div class="form-holder form-holder-2">
										
											<legend>Body Type::</legend>
											<select name="body_type" class="form-control text">
			 <option value="Select">SELECT</option>
	<option value="Slim">Slim</option>
	<option value="Average">Average</option>
	<option value="Heavy">Heavy</option>
	<option value="Athaletic">Athaletic</option>
	
	
	</select>
	
                                        
                                    </div>
									
									
									
									<div class="form-holder form-holder-2">
										
											<legend>Special Cases:</legend>
											<select name="special_cases" class="form-control text">
			 
			 <option value="Select">SELECT</option>
			 <option value="None">None</option>
	<option value="Physically Challenged From Birth">Physically Challenged From Birth</option>
	<option value="Physically challenged due to accident">Physically challenged due to accident</option>
	<option value="Mentally challenged from birth">Mentally challenged from birth</option>
	<option value="Mentally challenged due to accident">Mentally challenged due to accident</option>
	<option value="Physically abnormality affecting only looks">Physically abnormality affecting only looks</option>
	<option value="Physically abnormality affecting bodily functions">Physically abnormality affecting bodily functions</option>
	<option value="Physically and mentally challenged">Physically and mentally challenged</option>
	</select>

                                        
                                    </div>
						</div>
                                
								
								<div class="form-row">
									<div class="form-holder form-holder-2">
										
											<legend>Residency Status:</legend>
											<select name="residency_status" class="form-control text">
			 <option value="Select">SELECT</option>
	<option value="Citizen">Citizen</option>
	<option value="Permanent Resident">Permanent Resident</option>
	<option value="Student Visa">Student Visa</option>
	<option value="Temporary visa">Temporary visa</option>
	<option value="Work Permit">Work Permit</option>
	
	
	</select>
	
	</div>
	</div>
	
	                                <div class="form-row">
									<div class="form-row">
									<div class="form-holder form-holder-2">
										
											<legend>Language:</legend>
											<input type="text" class="form-control" id="phone" name="language"  value="<?php echo $language;?>" placeholder="Enter Language" required>
											
											
                                        </textarea>
                                    <!--<input  class="form-control" id="Place" name="address" required>
                                    -->
                                        
                                    
                                    
	</div>
	
	
	
	
							
	<div class="form-holder form-holder-2">
										
											
											<fieldset>
											<legend>Aadhar Card Number:</legend>
											<input type="tel" id="phone" name="aadhar"  value="<?php echo $aadhar;?>" placeholder="Enter Adhar Number" pattern="[0-9]{4}[0-9]{4}[0-9]{4}" class="form-control" required><br>
									</div>
			

                                </div>
                                
                           </div>
	                            <div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>Country Living In</legend>
											<input type="text" class="form-control" id="phone" name="country"  value="<?php echo $country;?>" placeholder="Country Living In"  style='text-transform:uppercase' required>
										</fieldset>
									</div>
								
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>City Living In</legend>
											<input type="text" class="form-control" id="phone" name="city" value="<?php echo $city;?>" placeholder="City Living In"  style='text-transform:uppercase' required>
										</fieldset>
									</div>
								</div>
								
								<div class="form-row">
									<div class="form-holder form-holder-2">
										
											<legend>Working With:</legend>
									<select name="working_with" class="form-control text">
			 <option value="Select">SELECT</option>
	<option value="Private Company">Private Company</option>
	<option value="Government">Government</option>
	<option value="Defense/Civil Services">Defense/Civil Services</option>
	<option value="Business/Self Employed">Business/Self Employed</option>
	<option value="Non Working">Non Working</option>
	
  </select>
           
	</div>
	
	                                  
									<div class="form-holder form-holder-2">
								
		
										<fieldset>
											<legend>Working As:</legend>
											<input type="text" class="form-control" id="working_as" name="working_as"  value="<?php echo $working_as;?>" placeholder="Working as"  style='text-transform:uppercase' required>
										</fieldset>
									</div>
								</div>
								
								<div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>Annual Income:</legend>
											<input type="text" class="form-control" id="Annual Income" name="annual_income"  value="<?php echo $annual_income;?>" placeholder="ANNUAL INCOME " required>
										</fieldset>
									</div>
								
								
								
									<div class="form-holder form-holder-2">
										
											<legend>Would a Prefer a Working Partner:</legend>
											<select name="prefer_working_partner" class="form-control text">
			 <option value="Select">SELECT</option>
	<option value="Self">YES</option>
	<option value="Parent/Guardian">NO</option>
	<option value="Occasionally">Does Not Matter</option>
  </select>
									</div>
									<br>
									
<a href=' personal_information.php' class='btn active  btn-primary' style='background-color:green';>Previous</font></a>

&nbsp;&nbsp;&nbsp;
<input type="submit" name="submit"  class='btn active  btn-danger' value="Save and Next"  style="background-color:blue;"/>

	
								
  
 </div></th>
</form>
</body>
</html>
