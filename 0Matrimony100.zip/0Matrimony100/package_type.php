<?php
include "header.php";
include "validate_member.php";
include "dbi.php";
?>
<html>
<body>
<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}
th{
	color:white;
}

tr:hover{
	background-color:FloralWhite;
}

table{
	width:95%;
}

</style>
<center>


<?php

$query="select * from package_master where (pm_id <> 1)order by pm_id desc";

$result = mysqli_query($con,$query) or die(mysqli_error($con));

echo "<center>";

//echo "<p><a href='new_package.php'>New Package</a></p>";

echo '<div class="table-responsive">';
echo '<table border>';
echo "<tr bgcolor='DeepPink'><th><center>Sr. No.</center></th><th><center>Package</center></th>";
echo "<th><center>Price</center></th><th><center>Discount</center></th> <th><center>Total Price</center></th>";
echo "<th><center>Duration<br>In Month(s)</center></th>";
echo "<th><center>Total<br>Days</center></th><th><center>Chat Count</center></th>";
echo "</tr>";

$cnt=0;

while($row=mysqli_fetch_array($result))
{
	$cnt++;
	$pm_id=$row["pm_id"];
	$package_type=$row["package_type"];
	$price=$row["price"];
	$discount=$row["discount"];
	$duration=$row["duration"];
    $chat_limit=$row["chat_limit"];
	$total1=$price*($discount/100);
	$days=$duration*30;
	$total=$price-$total1;
	echo "<tr>";
	echo "<td align='center'>$cnt</td>";
	echo "<td>&nbsp;".$row["package_type"]."</td>";
	echo "<td>&nbsp;".$row["price"]."</td>";
	echo "<td>&nbsp;".$row["discount"]."</td>";
	echo "<td>&nbsp;".$total."</td>";
	echo "<td>&nbsp;".$row["duration"]."</td>";
	echo "<td>&nbsp;".$days."</td>";
    echo "<td>&nbsp;".$row["chat_limit"]."</td>";
	
	
	echo "</tr>";
}

echo "</table></div>";


echo "<center>";
echo "<br>";


?>


<form action="update_package_details.php" method="post">
<div class="table-responsive">
<?php


if(!empty($uname))
{
	$result = mysqli_query($con,"select * from personal_information where uname='$uname'");

	if($row=mysqli_fetch_array($result))
	{
		
		$uname=$row["uname"];
		$m_nm = $row["fname"]." ".$row["lname"];
		
	}
}
?>
<table border>
<tr bgcolor='darkCyan'><td colspan="2" align='center'>
<font color="white"><b>PACKAGE DETAILS</b></font>
</td></tr>

<tr>
<td>User Name:-</td>
<td><input type="text" readonly name="uname" value="<?php echo $uname;?>"/></td>
</tr>

<tr>
<td>Name:-</td>
<td><input type="text" readonly name="m_nm" value="<?php echo $m_nm;?>"/></td>
</tr>
<!--<td>Date:-</td>
<td><input type="text" readonly name="purchase_date" value="<?php// echo $purchase_date;?>"/></td>
</tr>-->




<tr>
<td>SELECT PACKAGE:-</td>
<td>
<select name="pm_id">
<?php
//include "dbi.php";

$query="select * from package_master where (pm_id <> 1) order by pm_id desc";

$result = mysqli_query($con,$query);

while($row=mysqli_fetch_array($result))
{
	$pm_id=$row["pm_id"];
	$package_type=$row["package_type"];

	echo "<option value='$pm_id'>$package_type</option>";
}


?>
</select>

</td>
</tr>


<tr bgcolor='Honeydew'><td colspan="2" align='center'>
<input type="submit"  value="BUY NOW"/>
</td>
</tr>
</table>

<p><a href='member.php'>Back</a></p>
<!--View services table added below-->

<?php

mysqli_close($con);
?>

</div>
</form>
</center>
</body>
</html>