<?php
include "header.php";
include "dbi.php";

require "validate_member.php";
?>
<style>
div.solid{
	border-style:solid;
}
html,body{
	background-image:url('images/bb1.jpg');
}
</style>
<html>
<body>
<head>

</head>
<center> <!--<a href='package_type.php'><img qsrc="images/gift_box.png" height="60px" width="120px"/></a> <br>-->

	<a href="package_type.php" style ="color:navy"><h5><b>Click Here to</b></h5><h4><b>Buy Package</b></h4></a><br>
</center>
<!--<h1 style ="color:dark gray">Welcome Member</h1>-->


<div class="row">
	<div class="col-md-3">
			<div class="caption">
				<p style="color:#B6237C;font-size:20px;"><b>Get Exciting Packages</b></p>
							</div>
	</div>
	
	<div class="col-md-6">
			<div class="caption">
				<marquee style="color: red;">
				<img src="images/train.gif" height="70" width="130"/>
				<b>
				&nbsp;<a href='package_type.php' style="background-color:khaki;color:black" class='btn active  btn-warning'><b>
				&nbsp;Silver &nbsp;</b></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				
				&nbsp;<a href='package_type.php' style="background-color:#ffdb58;color:'bold';" class='btn active  btn-warning'><b>
				&nbsp;<font color='black'>Gold &nbsp;</font></b></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
				
				&nbsp;<a href='package_type.php' style="background-color:#e1ad01;color:black" class='btn active  btn-warning'><b>
				&nbsp;Platinum &nbsp;</b></a>
				</b></marquee>
				
				
			</div>
	</div>
	
	<div class="col-md-3">
			<div class="caption">
				<!--<p style="color:  #cc0000;font-size:20px;"><b>For More Offers and Benefits</b></p>-->
				<!--<p style="color:#cc0000;font-size:20px;"><b>Get Exciting Packages</b></p>-->
			</div>	
			
<?php


$query="select * from package_type where uname='$uname'";

$result = mysqli_query($con,$query) or die(mysqli_error($con));

while($row=mysqli_fetch_array($result))
{
	$pm_id=$row["pm_id"];
	$purchase_date=$row["purchase_date"];
	$uname=$row["uname"];
	$pt_id=$row["pt_id"];
	//echo $purchase_date,$uname,$pm_id."<br>" ;
	
}

$query="select * from package_master where pm_id='$pm_id'";

$result = mysqli_query($con,$query) or die(mysqli_error($con));

while($row=mysqli_fetch_array($result))
{
	//$pm_id=$row["pm_id"];
	$duration=$row["duration"];
	$days=$duration*30;

	//echo $days."<br>";
}

if($pm_id != 1)
{
	$date=date_create("$purchase_date");

	echo "<b><p style='color:#e80505;font-size:16px;'><font color='navy'>Your Pack Expires On: </font>";
	date_add($date,date_interval_create_from_date_string("$days days"));
	$expires=date_format($date,"Y-m-d");
	//echo "<h4 style='color:tan;'>".$expires."</h4>";
	echo "<font color='#e6005c'>".$expires."</font>";

	echo"</p></b>";
	mysqli_query($con,"update package_type set due_date='$expires' where pt_id='$pt_id'") or die(mysqli_error($con));
	
	$current_date=date("Y-m-d");

	if($current_date==$expires)
	{
		mysqli_query($con,"update package_type set pm_id=1 where pt_id='$pt_id'") or die(mysqli_error($con));
		//echo "done";
		
		
		/*$date=date_create("$purchase_date");
		//echo "<b>Your Pack Expires On:&nbsp;";
		//echo "<b><p style='color:#e80505;'><font color='black'>Your Pack Expires On: </font>";
		date_add($date,date_interval_create_from_date_string("$days days"));
	$expires=date_format($date,"Y-m-d");
	//$expires=date_format($date,"Y-m-d");
	//echo $expires;
	echo"</p></b>";*/
//	mysqli_query($con,"update package_type set purchase_date='$expires' where pt_id='$pt_id'") or die(mysqli_error($con));
		
	}
}
?>

	
	</div>
	
	
</div>

 <table class="table table-striped table-bordered table-hover table-condensed">
 
  <div class="list-group table-responsive solid">
	<a href="personal_information.php" class="list-group-item">Update My Profile</a>
	<a href="album_photo.php" class="list-group-item">Create Album</a>
	<?php
	$query45 = "select * from package_type where uname='$uname'";
      $result45=mysqli_query($con,$query45);
//echo "<p style='color:red;'><b><h3><center>".$package_type."</center></h3></b></p>";

while($row=mysqli_fetch_array($result45))
{
	if(!isset($_POST["pm_id"]))
	$pm_id=$row["pm_id"];
}

	    if($pm_id>1)
		{
		echo "<a href='search_filter.php' class='list-group-item'>Matches For You</a>";
		}
	else
	{
		echo "<a href='free_search_filter.php' class='list-group-item'>Matches For You</a>";
	}
	?>
	
	<!--<a href="view_matches.php" class="list-group-item">Matches For You</a>-->
	<a href="people_interested_in_me.php" class="list-group-item">People Interested In Me</a>
	<a href="my_interest.php" class="list-group-item">My Interest(s)</a>
	<a href="m_send_admin.php" class="list-group-item">Message to Admin</a>
	<a href="m_received_messages.php" class="list-group-item">Inbox</a>
	<a href="m_sent_messages.php" class="list-group-item">Outbox</a>
	<a href="delete_profile.php" class="list-group-item">Delete Profile</a>
	
  </div>
  </table>
  

</html>
<?php
include "dbi.php";
$query = "select * from package_type where uname='$uname'";

//$skill=strtoupper($skill);
$result=mysqli_query($con,$query);

while($row=mysqli_fetch_array($result))
{
	if(!isset($_POST["pm_id"]))
	$pm_id=$row["pm_id"];
}

$query2 = "select * from package_master where pm_id='$pm_id'";

$result2=mysqli_query($con,$query2);
while($row=mysqli_fetch_array($result2))
{
	
	$package_type=$row["package_type"];
	echo "<p style='color:green; font-size:20px;'><b><h5><center><font color='#6600ff'><h2>You Are ".$package_type." Member</h2></font></center></h5></b></p>";
}

?>
<?php
include "footer.php";
?>
</body>
</html>