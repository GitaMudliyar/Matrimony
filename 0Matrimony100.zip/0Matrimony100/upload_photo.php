<?php
include "header.php";
require "dbi.php";
$db=new mysqli('localhost','websited_reshim','Reshim@123','websited_reshim_gathi');
//$db=new mysqli('localhost','root',"",'db_reshim_gathi');
?>
<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
}

table{
	width:95%;
}


</style>

<head>
	<meta charset="utf-8">
	<!-- Mobile Specific Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!-- Font-->
	<link rel="stylesheet" type="text/css" href="css/opensans-font.css">
	<link rel="stylesheet" type="text/css" href="fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">
	<!-- Main Style Css -->
    <link rel="stylesheet" href="css/style.css"/>
</head>
<body>

<?php 
//include "header.php"; 
//include "validate_member.php";

?>
<!--<form action="update_photo_upload.php" method="post">-->

<div class='table-responsive' >
<table border='0'>

<th>
    <!--
  <font color="navy">
<b><h4><a href="personal_information.php" id="aa"  class='btn active  btn-primary'   style="background-color:crimson";><span></span>
	<span></span><span></span><span></span>01 Personal Information&nbsp;
	</a></h4></b>
	<br>
	<h4><a href="profile_details.php" id="aa" class='btn active  btn-primary' style="background-color:crimson">02 Profile Details
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		
	<h4><a href="family_details.php" id="aa" class='btn active  btn-primary'style="background-color:crimson">03 Family Details
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
	
	<h4><a href="astro_details.php" id="aa" class='btn active  btn-primary'style="background-color:crimson">04 Astro Details
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>

	<h4><a href="education_and_career.php" id="aa" class='btn active  btn-primary'style="background-color:crimson">05 Education And Career</a></h4><br>

	<h4><a href="hobbies_and_traits.php" id="aa" class='btn active  btn-primary'style="background-color:crimson">06 Hobbies and Traits
	&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		<h4><a href="about_myself.php" id="aa" class='btn active  btn-primary'style="background-color:crimson"> 07 About Myself
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		
		<h4><a href="expectation.php" id="aa" class='btn active  btn-primary'style="background-color:crimson"> 08 My Expectations
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		
		<h4> <a href="upload_photo.php"id="aa" class='btn active  btn-primary'style="background-color:pink"><font color="navy">09 Upload Profile Photo</font>&nbsp;&nbsp;</a></h4><br>
    
	</font>
</th><th>-->
  
  		<?php
//include "dbi.php";

if(!empty($uname))
{
	$result = mysqli_query($con,"select * from profile_image where uname='$uname'");
}


?>


  
  <div class="column">
  
  <?php
/*$user="sanjay"; //you can fetch username here*/
//$db=new mysqli('localhost','root',"",'db_reshim_gathi');
if($db->connect_errno){
echo $db->connect_error;
}

$pull="select * from profile_image where uname='$uname'";
$allowedExts = array("jpg", "jpeg", "gif", "png","JPG");
$extension = @end(explode(".", $_FILES["file"]["name"]));
if(isset($_POST['pupload'])){
if ((($_FILES["file"]["type"] == "image/gif")
|| ($_FILES["file"]["type"] == "image/jpeg")
|| ($_FILES["file"]["type"] == "image/JPG")
|| ($_FILES["file"]["type"] == "image/png")
|| ($_FILES["file"]["type"] == "image/pjpeg"))
&& ($_FILES["file"]["size"] < 2097152)
&& in_array($extension, $allowedExts))
{
if ($_FILES["file"]["error"] > 0)
{
echo "Return Code: " . $_FILES["file"]["error"] . "<br>";
}
else
{
echo '<div class="plus">';
echo "<h3>Uploaded Successully</h3>";
echo '</div>';
/*echo"<br/><b><u>Image Details</u></b><br/>";

echo "Name: " . $_FILES["file"]["name"] . "<br/>";
echo "Type: " . $_FILES["file"]["type"] . "<br/>";
echo "Size: " . ceil(($_FILES["file"]["size"] / 1024)) . " KB";*/

if (file_exists("profile_pics/" . $_FILES["file"]["name"]))
{
unlink("profile_pics/" . $_FILES["file"]["name"]);
}
else{
$pic=$_FILES["file"]["name"];
$conv=explode(".",$pic);
//$ext=$conv['1'];
move_uploaded_file($_FILES["file"]["tmp_name"],"profile_pics/".$uname."."."png");
//echo "Stored in as: " . "profile_pics/".$uname.".".$ext;
$url=$uname."."."png";

$query="update profile_image set url='$url', lastUpload=now() where uname='$uname'";
if($upl=$db->query($query)){
echo "<h3>Saved to Database successfully</h3>";

}
}
}
}else{
echo "File Size Limit Crossed 1 MB Use Picture Size less than 1 MB";
}
}
?>
<form action="" method="post" enctype="multipart/form-data">
<div class="wizard-header">
									<h3 class="heading"><b>Profile Picture</b></h3>
								</div>
								
<?php
$res=$db->query($pull);
$pics=$res->fetch_assoc();
echo "<div class='imgLow'>";
echo "<a href='profile_pics/$pics[url]'><img src='profile_pics/$pics[url]' alt='profile picture' width='300' height='300' class='doubleborder'/></a>";
echo "</div>";

//echo "<h4><font color='maroon'><a href='member.php'>Back to Panel</a><font></h4>";

?><br>
<input type="file" name="file" />

<input type="submit" name="pupload" class="button" value="Upload"/>
<h4><a href='member.php'style="color:maroon">Back to Panel</a>
</form>
  
  
  
  
 
	<!---ppp
	<div class="wizard-header">
<h2>
			            	<p class="step-icon"><span>08</span></p>
			            	<span class="step-text">Upload Profile Photo</span>
			            </h2>
			            <section>
			                <div class="inner">
			                	<div class="wizard-header">
									
									<p>Please enter your infomation and proceed to the next step so we can build your accounts.</p>
								</div>
								<div class="form-row">
			                		
								

<center>
<label for="nameField">Profile Picture</label><br>

<a href="file_upload.php?uname=<?php //echo $uname; ?>"><img src="profile_pics/pic<?php //echo $uname; ?>.png" width="100px" height="100px"/></a>
</center>
</div>
									
									
			                	</div>
							</div><br>
		 
		 <input type="submit" name="submit" value="Save"  style="background-color:#2eb82e;"/>pppp-->
  </div>
</div>
<!--</form>--></th>
</body>
</html>
