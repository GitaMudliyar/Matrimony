<?php
include "header.php";
require "dbi.php";
?>
<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	<!--height:50px;-->
}

table{
	width:95%;
}


</style>

</style>
</head>

<head>
	<meta charset="utf-8">
	<!-- Mobile Specific Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!-- Font-->
	<link rel="stylesheet" type="text/css" href="css/opensans-font.css">
	<link rel="stylesheet" type="text/css" href="fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">
	<!-- Main Style Css -->
    <link rel="stylesheet" href="css/style.css"/>
</head>
<body>

<?php 
//include "header.php"; 
//include "validate_member.php";

?>
<form action="update_education_and_career.php" method="post">

<div class='table-responsive' >
<table border='0'>
  
  <th><!--
    <br>
  <font color="navy">
<b><h4><a href="personal_information.php" id="aa"  class='btn active  btn-primary'   style="background-color:crimson";><span></span>
	<span></span><span></span><span></span>01 Personal Information&nbsp;
	</a></h4></b>
	<br>
	<h4><a href="profile_details.php" id="aa" class='btn active  btn-primary' style="background-color:crimson">02 Profile Details
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		
	<h4><a href="family_details.php" id="aa" class='btn active  btn-primary'style="background-color:crimson">03 Family Details
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
	
	<h4><a href="astro_details.php" id="aa" class='btn active  btn-primary'style="background-color:crimson">04 Astro Details
	&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>

	<h4><a href="education_and_career.php" id="aa" class='btn active  btn-primary'style="background-color:pink"><font color="navy">05 Education And Career</font></a></h4><br>

	<h4><a href="hobbies_and_traits.php" id="aa" class='btn active  btn-primary'style="background-color:crimson">06 Hobbies and Traits
	&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		<h4><a href="about_myself.php" id="aa" class='btn active  btn-primary'style="background-color:crimson"> 07 About Myself
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		
		<h4><a href="expectation.php" id="aa" class='btn active  btn-primary'style="background-color:crimson"> 08 My Expectations
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a></h4><br>
		
		<h4> <a href="upload_photo.php"id="aa" class='btn active  btn-primary'style="background-color:crimson">09 Upload Profile Photo&nbsp;&nbsp;</a></h4><br>
    
	</font>
	
	
  </th><th>-->
  
  		<?php
//include "dbi.php";

if(!empty($uname))
{
	$result = mysqli_query($con,"select * from education_and_career where uname='$uname'");

	if($row=mysqli_fetch_array($result))
	{
		

$e_educational_level=$row["e_educational_level"];
$e_educational_field=$row["e_educational_field"];
$e_annual_income=$row["e_annual_income"];
$e_family_status=$row["e_family_status"];




	}
	else
	{
		$e_educational_level="";
$e_educational_field="";
$e_annual_income="";
$e_family_status="";
	}

}


?>
  
<!--   <div class="column">
 <!--   <h2>Column 2</h2>
    <p>Some text..</p>-->
	
	<div class="wizard-header">
<h2>
			            	
			            	<!--<span class="step-text">Educational and Career</span>-->
			            </h2>
			                	<div class="wizard-header">
									<h3 class="heading"><b>Educational and Career</b></h3>
									<p>Please enter your infomation and proceed to the next step so we can build your accounts.</p>
								</div>
								
			                		 <div class="form-row">
									<div class="form-holder form-holder-2">
										
											<legend>Education Level:</legend>
											<select name="e_educational_level" class="form-control text">
			 <option value="Select">SELECT</option>
	<option value="Bachelors">Bachelors</option>
	<option value="Masters">Masters</option>
	<option value="Doctorate">Doctorate</option>
	<option value="Diploma">Diploma</option>
	<option value="Undergraduate">Undergraduate</option>
	<option value="Associates Degree">Associates Degree</option>
	<option value="Honours Degree">Honours Degree</option>
	<option value="Trade School">Trade School</option>
	<option value="Occasionally">High School</option>
	<option value="High School">Less than high school </option>
	<option value="Graduate">Graduate</option>
	
  </select>
                                        
                                    
                                    
	</div>
	</div>
	
	
	<div class="form-row">
							
	<div class="form-holder form-holder-2">
										
											<legend>Education Field:</legend>
											<select name="e_educational_field" class="form-control text">
			 <option value="Select">SELECT</option>
	<option value="Advertising/Marketing">Advertising/Marketing</option>
	<option value="Administrative Services">Administrative Services</option>
	<option value="Architecture">Architecture</option>
	<option value="Armed Forces">Armed Forces</option>
	<option value="Arts">Arts</option>
	<option value="Commerce">Commerce</option>
	<option value="Computers/IT">Computers/IT</option>
	<option value="Education">Education</option>
	<option value="Engineering/Technology">Engineering/Technology</option>
    <option value="Fashion">Fashion</option>
	<option value="Finance">Finance</option>
	<option value="Fine Arts">Fine Arts</option>
	<option value="Home Science">Home Science</option>
	<option value="Law">Law</option>
	<option value="Management">Management</option>
	<option value="Science">Science</option>

</select>

                                </div>
                                
                           </div>
						   
						   <div class="form-row">
									<div class="form-holder form-holder-2">
										<fieldset>
											<legend>Annual Income:</legend>
											<input type="text" class="form-control" id="Annual Income" name="e_annual_income" placeholder="ANNUAL INCOME " required>
										</fieldset>
									</div>
									</div>
									
							<div class="form-row">
									<div class="form-holder form-holder-2">
										
											<legend>Family Status:</legend>
											<select name="e_family_status" class="form-control text">
											<option value="Select">SELECT</option>
											<option value="Poor">Poor</option>
											<option value="Rich">Rich</option>
											
											 <option value="Upper Middle Class">Upper Middle Class</option>
	                                 <option value="Middle Class">Middle Class</option>
	                                  </select>
									  
									  </div>
									  </div>	
							</div>		 <br>
							
							<a href=' personal_information.php' class='btn active  btn-primary' style='background-color:green';>Previous</font></a>
&nbsp;&nbsp;&nbsp;

<input type="submit" name="submit"  class='btn active  btn-danger' value="Save and Next"  style="background-color:blue;"/>
	</th>	 
		 <!--<input type="submit" name="submit" value="Save and Next"  style="background-color:#2eb82e;"/>-->
  </div>
</div></th>
</form>
</body>
</html>
