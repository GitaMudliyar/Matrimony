<?php
include "header.php";
?>
<style>
body{
	background-image: url("images/nb.jpg");
	 background-size: cover;
}

</style>

<script>
function myFunction(x) {
  x.style.background = "GreenYellow";
}
</script>


<script type="text/javascript">
    function blockSpecialChar(e){
        var k;
        document.all ? k = e.keyCode : k = e.which;
        return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57));
        }
    </script>

<body>
<div class="panel panel-primary" style="max-width:300px;margin:auto">
		<div class="panel-heading">
			Please Login
		</div>

		<div class="panel-body panel-center">
	<form class="form" action="act_login.php" method="post">		


<div class="form-group">
<label for="nameField">UserName</label>
<input type="text" class="form-control input-sm" name="uname"   onkeypress="return blockSpecialChar(event)" required placeholder="User Name" />

</div>

<div class="form-group">
<label for="emailField">Password</label>
<input type="password" class="form-control" name="pwd" required placeholder="Password" />
</div>



<?php
//echo(rand(0,10));
//echo "";
$n1=(rand(0,9));
$n2=(rand(0,9));
echo "<h2><b><i>Captcha</i></b><h2>";
echo "<h4>$n1 + $n2";

$n3=$n1+$n2;

//echo "<br><br>Result is $n3";
?>

<a href='login.php' class='btn btn-primary' style="background-color:#696969">Refresh</a>

</h4>
<input type="text" class="form-control" id="box" name="captcha" required placeholder="Enter Result of Captcha" onfocus="myFunction(this)" />
<input type="hidden"  value="<?php echo $n3;?>" name="n3" />
<br>

<?php 

   /* $captcha = $_GET["captcha"];
	echo $ca
	if($n3==$captcha)
		echo "<input type='submit' class='btn btn-primary btn-block' value='Login' /> ";
	else
		echo "Invalid Captcha";*/
	?>
	
<input type="submit" class="btn btn-primary btn-block" value="Login" /> 
</form>
		</div>
		
		<div class="panel-footer text-center">
			
<a href="registration.php">Register Member</a><br>
<a href="forgot_password.php">Forgot Password?</a>

		</div>

	</div>

</body>

<?php
include "footer.php";
?>
