<?php
include "header.php";
require "dbi.php";



$from=$_POST["m_nm"];
//$to=$_POST["nm"];
$f_uname=$_POST["uname"];

$t_uname=$_POST["uname"];
$mdate=$_POST["mdate"];
$subject=$_POST["subject"];
$contents=$_POST["contents"];
//$sid=$_POST["sid"];
//$sk=$_POST["sk"];



//echo "$to";
$query="insert into message(f_uname,from_u,t_uname,to_u,mdate,subject,contents) values('$f_uname','$from','ad','Admin','$mdate','$subject','$contents')";
//echo "$query";




mysqli_query($con,$query) or die(mysqli_error($con));
if(mysqli_affected_rows($con) > 0)
{
	
	echo "<div class='well text-center'><h2 style='color:green'>Success: Message Sent!</h2>";
	echo "<div class='well text-center'><h3 style='color:navy'>Our Admin will Contact You Soon!</h3>";
	echo "<p><a href='member.php'>Back To Panel</a></p></div>";
	
}

?>