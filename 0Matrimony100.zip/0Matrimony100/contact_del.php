<?php
include "header.php";
require "dbi.php";
?>
<?php
//include "header.php";
$cid= $_GET["cid"];
$name=$_GET["name"];

//require "dbi.php";
$query="select * from contact_us where cid=$cid";

$result=mysqli_query($con,$query) or die(mysqli_error($con));

//	echo "<center><h2 style='color:red'>Products Exist. Cannot Delete Category</h2></center>";
	//echo "<p><a href='admin.php'>Back</a></p></center>";


?>
<html>
<body>
<center>
<p><a href='contact_select.php'>Back</a></p>

<form action="contact_delete.php" method="post">

<?php
	echo "<h2 style='color:maroon'>Delete Contact:$name @ CID: $cid</h2>";
	echo "<h2>Are You Sure?</h2>";

?>

<input type="hidden" name="cid" value="<?php echo $cid; ?>" />


<input type="submit"  value="Confirm Delete"/>

</form>
</center>
</body>
</html>