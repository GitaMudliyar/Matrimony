<?php
include "header.php";
require "dbi.php";
?>
<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}

tr:hover{
	background-color:FloralWhite;
}

table{
	width:95%;
}

</style>



<?php
//include "header.php";
//require "dbi.php";


$uname=$_SESSION["uname"];
?>

<head>
<style> 
#myDIV {

  background: red;
  animation: mymove 5s infinite;
}

@keyframes mymove {
  from {background-color:LavenderBlush;}
  to {background-color:LightCyan;}
}
</style>
</head>
<body>


</body>
<?php
$query="select DISTINCT f_uname, from_u from message where t_uname='$uname' and f_status=1 and t_status=1 ";

//echo $query;

$result = mysqli_query($con,$query) or die(mysqli_error($con));

echo "<div id='myDIV'>";
echo "<center>";
echo "<h1><strong>Blocked List<strong></h1>";
$cnt=0;
//echo "<p><a href='new_package.php'>New Package</a></p>";

echo '<div class="table-responsive">';
echo '<table border>';
echo "<tr bgcolor='DeepPink'><th><center>Sr. No.</center></th><th><center>Name</center></th>";



while($row=mysqli_fetch_array($result))
{
	$cnt++;
	$f_uname=$row["f_uname"];
	$from_u=$row["from_u"];
	
	echo "<tr>";
	echo "<td align='center'>$cnt</td>";
	echo "<td>&nbsp;".$row["from_u"]." ".$row["f_uname"]. "</td>";
	
	/*echo "<td>";

	echo "&nbsp;<a href='view_member_package_list.php?pm_id=$pm_id&package_type=$package_type'>Members</a>";
	echo "</td>";*/


	/*echo "<th>";
	echo '<a href="file_upload_home.php?sid=<?php echo $sid; ?>"><img src="home_pics/pic<?php echo $sid; ?>.png" width="50px" height="50px"/></a>';
	echo "</th>";*/
	echo "</tr>";
}
echo "<h3 style='color: #009900'><b>$cnt Records Found</b></h3>";
echo "</table></div>";
echo "<br><br></div>";
echo "<p><a href='member.php'></a></p>";

echo "<center>";

mysqli_close($con);
?>