<?php
include "header.php";
require "dbi.php";
?>
<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}

tr:hover{
	background-color:FloralWhite;
}
th{
	background-color:#e6005c;
	color:white;
}

table{
	width:95%;
}

</style>
<?php
//include "header.php";
//require "dbi.php";

$query2="select * from delete_profile where delete_for='Found My Partner From ReshimGathi' ";

//echo $uname;

$result2 =mysqli_query($con,$query2) or die(mysqli_error($con));


echo "<center>";

echo "<p><b><h3>Story</h3></b></p>";

echo '<div class="table-responsive">';
echo "<table border='1'>";
echo "<tr bgcolor='ChartReuse'><th><center>Sr. No.</center></th><th><center>Image</center></th><th><center>User Name</center></th>";
echo "<th><center>Partner Name</center></th><th><center>Story</center></th><th><center>More </center></th>";
echo "<th><center>Display on Site </center></th></tr>";

$cnt=0;

while($row=mysqli_fetch_array($result2))
{
	//$cnt++;
	$uname=$row["uname"];



$query="select * from share_story where uname='$uname'";

//echo $uname;

$result = mysqli_query($con,$query) or die(mysqli_error($con));

	
while($row=mysqli_fetch_array($result))
{
	$cnt++;
	$partner_name=$row["partner_name"];

	echo "<tr>";
	
	echo "<td align='center'>$cnt</td>";
	echo "<td><a href='share_story_pics/pic$uname.png'><img src='share_story_pics/pic$uname.png' height='100px' width='100px' /></a></td>";
	echo "<td>&nbsp;".$row["uname"]."</td>";
	echo "<td>&nbsp;".$row["partner_name"]."</td>";
	
	echo "<td>&nbsp;".$row["share_your_story"]."</td>";
	//echo "<td>&nbsp;".$row["contents"]."</td>";
	 echo "<td ><a href='view_temp_read_more.php?uname=$uname' class='btn active  btn-warning' style='background-color:LawnGreen; color:black;'>Read More</a></td>";
 
 echo "<td ><a href='add_success_story.php?uname=$uname&partner_name=$partner_name' class='btn active  btn-warning' style='background-color:Cyan; color:black;'>Add</a>";
 echo "<a href='remove_success_story.php?uname=$uname&partner_name=$partner_name' class='btn active  btn-warning' style='background-color:darkCyan'>Remove</a></td>";
 

	//echo "<td>";
		
	echo "</tr>";
}
}
echo "<h3 style='color:navy'> $cnt Record(s) Found </h3>";
echo "</table></div>";
echo "<br><p><a href='admin.php'>Back to Panel</a></p>";

echo "<center>";

mysqli_close($con);
?>