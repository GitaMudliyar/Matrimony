<?php
include "header.php";   // session started in header file - session_start();
include "dbi.php";
$uname=$_POST["uname"];
$phone=$_POST["phone"];
$e_email=$_POST["e_email"];


$query = "select * from personal_information where uname='$uname' and phone='$phone' and e_email='$e_email'"; 
$result=mysqli_query($con,$query);

while($row=mysqli_fetch_array($result))
{
	//$cnt++;
	$uname=$row["uname"];
	//$nm = $row["fname"]." ".$row["lname"];
	$e_email=$row["e_email"];
	$phone=$row["phone"];

}
if(mysqli_affected_rows($con) > 0)
{
	//header("location:change_password.php");
   echo "<div class='well text-center'><h3 style='color:green'>Done</h3>";	
   echo "<div class='well text-center'><a href='change_password.php?uname=$uname'> <h2 style='color:navy'>Click Here... To Change New Password</h2></a></div></div>";

}
else
{
   echo "<div class='well text-center'><h3 style='color:red'>Invalid Credentials</h3>";
   echo "<div class='well text-center'><a href='forgot_password.php'> <h2 style='color:blue'>Back</h2></a></div></div>";
	
}


	 ?>      

		  