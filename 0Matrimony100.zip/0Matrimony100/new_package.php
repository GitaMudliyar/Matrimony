<?php
include "header.php";
//require "dbi.php";
?>
<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}

tr:hover{
	background-color:FloralWhite;
}

table{
	width:95%;
}

</style>


<?php
//include "header.php"
?>

<html>
<body>
<center>
<p><a href='package_list.php'>Back to List</a></p>


<form action="insert_package.php" method="post">
<div class="table-responsive">
<table border>
<tr bgcolor="DeepPInk"><td colspan="2" align='center'>
NEW PACKAGE
</td></tr>
<tr>
<td>Enter Package:-</td>
<td><input type="text" name="package_type" /></td></tr>

<tr>
<td>Enter Price:-</td>
<td><input type="text" name="price" /></td></tr>

<tr>
<td>Enter Percentage of Discount:-</td>
<td><input type="text" name="discount" /></td></tr>

<tr>
<td>Enter Duration Period:-</td>
<td><input type="number" name="duration" /></td></tr>

<tr>
<td>Enter Chat Limit:-</td>
<td><input type="text" name="chat_limit" /></td></tr>

<tr bgcolor='Thistle'><td colspan="2" align='center'>
<input type="submit"  value="Add PACKAGE"/>
</td>
</tr>
</table></div>
</form>
</center>
</body>
</html>