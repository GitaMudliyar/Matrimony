<?php
include "header.php";
require "dbi.php";

$cid=$_POST["cid"];
$name=$_POST["name"];
$e_mail=$_POST["e_mail"];
$u_date=date("Y-m-d");
$subject=$_POST["subject"];
$message=$_POST["message"];

//$name=$fname+$lname;

$query="insert into contact_us(cid,name,e_mail,u_date,subject,message) values('$cid','$name','$e_mail','$u_date','$subject','$message' )";

mysqli_query($con,$query) or die(mysqli_error($con));

if(mysqli_affected_rows($con) > 0)
{
	header("location:contact_us_success.php");
}

?>