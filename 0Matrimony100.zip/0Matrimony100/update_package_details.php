<?php
include "header.php";
require "dbi.php";

$pm_id=$_POST["pm_id"];
//$service_type=$_POST["service_type"];
$uname=$_POST["uname"];
$m_nm=$_POST["m_nm"];
$purchase_date=date('Y-m-d');

$query="update package_type set pm_id='$pm_id',m_nm='$m_nm',purchase_date='$purchase_date' where uname='$uname'";

mysqli_query($con,$query) or die(mysqli_error($con));

if(mysqli_affected_rows($con) > 0)
{
	echo "<div class='well text-center'><h2 style='color:navy'><p><a href='member.php'>Back</a></p></div>";
	echo "<div class='well text-center'><h2 style='color:green'>Success!</h2>";
	echo "<div class='well text-center'><h3 style='color:maroon'>Now You Can View Fantastic Matches</h3>";
	//echo "<p><a href='worker_work_details.php'>Click Here</a></p></div>";

}

?>
<!--	header("location:worker_work_details.php");-->