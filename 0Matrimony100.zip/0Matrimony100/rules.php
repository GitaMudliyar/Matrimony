<?php
include "header.php";
//require "dbi.php";
?>

<!DOCTYPE html>

<?php
//include "header.php";
?>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Rules</title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link href="css/styles.css" rel="stylesheet">
</head>
<style>
body{

background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;
<!--background-color:#bb99ff;-->

 margin:0; padding:0; height:100%; width:100%;
 font-family:"Comic sans MS";
font-size:18px;
background-image:url('images/nb3.jpg');
}

</style>
<body><font color="black">
<center><b><h1> Rules </h1></b></center>
<p>
         &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		 By the advisory, the websites will need to confirm the “user’s intent to enter into a 
matrimonial alliance” and “confirm that the user information is correct to the best of his or her 
knowledge”</p>
		 

 
<p> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
“The ministry had received a number of complaints on matrimonial sites being used to dupe 
prospective brides and grooms, used for illegal activities related to certain rackets being run,
 as well as other problems," explained a senior ministry official. “Matrimonial websites are an
 intermediary under Section 2 of the IT Act and (have) to follow the Act.” By the advisory, the
 websites will need to confirm the “user’s intent to enter into a matrimonial alliance” and 
 “confirm that the user information is correct to the best of his or her knowledge” when they
 register to join.</p>

<p> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;“Though we are still in the process of setting all the guidelines, we might ask sites to make 
use of government identification papers such as Aadhaar, passport details or driving licence 
details mandatory,” added the official.</p>

<p> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;With this coming in place, users will be required to upload true copies of supporting documents
 such as proof of identity and address. “It is advisable that matrimonial websites should provide
 a list of legally verifiable documents (on) proof of identity,” the advisory says.</p>

<p> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Users will also be required to confirm their intent. "We want to ensure that there are no 
websites, portals or apps which are operating as dating sites in the garb of matrimonial 
websites,” added the official. Service providers need to make a declaration that their 
website is strictly for matrimony. Also after receiving complaints of obscene photos on 
these portals, the ministry said a vetting process would ne needed to prevent this. Under 
the new rules, websites will be required to name a grievances redressal officer on their 
portals.</p>
</font>

<script src="js/jquery.js"></script>
<script src="js/bootstrap.js"></script>
</body>
</html>