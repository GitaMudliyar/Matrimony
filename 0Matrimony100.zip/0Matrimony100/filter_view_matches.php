<?php
include "header.php";
require "dbi.php";
?>
<style>
th,td{
	background-color:#FFEFD5;
	padding:15px;
	text-align:left;
	border-bottom:1px solid Darkgray;
	height:50px;
	text-align:center;
	
}

tr:hover{
	background-color:FloralWhite;
}

table{
	background-color:#FFD700;
	width:95%;
}

</style>


<?php
//include "header.php";
//require "dbi.php";
 $uname=$_SESSION['uname'];
 //print_r($_SESSION);
$username = $_SESSION['uname'];
 $gender = mysqli_fetch_object(mysqli_query($con, "SELECT * FROM profile_details WHERE uname = '$username'"))->gender;
// echo $gender;




$query45 = "select * from package_type where uname='$uname'";
//$pm_id = $_POST["pm_id"];
//$package_type = $_GET["package_type"];
//$query = "select * from package_type where pm_id='$pm_id'";
//echo $query;

//$skill=strtoupper($skill);
$result45=mysqli_query($con,$query45);
//echo "<p style='color:red;'><b><h3><center>".$package_type."</center></h3></b></p>";

while($row=mysqli_fetch_array($result45))
{
	if(!isset($_POST["pm_id"]))
	$pm_id=$row["pm_id"];
}
/*echo $pm_id;

$query46 = "select * from package_master where pm_id <= '$pm_id'";
echo $query46;
*/


$filter = isset($_POST["filter"])?$_POST["filter"]:"";
$btn = isset($_POST["btn"])?$_POST["btn"]:"";

if(empty($filter) || $btn=="Show All")
{
	$cnt=0;

	$query11="select * from view_profile_match where gender<>'$gender'  order by uid";
	$result11 = mysqli_query($con,$query11) or die(mysqli_error($con));
	$filter="";
	
	echo "<center>";
		
	//$cnt=0;

//echo "<p><a href='new_cat.php'>New Category</a></p>";
echo "<div class='table-responsive'>";
echo "<table>";
	
		while($row=mysqli_fetch_array($result11))
		{
			$cnt++;
			//$id=$row["cpid"];
			$uname=$row["uname"];
			$fname=$row["fname"];
			$lname=$row["lname"];
			//$gender=$row["gender"];
			$dob=$row["dob"];
			$height=$row["height"];
			$city=$row["city"];
			$manglik=$row["manglik"];
			$caste=$row["caste"];
			$annual_income=$row["annual_income"];
			$t_nm = $row["fname"]." ".$row["lname"];
			
//echo "$fname $lname";

			echo "<tr>";
			echo "<font color='white'>";
	
				echo "<td>";
				echo "<a href='profile_pics/pic$uname.png'><img src='profile_pics/pic$uname.png' height='200px' width='200px' /></a>";
		
	
			echo "</td>";
	
	echo "<td style='text-align:right'>Name&nbsp;&nbsp;<br>Gender&nbsp;&nbsp;<br>DOB&nbsp;&nbsp;<br>Height&nbsp;&nbsp;<br>City&nbsp;&nbsp;<br>Manglik&nbsp;&nbsp;<br>Caste&nbsp;&nbsp;<br>Annual Income&nbsp;&nbsp;<br></td>";
	echo "<td style='text-align:left'>".$row["fname"]." ".$row["lname"]."<br>".$row["gender"]."<br>".$row["dob"]."<br>".$row["height"]."</br>".$row["city"]."</br>".$row["manglik"]."</br>".$row["caste"]."</br>".$row["annual_income"]."</br></td>";
	
	    echo "<td >&nbsp;<a href='view_read_more.php?uname=$uname' class='btn active  btn-warning'>Read More</a>";
		echo "&nbsp;&nbsp;&nbsp;<a href='send_interest.php?uname=$uname' class='btn active  btn-primary'>Interested</a>";
		echo "&nbsp;&nbsp;&nbsp;<a href='m_send_message_m.php?uname=$uname&t_nm=$t_nm' class='btn active  btn-primary' style='background-color:#2eb82e';>Send Message</font></a>";
		 
	
	echo "</td></tr>";	
	
		}

//echo $cnt;	
echo "<div><font color='deepPink'><h2 style='color:crimson'>$cnt Profile Match Your Requirements</font></h2>";	

}

else
{
	
	
	$query11="select * from view_profile_match where caste like '%$filter%' and gender<> '$gender'  order by uid";
}

//$res1 =mysqli_query($con,$query11) or die(mysqli_error($con));
$result11 = mysqli_query($con,$query11) or die(mysqli_error($con));
//echo $cnt;	
//$res=mysqli_fetch_assoc($result11);
//$res1=print_r($res);

		//echo "<div><font color='deepPink'><h2 style='color:crimson'>$cnt Profile Match Your Requirements</font></h2>";

echo "<center>";


?>

<p>
<form action="view_matches.php" method="post">
<center> <font color="maroon">
Search Caste : <input type="text" name="filter" value="<?php echo $filter; ?>" /> 
<input type="submit" value="Filter" name="btn" />
<input type="submit" value="Show All" name="btn" /></font>
<!--<a href="view_all_matches.php" class='btn btn-primary'>Show All</a>-->
</center>
</form>
</p>








<?php 
 if ($gender){
$query1="select * from view_profile_match where gender<>'$gender' AND caste like '$filter' and pm_id<='$pm_id' order by uid  ";

$result1 = mysqli_query($con,$query1) or die(mysqli_error($con));

echo "<center>";

//echo "<p><a href='new_cat.php'>New Category</a></p>";
echo "<div class='table-responsive'>";
echo "<table>";
$cnt=0;
	while($row=mysqli_fetch_array($result1))
	{
		while($row=mysqli_fetch_array($result11))
		{
			$cnt++;
			//$id=$row["cpid"];
			$uname=$row["uname"];
			$fname=$row["fname"];
			$lname=$row["lname"];
			//$gender=$row["gender"];
			$dob=$row["dob"];
			$height=$row["height"];
			$city=$row["city"];
			$manglik=$row["manglik"];
			$caste=$row["caste"];
			$annual_income=$row["annual_income"];

			echo "<tr>";
			echo "<font color='white'>";

				echo "<td>";
				echo "<a href='profile_pics/pic$uname.png'><img src='profile_pics/pic$uname.png' height='200px' width='200px' /></a>";
		
	
			echo "</td>";
	
	echo "<td style='text-align:right'>Name&nbsp;&nbsp;<br>Gender&nbsp;&nbsp;<br>DOB&nbsp;&nbsp;<br>Height&nbsp;&nbsp;<br>City&nbsp;&nbsp;<br>Manglik&nbsp;&nbsp;<br>Caste&nbsp;&nbsp;<br>Annual Income&nbsp;&nbsp;<br></td>";
	echo "<td style='text-align:left'>".$row["fname"]." ".$row["lname"]."<br>".$row["gender"]."<br>".$row["dob"]."<br>".$row["height"]."</br>".$row["city"]."</br>".$row["manglik"]."</br>".$row["caste"]."</br>".$row["annual_income"]."</br></td>";
	
	    echo "<td >&nbsp;<a href='view_read_more.php?uname=$uname' class='btn active  btn-warning'>Read More</a>";
		 echo "&nbsp;&nbsp;&nbsp;<a href='send_interest.php?uname=$uname' class='btn active  btn-primary'>Interested</a>";
	
	echo "</td></tr>";
	
		}
		
	}
//echo $cnt."hi";
echo "<div><font color='deepPink'><h2 style='color:crimson'>$cnt Profile Match Your Requirements</font></h2>";
}
else 
{
	
	
	$query2="select * from view_profile_match where gender like 'female' AND caste like '$res1' and pm_id<='$pm_id'  order by uid";

$result2 = mysqli_query($con,$query2) or die(mysqli_error($con));

echo "<center>";


echo "<div class='table-responsive'>";
echo "<table>";

while($row=mysqli_fetch_array($result2))
{
	while($row=mysqli_fetch_array($result11))
{
	
	
	$uname=$row["uname"];
	$fname=$row["fname"];
	$lname=$row["lname"];
	
	$dob=$row["dob"];
	$height=$row["height"];
	$city=$row["city"];
	$manglik=$row["manglik"];
	$caste=$row["caste"];
	$annual_income=$row["annual_income"];

	echo "<tr>";
	echo "<font color='white'>";
	//echo "<td align='center'>$cnt</td>";
		echo "<td>";
	echo "<a href='file_upload.php?uname=$uname'><img src='profile_pics/pic$uname.png' width='150px' width='150px'  /></a>";

	echo "</td>";
	
	echo "<td style='text-align:right'>Name&nbsp;&nbsp;<br>Gender&nbsp;&nbsp;<br>DOB&nbsp;&nbsp;<br>Height&nbsp;&nbsp;<br>City&nbsp;&nbsp;<br>Manglik&nbsp;&nbsp;<br>Caste&nbsp;&nbsp;<br>Annual Income&nbsp;&nbsp;<br></td>";
	echo "<td style='text-align:left'>".$row["fname"]." ".$row["lname"]."<br>".$row["gender"]."<br>".$row["dob"]."<br>".$row["height"]."</br>".$row["city"]."</br>".$row["manglik"]."</br>".$row["caste"]."</br>".$row["annual_income"]."</br></td>";
	
	    echo "<td>&nbsp;<a href='view_read_more.php?uname=$uname' class='btn active  btn-warning'>Read More</a>";
	
	  echo "&nbsp;&nbsp;&nbsp;<a href='send_interest.php?uname=$uname' class='btn active  btn-primary'> More</a>";
	echo "</td></tr>";
	}
}
	
}


 
echo "</table>";
echo "</div>";


echo "<br>";
echo "<p><a href='member.php' class='btn btn-danger btn-block'>Back To Panel</a></p>";

echo "<center>";

mysqli_close($con);
include "footer.php";
?>
