<?php
include "header.php";
require "dbi.php";
?>
<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}

tr:hover{
	background-color:FloralWhite;
}
th{
	background-color:#F52887;
}

table{
	width:95%;
}

</style>


<?php
//$fid=$_POST["fid"];
//$name=$_POST["name"];
//$e_mail=$_POST["e_mail"];
//$u_date=date("Y-m-d");
//$comments=$_POST["comments"];

//include "dbi.php";
//include "header.php";


$query="select * from contact_us";

$result = mysqli_query($con,$query) or die(mysqli_error($con));
echo "<center>";

echo "<p><a href='admin.php' class='btn btn-primary'>Back To Panel</a></p>";

//$total = mysqli_num_rows($result);

//echo "<h3>".strtoupper($cn).": $total Product(s)</h3>";
echo "<div class='table-responsive' >";
echo "<table border='1'>";
echo "<tr bgcolor='gold'><th><center>Sr.No.</center></th><th><center>Name</center></th><th><center>E-mail</center></th>";
echo "<th><center>Received On</center></th><th><center>Subject</th><th><center>Message</th><th><center>Delete</center></th></tr>";

$cnt=0;

while($row=mysqli_fetch_array($result))
{
	$cnt++;
	$cid=$row["cid"];
	$name=$row["name"];

	echo "<tr>";
	echo "<td align='center'>$cnt</td>";
	echo "<td>&nbsp;".$row["name"]." ";

	echo "<td>&nbsp;".$row["e_mail"]."</td>";
	echo "<td>&nbsp;".$row["u_date"]."</td>";
		echo "<td>&nbsp;".$row["subject"]."</td>";
		echo "<td>&nbsp;".$row["message"]."</td>";
	echo "<td>";
	echo "&nbsp";
	//echo "<a href='feedback_del.php?fid=$fid'>Delete</a></td>";
	echo "<a href='contact_del.php?cid=$cid&name=$name' class='btn active  btn-warning'";
	echo "style='background-color:SeaShell; color:black'>Delete</a></td>";
	echo "</tr>";
}

echo "</table></div></center>";

mysqli_close($con);
include "footer.php";
?>