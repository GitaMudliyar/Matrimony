<?php
include "header.php";
require "dbi.php";
?>
<?php
//include "header.php";

//include "validate_worker.php";
?>
<style>
body{
	margin: 0;
	padding: 0;
	background : url(pic1.jpg); 
	background-size: cover;
	background-position: center;
	font-family: sans-serif;
}
</style>

<div class="panel panel-primary" style="max-width:300px;margin:auto">
		<div class="panel-heading">
			SEND MESSAGE
		</div>

		<div class="panel-body panel-center">
		<?php
//include "dbi.php";
//$from_u=$_GET["w_uname"];
//$sid=$_GET["sid"];
///$nm=$_GET["nm"];
$pm_id=$_GET["pm_id"];
$udt=date('Y-m-d');
$t_uname=$_GET["uname"];
$t_nm=$_GET["t_nm"];
///$t_uname=$_GET["w_nm"];



$query = "select * from personal_information where uname='$uname'";
$result = mysqli_query($con,$query) or die(mysqli_error($con));

while($row=mysqli_fetch_array($result))
{
	$m_nm = $row["fname"]." ".$row["lname"];
	
}

?>

<form class="form" action="insert_message_m_to_m.php" method="post">		

<div class="form-group">
<label for="nameField">Date</label>
<input type="text" readonly class="form-control input-sm" name="mdate" value="<?php echo $udt;?>" />
</div>

<input type="hidden"  value="<?php echo $m_nm;?>" name="m_nm"/>
<input type="hidden"  value="<?php echo $uname;?>" name="uname"/>
<input type="hidden"  value="<?php echo $t_uname;?>" name="t_uname"/>
<input type="hidden"  value="<?php echo $t_nm;?>" name="t_nm"/>
<input type="hidden"  value="<?php echo $pm_id;?>" name="pm_id"/>


<div class="form-group">
<label for="nameField">From</label>
<input type="text" class="form-control input-sm" readonly value="<?php echo $m_nm;?>" placeholder="Worker Name" />
</div>

<!--<div class="form-group">
<label for="nameField">To User Name</label>
<input type="text" class="form-control input-sm" readonly value="<?php echo $t_uname;?>" placeholder="Worker Name" />
</div>-->


<div class="form-group">
<label for="nameField">To</label>
<input type="text" class="form-control input-sm" readonly value="<?php echo $t_nm;?>" placeholder="Worker Name" />
</div>

<!--<input type="hidden" class="form-control input-sm" name="sid" />-->

<div class="form-group">
<label for="nameField">Subject</label>
<input type="text" class="form-control input-sm" name="subject" placeholder="Subject" />
</div>

<div class="form-group">
<label for="nameField">Contents</label>
<textarea class="form-control input-sm" rows="4" cols="50"  name="contents" placeholder="Body of Message"></textarea>
</div>


<input type="submit" class="btn btn-success btn-block" value="Send" /> 
<!--<a href="insert_message_m_to_admin.php?uname=$uname&m_nm=$m_nm"> Send </a>-->
</form>
		</div>

		<div class="panel-footer text-center">
<?php			
echo "<a href='member.php'>Back To Panel</a>";
?>
		</div>

	</div>


<?php
include "footer.php";
?>