<?php
include "header.php";   // session started in header file - session_start();
include "dbi.php";

$h_describe=$_POST["h_describe"];
$h_activities=$_POST["h_activities"];

mysqli_query($con,"update hobbies_and_traits set h_describe='$h_describe',h_activities='$h_activities' where uname='$uname'") or die(mysqli_error($con));
if(mysqli_affected_rows($con) > 0)
{
	//echo "<div class='well text-center'><h2 style='color:green'>Success: Hobbies And Traits Updated!</h2>";
	//echo "<p><a href='about_myself.php'>Back To Panel</a></p></div>";
	header("location:about_myself.php");	
	
}


//include "footer.php";
?>