<?php
include "header.php";
//require "dbi.php";
?>
<!DOCTYPE html>

<?php
//include "header.php";
?>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Succesful Matches</title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link href="css/styles.css" rel="stylesheet">
</head>
<style>
body{
background-image:url('images/back10.jpg');
background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;

}
h1{
<!--background-color:floralWhite;-->
}
img
{
	border-radius:20%;
	border: 5px solid navy;
}
</style>
<body>

<center><h1><b> Our Successful Stories</b></h1></center>
<div class="container">
  <div class="row">
	<div class="col-xs-3">
		<div class="thumbnail">
		<img src="./images/p1.jpg" height="600px" width="400px">
			<div class="caption">
				<h3>Pritam Weds Smita</h3>
				<p><a href="successful_act_p1.php" class="btn btn-primary">Read More</a></p>
			
			</div>
		</div>
	</div>
	<div class="col-xs-3">
		<div class="thumbnail">
		<img src="./images/p2.jpg" height="800px" width="600px"> 
			<div class="caption">
				<h3>Bhimsen Weds Nayra</h3>
			
				<p><a href="successful_act_p2.php" class="btn btn-primary">Read More</a></p>
			</div>
		</div>
	</div>
	<div class="col-xs-3">
		<div class="thumbnail">
		<img src="./images/p3.jpg"height="600px" width="400px">
			<div class="caption">
				<h3>Harshad Weds Sneha</h3>
				
				<p><a href="successful_act_p3.php" class="btn btn-primary">Read More</a></p>
			</div>
		</div>
	</div>
	<div class="col-xs-3">
		<div class="thumbnail">
		<img src="./images/p4.jpg" height="600px" width="400px">
			<div class="caption">
				<h3>Preet Weds Tamanna</h3>
				
				<p><a href="successful_act_p4.php" class="btn btn-primary">Read More</a></p>
			</div>
		</div>
	</div>
	
	<div class="col-xs-3">
		<div class="thumbnail">
		<img src="./images/p6.jpg" height="600px" width="400px">
			<div class="caption">
				<h3>Soheb Weds Arohi</h3>
			
				<p><a href="successful_act_p6.php" class="btn btn-primary">Read More</a></p>
			</div>
		</div>
	</div>
	
	<div class="col-xs-3">
		<div class="thumbnail">
		<img src="./images/p7.jpg" height="600px" width="400px">
			<div class="caption">
				<h3>Maithil Weds Rinki</h3>
				
				<p><a href="successful_act_p7.php" class="btn btn-primary">Read More</a></p>
			</div>
		</div>
	</div>
	
	
	<div class="col-xs-3">
		<div class="thumbnail">
		<img src="./images/p8.jpg" height="600px" width="400px">
			<div class="caption">
				<h3>Piyush Weds Trupti</h3>
				
				<p><a href="successful_act_p8.php" class="btn btn-primary">Read More</a></p>
			</div>
		</div>
	</div>
	
	<div class="col-xs-3">
		<div class="thumbnail" height="600px" width="400px">
		<img src="./images/p5.jpg">
			<div class="caption">
				<h3>John Weds Kiyara</h3>
			
				<p><a href="successful_act_p5.php" class="btn btn-primary">Read More</a></p>
			</div>
		</div>
	</div>
	
	
	
	
	
	
	
	
  </div>

</div>


<script src="js/jquery.js"></script>
<script src="js/bootstrap.js"></script>
</body>
</html>