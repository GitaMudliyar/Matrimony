<?php
include "header.php";
require "dbi.php";
?>
<?php
//include "header.php";

//include "validate_worker.php";
?>
<style>
body{
	margin: 0;
	padding: 0;
	background : url(pic1.jpg); 
	background-size: cover;
	background-position: center;
	font-family: sans-serif;
}
</style>

<div class="panel panel-primary" style="max-width:300px;margin:auto">
		<div class="panel-heading">
			SEND MESSAGE
		</div>

		<div class="panel-body panel-center">
		<?php
//include "dbi.php";
$uname=$_GET["uname"];
$fname=$_GET["fname"];
$lname=$_GET["lname"];
//$sid=$_GET["sid"];
$nm=$_GET["nm"];
$f_uname=$_SESSION['uname'];
//$sk=$_GET["sk"];
$udt=date('Y-m-d');

echo $f_uname;
?>

<form class="form" action="insert_message_of_member.php" method="post">		

<div class="form-group">
<label for="nameField">Date</label>
<input type="text" readonly class="form-control input-sm" name="mdate" value="<?php echo $udt;?>" />
</div>

<input type="hidden"  value="<?php echo $f_uname;?>" name="f_uname" />
<input type="hidden"  value="<?php echo $uname;?>" name="uname" />
<input type="hidden"  value="<?php echo $fname; echo $lname;?>" name="nm" />
<!--<input type="hidden"  value="<?php //echo $m_uname;?>" name="m_uname" />-->

<div class="form-group">
<label for="nameField">From</label>
<input type="text" class="form-control input-sm" value="<?php echo $f_uname;?>" placeholder="Member Name" readonly/>
</div>


<div class="form-group">
<label for="nameField">To</label>
<input type="text" class="form-control input-sm" value="<?php echo $fname; echo $lname;?>" placeholder="Member Name" />
</div>

<!--<input type="hidden" class="form-control input-sm" name="sid" />-->

<div class="form-group">
<label for="nameField">Subject</label>
<input type="text" class="form-control input-sm" name="subject" placeholder="Subject" />
</div>

<div class="form-group">
<label for="nameField">Contents</label>
<textarea class="form-control input-sm" rows="4" cols="50"  name="contents" placeholder="Body of Message"></textarea>
</div>


<input type="submit" class="btn btn-success btn-block" value="Send" /> 
</form>
		</div>

		<div class="panel-footer text-center">
<?php			
echo "<a href='view_all_members.php'>Back To Panel</a>";
?>
		</div>

	</div>


<?php
include "footer.php";
?>