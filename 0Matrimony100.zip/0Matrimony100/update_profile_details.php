<?php
include "header.php";   // session started in header file - session_start();
include "dbi.php";
$gender=$_POST["gender"];
$marital_status=$_POST["marital_status"];
$inch=$_POST["inch"];
$feet=$_POST["feet"];

$height=$inch.$feet;
$caste=$_POST["caste"];
$sub_caste=$_POST["sub_caste"];
$gotra=$_POST["gotra"];
$diet=$_POST["diet"];
$smoke=$_POST["smoke"];
$personal_values=$_POST["personal_values"];
$complexion=$_POST["complexion"];
$body_type=$_POST["body_type"];
$special_cases=$_POST["special_cases"];
$residency_status=$_POST["residency_status"];
$language=$_POST["language"];
$aadhar=$_POST["aadhar"];
$country=$_POST["country"];
$city=$_POST["city"];
$working_with=$_POST["working_with"];
$working_as=$_POST["working_as"];
$annual_income=$_POST["annual_income"];
$prefer_working_partner=$_POST["prefer_working_partner"];


mysqli_query($con,"update profile_details set gender='$gender', marital_status='$marital_status',height='$height',caste='$caste',sub_caste='$sub_caste',gotra='$gotra',diet='$diet',smoke='$smoke',personal_values='$personal_values',complexion='$complexion',body_type='$body_type',special_cases='$special_cases',residency_status='$residency_status',language='$language',aadhar='$aadhar',country='$country',city='$city',working_with='$working_with',working_as='$working_as',annual_income='$annual_income',prefer_working_partner='$prefer_working_partner'where uname='$uname'")or die(mysqli_error($con));

if(mysqli_affected_rows($con) > 0)
{
	//echo "<div class='well text-center'><h2 style='color:green'>Success: Profile Details Updated!</h2>";
	//echo "<p><a href='family_details.php'>Back To Panel</a></p></div>";
	header("location:family_details.php");	
}


//include "footer.php";
?>