<?php
include "header.php";   // session started in header file - session_start();
include "dbi.php";

$created_for=$_POST["created_for"];
$fn=$_POST["fname"];
$ln=$_POST["lname"];
//$age=$_POST["age"];
$e_email=$_POST["e_email"];
//$qual=$_POST["qlf"];
//$aadhar_id=$_POST["aadhar_id"];
//$work=$_POST["work"];
$phone=$_POST["phone"];
$dob=$_POST["dob"];
//$contact=$_POST["contact"];
//$udt=date("Y-m-d");

mysqli_query($con,"update personal_information set created_for='$created_for',fname='$fn',lname='$ln',e_email='$e_email',phone='$phone',dob='$dob' where uname='$uname'");
if(mysqli_affected_rows($con) > 0)
{
	//echo "<div class='well text-center'><h2 style='color:green'>Success: Personal Information Updated!</h2>";
	//echo "<p><a href='profile_details.php'>Back To Panel</a></p></div>";
	header("location:profile_details.php");	
}


include "footer.php";
?>