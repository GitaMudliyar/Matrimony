<?php
include "header.php";   // session started in header file - session_start();
include "dbi.php";

/*$fn=$_POST["fname"];
$ln=$_POST["lname"];
$age=$_POST["age"];
$gender=$_POST["gen"];
$qual=$_POST["qlf"];
$aadhar_id=$_POST["aadhar_id"];
//$work=$_POST["work"];
$area=$_POST["area"];
$location=$_POST["loc"];
$contact=$_POST["contact"];
$udt=date("Y-m-d");*/

/*mysqli_query($con,"update worker_profile set fname='$fn',lname='$ln',age='$age',gender='$gender',qualification='$qual',aadhar_id='$aadhar_id',area='$area',location='$location',contact='$contact',udate='$udt' where w_uname='$uname'");
if(mysqli_affected_rows($con) > 0)
{*/
	echo "<div class='well text-center'><h2 style='color:green'>Success: Photo Updated!</h2>";
	echo "<p><a href='personal_information.php'>Back To Panel</a></p></div>";
//}


//include "footer.php";
?>