<?php
include "header.php";
require "dbi.php";
?>
<?php
//include "header.php";   // session started in header file - session_start();

$uname=$_POST["uname"];
$npwd=$_POST["npwd"];
$cpwd=$_POST["cpwd"];
$gender=$_POST["gender"];

if(empty($uname) || empty($npwd))
{
	echo "<div class='well text-center'><h2 style='color:red'>Error: UserName/ Password Required !</h2>";
	echo "<p><a href='registration.php'>Try Again</a></p></div>";
	include "footer.php";
	return;
}

if($npwd!=$cpwd)
{
	echo "<div class='well text-center'><h2 style='color:red'>Error: Passwords Mismatch!</h2>";
	echo "<p><a href='registration.php'>Try Again</a></p></div>";
	include "footer.php";
	return;
}


//require "dbi.php";
$created_at=date("Y-m-d");
$purchase_date = date("Y-m-d");
$query="select * from login where uname='$uname'";


$result = mysqli_query($con,$query) or die(mysqli_error($con));

if(mysqli_num_rows($result) > 0)
{
	echo "<div class='well text-center'><h2 style='color:red'>Error: User Already Exists!</h2>";
	echo "<p><a href='registration.php'>Try Again</a></p></div>";
}
else
{
	$query1 = "insert into login(uname,pwd,role,created_at) values('$uname',md5('$npwd'),'member','$created_at')";

	$query2 = "insert into personal_information(uname) values('$uname') ";
	$query3 = "insert into hobbies_and_traits(uname) values('$uname')";
	$query4 = "insert into about_myself(uname) values('$uname')" ;
	$query5 = "insert into profile_details(uname,gender) values('$uname','$gender')";
	$query6 = "insert into family_details(uname) values('$uname')";
	$query7 = "insert into astro_details(uname) values('$uname')";
	$query8 = "insert into education_and_career(uname) values('$uname')";
	$query9 = "insert into delete_profile(uname) values('$uname')";
	$query10 = "insert into share_story(uname) values('$uname')";
	$query11="insert into package_type (uname,pm_id,purchase_date) values('$uname',1,'$purchase_date')"; 
	$query12 = "insert into expectation (uname) values('$uname')";
	$query13="insert into profile_image (uname) values('$uname')";
	$query14="insert into gallery1 (uname) values('$uname')";
	$query15="insert into gallery2 (uname) values('$uname')";
	$query16="insert into gallery3 (uname) values('$uname')";

	mysqli_query($con,$query2) or die(mysqli_error($con));

	mysqli_query($con,$query1) or die(mysqli_error($con));
	mysqli_query($con,$query3) or die(mysqli_error($con));
	mysqli_query($con,$query4) or die(mysqli_error($con));
	mysqli_query($con,$query5) or die(mysqli_error($con));
	mysqli_query($con,$query6) or die(mysqli_error($con));
	mysqli_query($con,$query7) or die(mysqli_error($con));
	mysqli_query($con,$query8) or die(mysqli_error($con));
	mysqli_query($con,$query9) or die(mysqli_error($con));
	mysqli_query($con,$query10) or die(mysqli_error($con));
	mysqli_query($con,$query11) or die(mysqli_error($con));
	mysqli_query($con,$query12) or die(mysqli_error($con));
	mysqli_query($con,$query13) or die(mysqli_error($con));
	mysqli_query($con,$query14) or die(mysqli_error($con));
	mysqli_query($con,$query15) or die(mysqli_error($con));
	mysqli_query($con,$query16) or die(mysqli_error($con));


	if(mysqli_affected_rows($con) > 0)
	{
		echo "<div class='well text-center'><h2 style='color:green'>Success: User Registered!</h2>";
		echo "<p><a href='login.php'>Login...</a></p></div>";
	}
}

//include "footer.php";
?>
