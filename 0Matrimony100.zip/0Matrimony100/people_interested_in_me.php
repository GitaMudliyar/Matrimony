<?php
include "header.php";
require "dbi.php";
?>
<style>
th,td{
	border-bottom:1px solid Darkgray;
	padding:15px;
	text-align:left;
	background-color:#FFEFD5;
	height:50px;
	text-align:center;
}

tr:hover{
	background-color:FloralWhite;
}
tr,th{
	background-color:#F52887;
}

table{
	background-color:#FFD700;
	width:95%;
}

</style>
<?php
//include "header.php";
//require "dbi.php";

//echo $uname;

/*if(!empty($uname))
{
	$result = mysqli_query($con,"select * from about_myself where uname='$uname'");

	if($row=mysqli_fetch_array($result))
	{
		
$about_self=$row["about_self"];
//$h_activities=$row["h_activities"];

	}
*/


//$f_uname=$_GET["uname"];
$mdate=date("Y-m-d");

$query="select * from interest where  t_uname='$uname'";

$result = mysqli_query($con,$query) or die(mysqli_error($con));

echo "<center>";

//echo "<p><a href='new_cat.php'>New Category</a></p>";
echo "<div class='table-responsive'>";
echo "<table border='1'>";
echo "<tr bgcolor='RoyalBlue'><th><center>Name</center></th><th><center>Sended Request On</center></th>";
echo "<th><center>Like/Dislike</center></th></tr>";
//$cnt=0;

while($row=mysqli_fetch_array($result))
{
	//$cnt++;
	//$id=$row["cpid"];
	$mdate=$row["mdate"];
	$f_uname=$row["f_uname"];
	//$category=$row["category"];
	//$c_detail=$row["c_detail"];
	//$status=$row["status"];

	echo "<tr>";
	//echo "<td align='center'>$cnt</td>";
	//echo "<td>&nbsp;".$f_name."</td>";
	echo "<td>&nbsp;".$row["f_uname"]."</td>";
	echo "<td>&nbsp;".$row["mdate"]."</td>";
	
	echo "<td >&nbsp;<a href='send_like.php?uname=$uname&f_uname=$f_uname' style='background:hotpink' class='btn active  btn-warning'>Like</a>";
	echo "&nbsp;<a href='send_dislike.php?uname=$uname&f_uname=$f_uname' style='background:chartReuse' class='btn active  btn-warning'>Dislike</a></td>";
	//echo "<td>&nbsp;".$row["c_detail"]."</td>";
	//echo "<td>&nbsp;".$row["status"]."</td>";


	echo "</tr>";
}

echo "</table>";
echo "</div>";
echo "<br>";
echo "<p><a href='member.php' class='btn btn-danger btn-block'>Back To Panel</a></p>";

echo "<center>";

mysqli_close($con);
include "footer.php";
?>
