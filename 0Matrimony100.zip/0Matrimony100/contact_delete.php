<?php
include "header.php";
require "dbi.php";
?>
<?php
//include "header.php";
$cid= $_POST["cid"];
//$name=$_POST["name"];

//require "dbi.php";

$query="delete from contact_us where cid=$cid";

mysqli_query($con,$query) or die(mysqli_error($con));

if(mysqli_affected_rows($con) > 0)
{
	header("location:admin.php");
}

?>