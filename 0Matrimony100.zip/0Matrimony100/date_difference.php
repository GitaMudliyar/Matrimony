<?php
include "header.php";
require "dbi.php";

/*
$cid=$_POST["cid"];
$name=$_POST["name"];
$e_mail=$_POST["e_mail"];
$u_date=date("Y-m-d");
$subject=$_POST["subject"];
$message=$_POST["message"];

//$name=$fname+$lname;

//$query="insert into contact_us(cid,name,e_mail,u_date,subject,message) values('$cid','$name','$e_mail','$u_date','$subject','$message' )";

mysqli_query($con,$query) or die(mysqli_error($con));

if(mysqli_affected_rows($con) > 0)
{
	header("location:contact_us_success.php");
}*/
?>
<?php //
/*$date=date_create("2013-03-15");
date_add($date,date_interval_create_from_date_string("40 days"));
echo date_format($date,"Y-m-d");*/


echo date("6");
?>


<?php
$u_date=date("Y-m-d");

$date1=date_create("$u_date");
$date2=date_create("2013-12-12");
$diff=date_diff($date2,$date1);
echo $diff->format("%R%a days");
?>