<?php
include "header.php";
require "dbi.php";
?>
<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">

<style>
* {
  box-sizing: border-box;
}

/* Create two equal columns that floats next to each other */
.column1 {
  float: left;
  width: 28%;
  padding: 10px;
  padding-left:10px;
  height: 600px; /* Should be removed. Only for demonstration Numbers*/
}
.column {
  float: left;
  width: 68%;
  padding: 10px;
  padding-right: 10px;
  height: 600px; /* Should be removed. Only for demonstration */
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

h4{
	padding-left:30px;
}


</style>
</head>

<head>
	<meta charset="utf-8">
	<!-- Mobile Specific Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!-- Font-->
	<link rel="stylesheet" type="text/css" href="css/opensans-font.css">
	<link rel="stylesheet" type="text/css" href="fonts/material-design-iconic-font/css/material-design-iconic-font.min.css">
	<!-- Main Style Css -->
    <link rel="stylesheet" href="css/style.css"/>
</head>
<body>

<?php 
//include "header.php"; 
//include "validate_member.php";

?>
<form action="act_delete_profile.php" method="post">

<div class="row" width="80%">
  <div class="column1" style="background-color:Gainsboro;">
  
  
  <font color="navy">
  
		<h4> <a href="delete_profile.php">Delete Profile</a></h4><br>
    
	</font>
	
	
  </div>
  
  		<?php
//include "dbi.php";

if(!empty($uname))
{
	$result = mysqli_query($con,"select * from delete_profile where uname='$uname'");

	if($row=mysqli_fetch_array($result))
	{
		
$delete_for=$row["delete_for"];
//$h_activities=$row["h_activities"];

	}
	else
	{
		$delete_for="";
	}

}


?>
  
  <div class="column" style="background-color:ghostWhite;">
 <!--   <h2>Column 2</h2>
    <p>Some text..</p>-->
	
	<div class="wizard-header">
<h2>
			            	
			            	<span class="step-text">Delete Profile</span>
			            </h2>
						<div class="wizard-header">
									<!--<h3 class="heading">Delete Profile</h3>-->
									<p>Please enter your infomation and proceed to the next step so we can build your accounts.  </p>
								</div>
								<div class="form-row"> 
								 	
									<div class="form-holder">
										
											<legend>Delete Profile For the Reason:</legend>
											<!--<input type="text" class="form-control" id="first-name" name="first-name" placeholder="First Name" required>-->
											<select name="delete_for" class="form-control text">
											<option value="Select">Select</option>
											<option <?php echo($delete_for=='Found My Partner From ReshimGathi')?"selected":"";?>>Found My Partner From ReshimGathi</option>
											<option value="Found Partner From Other">Found Partner From Other</option>
											<option value="Now Not Interested">Now Not Interested</option>
											<option value="Other Reason">Other Reason</option>
											
										</select>
										
									</div>
									</div>
									
									
									</div>		 <br>
									
									
									
									
									
		 <input type="hidden"  value="<?php echo $uname;?>" name="uname"/>
		 <input type="submit" name="delete" value="Delete"  style="background-color:#2eb82e;"/>
  </div>
</div>
</form>
</body>
</html>