<?php
include "header.php";
//require "dbi.php";
?>
<html>
<body>
<center>


<?php
//include "header.php";

//$uname = $_GET["uname"];

//echo "<p><img src='share_story_pics/pic$uname.png' / height='200px' width='200px'></p>";
?>
<body style="background-image:url('images/back.jpg'); background-size:cover;"><br><br>

<p><a href='index.php'>Back To List</a></p>


<form action="act_story_fileupload.php" method="post" enctype="multipart/form-data">
<input type="hidden" name="uname" value="<?php echo $uname; ?>" />
Select Picture File [.jpg or .png]:
<p>
<input type="file" name="file" />
</p>
<input type="submit"  value="Upload"/>
</center>
</form>
</body>
</html>