<?php
include "header.php";
require "dbi.php";
?>
<?php
//include "header.php";
$uname= $_GET["uname"];
$nm=$_GET["nm"];

//require "dbi.php";


$query="select * from login where uname='$uname'";

$result=mysqli_query($con,$query) or die(mysqli_error($con));

if($row=mysqli_fetch_array($result))
{
	$uname=$row["uname"];
}
else
{
	echo "<center><h2>Member Not Found</h2>";
	echo "<p><a href='admin_view_all_members.php'>Back</a></p></center>";
	exit;
}

?>
<html>
<body>
<center>
<p><a href='admin_view_all_members.php'>Back to List</a></p>

<!--<form action="delete_member.php" method="post">-->

<?php
	echo "<h2 style='color:white'>Remove Member $nm</h2>";
	echo "<h2>Are You Sure?</h2>";
		echo "<td ><a href='delete_member.php?uname=$uname&nm=$nm' class='btn active  btn-warning'>Delete User</a></td>";

?>
<!--
<input type="hidden" name="uname" value="<?php //echo $uname; ?>" />
<input type="hidden" name="nm" value="<?php //echo $nm; ?>" />


<input type="submit"  value="Confirm Delete"/>

</form>-->
</center>
</body>
</html>