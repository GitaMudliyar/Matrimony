
<?php

	// mysql, user,pwd,database
 $con = mysqli_connect("localhost","root","","db_reshim_gathi") or die(mysqli_error($con));
 //$con = mysqli_connect("localhost","websited_reshim","Reshim@123","websited_reshim_gathi") or die(mysqli_error($con));

?>