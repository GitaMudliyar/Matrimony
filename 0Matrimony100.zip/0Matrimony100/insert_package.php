<?php
require "dbi.php";

$package_type=strtoupper($_POST["package_type"]);
$price=($_POST["price"]);
$discount=($_POST["discount"]);
$duration=($_POST["duration"]);
$chat_limit=($_POST["chat_limit"]);

$query="insert into package_master(package_type,price,discount,duration,chat_limit) values('$package_type','$price','$discount','$duration','$chat_limit')";

mysqli_query($con,$query) or die(mysqli_error($con));

if(mysqli_affected_rows($con) > 0)
{
	header("location:package_list.php");
}

?>