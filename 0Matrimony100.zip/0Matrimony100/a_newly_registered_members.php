<?php
include "header.php";
require "dbi.php";
?>
<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}

tr:hover{
	background-color:FloralWhite;
}

table{
	width:95%;
}

</style>

<?php
$current_month=date('m');
//echo $current_month;
//$query="select * from package_type";


	//echo $expires;

$query1="SELECT DATE_FORMAT(created_at, '%m'),uname from login order by created_at desc";

//$query="SELECT DATE_FORMAT(created_at, '%m'),pm_id,uname,m_nm FROM package_type";
	

$result = mysqli_query($con,$query1) or die(mysqli_error($con));

echo "<center>";


echo "<h3 style='color:#ff0040'>Newly Registered Members</h3>";
echo '<div class="table-responsive">';
echo '<table border>';
echo "<tr bgcolor='LawnGreen'><th><center>Sr. No.</center></th>";
echo "<th><center>User Name</center></th>";

$cnt=0;



while($row=mysqli_fetch_array($result))
{
	

	//$pm_id=$row["pm_id"];
	$uname=$row["uname"];
	
	$due_month= $row["DATE_FORMAT(created_at, '%m')"];

	if($current_month== $due_month)
	{
			$cnt++;
		echo "<tr>";
		echo "<td align='center'>$cnt</td>";
		echo "<td>&nbsp;".$row["uname"]." ";
		//echo "<td>&nbsp;".$row["m_nm"]." ";
		//echo "<td>&nbsp;".$row["DATE_FORMAT(created_at, '%m')"]." ";

		echo "</tr>";

	}
}

echo "</table></div>";

		echo "<h5 style='color:#ff0040'><b>$cnt Record Found</b></h5>";

echo "<p><a href='admin.php'></a></p>";

echo "<center>";

mysqli_close($con);
?>