<?php
include "header.php";
require "dbi.php";

$uname=$_GET["uname"];
//$from=$_POST["uname"];
$partner_name=$_GET["partner_name"];

//echo $f_uname;

$query="update share_story set display_on_site='added' where uname='$uname' and partner_name='$partner_name'";
//echo $query;
mysqli_query($con,$query) or die(mysqli_error($con));

if(mysqli_affected_rows($con) > 0)
{
	//header("location:view_matches.php");
	//echo "Success";
	echo "<div class='well text-center'><h2 style='color:green'>Added Story on Site</h2>";
	echo "<p><a href='view_deleted_profiles.php'>Back To List</a></p></div>";
}
else{
echo "<div class='well text-center'><h2 style='color:red'>Already Added on Site</h2>";
	echo "<p><a href='view_deleted_profiles.php'>Back To List</a></p></div>";
}
?>