<?php
include "header.php";
require "dbi.php";
?>
<style>
th,td{
	background-color:#FFEFD5;
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}

tr:hover{
	background-color:FloralWhite;
}
tr,th{
	background-color:ChartReuse;
}

table{
	background-color:#FFD700;
	width:95%;
}
img
{
	border-radius:50%;
	border: 5px solid navy;
}

</style>

<?php
//include "header.php";   // require "header.php";
//include "dbi.php";
$uname=$_GET["uname"];
$f_uname=$_GET["f_uname"];
//$sid=$_GET["sid"];

$query = "select * from message where uname='$uname' and f_uname='$f_uname'"; 
//echo $query;

$result=mysqli_query($con,$query);


mysqli_query($con,"update message set f_status=1, t_status=1  where t_uname='$uname' and f_uname='$f_uname' ") or die(mysqli_error($con));
if(mysqli_affected_rows($con) > 0)
{
	echo "<div class='well text-center'><h2 style='color:green'>Blocked $f_uname</h2>";
	echo "<p><a href='member.php'>Back To Panel</a></p></div>";	
	
}
else
	{
	echo "<div class='well text-center'><h2 style='color:red'>Already Blocked $f_uname</h2>";
	echo "<p><a href='member.php'>Back To Panel</a></p></div>";	
	
}


 ?>
 
 <?php
include "footer.php";   // require "header.php";
 ?>