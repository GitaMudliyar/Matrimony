<?php
include "header.php";
require "dbi.php";

$f_uname=$_SESSION["uname"];
//$from=$_POST["uname"];
$t_uname=$_GET["uname"];
//$to=$_POST["nm"];
$mdate=date("Y-m-d");

//$contents=$_POST["contents"];
//$sid=$_POST["sid"];
//$sk=$_POST["sk"];
//$flag=1;
//if($flag==0)
	
$query1="select * from interest where f_uname='$f_uname' and t_uname='$t_uname'";
mysqli_query($con,$query1) or die(mysqli_error($con));

	if(mysqli_affected_rows($con) > 0)
	{
		echo "<div class='well text-center'><h2 style='color:maroon'>Already Sent!</h2>";
		echo "<p><a href='view_matches.php'>Back To List</a></p></div>";
	}
else
{
$query="insert into interest(f_uname,t_uname,mdate) values('$f_uname','$t_uname','$mdate')";
//echo $query;
mysqli_query($con,$query) or die(mysqli_error($con));

	if(mysqli_affected_rows($con) > 0)
	{
		//header("location:view_matches.php");
		//echo "Success";
		echo "<div class='well text-center'><h2 style='color:green'>Success: Request Sent!</h2>";
		echo "<p><a href='view_matches.php'>Back To List</a></p></div>";
	}

}

?>