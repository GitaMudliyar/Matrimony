<?php
include "header.php";
require "dbi.php";
?>
<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}

tr:hover{
	background-color:FloralWhite;
}

table{
	width:95%;
}

</style>

<?php
//include "header.php";
//require "dbi.php";

$current_month=date('m');
//echo $current_month;
//$query="select * from package_type";


	//echo $expires;

$query1="SELECT DATE_FORMAT(due_date, '%m'),uname,m_nm,due_date from package_type";

//$query="SELECT DATE_FORMAT(due_date, '%m'),pm_id,uname,m_nm FROM package_type";
	

$result = mysqli_query($con,$query1) or die(mysqli_error($con));

echo "<center>";


echo "<h3 style='color:#ff0040'>Matched Interest</h3>";
echo '<div class="table-responsive">';
echo '<table border>';
echo "<tr bgcolor='LawnGreen'><th><center>Sr. No.</center></th>";
echo "<th><center>Sent By</center></th><th><center>Liked By</center><th><center>Due Date</center></th>";

$cnt=0;



while($row=mysqli_fetch_array($result))
{
	
	
	//$pm_id=$row["pm_id"];
	$uname=$row["uname"];
	$m_nm=$row["m_nm"];
	$due_date=$row["due_date"];

	$due_month= $row["DATE_FORMAT(due_date, '%m')"];

	if($current_month== $due_month)
	{
		$cnt++;

		echo "<tr>";
		echo "<td align='center'>$cnt</td>";
		echo "<td>&nbsp;".$row["uname"]." ";
		echo "<td>&nbsp;".$row["m_nm"]." ";
		echo "<td>&nbsp;".$row["DATE_FORMAT(due_date, '%m')"]." ";

		echo "</tr>";

	}
}
		echo "<h5 style='color:#ff0040'><b>$cnt Record Found</b></h5>";

echo "</table></div>";

echo "<p><a href='admin.php'></a></p>";

echo "<center>";

mysqli_close($con);
?>