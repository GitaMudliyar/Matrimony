


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Reshim Gathi</title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link href="css/styles.css" rel="stylesheet">

<style>

body{
	background-color:black;
	<!--background:url(images/footerb.jpg);-->
	 background-size: cover;
}
div{
	<!--background-color: coral;-->
}
li {
  color: green;
}
</style>
</head>

<body>


   <!-- <div class="navbar navbar-inverse">
	<div class="container-fluid" style="background-color:DarkGray;">
	<div class="navbar-header" style="background-color:DarkGrey;">
		<button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#mynavbar-content">
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		<span class="icon-bar"></span>
		</button>-->

	<a class="navbar-brand active" href="gallery.php"><font color="blue">Reshim Gathi</font></a>
	</div>
		<div class="collapse navbar-collapse" id="mynavbar-content" style="background-color:black;">
			<ul class="nav navbar-nav">
				<li class><a href="index.php"><font color="blue">Home</a></font></li>
				<li class="dropdown">
				  <a href="successful.php" class="dropdown-toggle" data-toggle="dropdown" style="background-color:black;"><font color="blue"> About Us</font><b class="caret"></b></a>
					<ul class="dropdown-menu">
						<li><a href="gallery.php"><font color="blue">Gallery</font></a></li>
						<li><a href="successful.php"><font color="blue">Our Successful Stories</font></a></li>
						<!--<li><a href="#">Designing Team</a></li>-->
						<li class="divider"></li>
						<li><a href="rules.php"><font color="blue">Rules</font></a></li>
						<!--<li><a href="#">Registration</a></li>-->
					</ul>
				</li>
				
				<li><a href="contact_us.php"><font color="blue">Contact Us</font></a></li>
				<li><a href="feedback.php"><font color="blue">Feedback</font></a></li>
				<li><a href="registration.php"><font color="blue">New Registration</font></a></li>

							<li>

<?php
/*
		if($role=="admin")
		{
			echo "<li><a href='admin.php'>Admin</a></li>	";
		}
		else if($role=="member")
		{
			echo "<li><a href='member.php'>Member</a></li>";
		}
		else if($role=="worker")
		{
			echo "<li><a href='worker.php'>Worker</a></li>";
		}


		if(empty($uname))
			echo "<li> <a style='background:LavenderBlush' href='login.php'><b>Login</b></a></li>	";
		
		else
		{
			
			echo "<li><a style='background:LavenderBlush' href='logout.php'>Logout $uname</a></li>";
		}
	*/	?>
		
	
			</li>
				
				
			</ul>	
		</div>
	</div>
</div>
<?php include "footer_top_header.php" ?>

