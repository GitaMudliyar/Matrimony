<?php
include "header.php";   // session started in header file - session_start();
include "dbi.php";
//$uname=$_POST["uname"];
$partner_name=$_POST["partner_name"];
$share_your_story=$_POST["share_your_story"];
mysqli_query($con,"select * from delete_profile where uname='$partner_name'") or die(mysqli_error($con));
if(mysqli_affected_rows($con) > 0)
{
	echo " ";
}
else
{
	//echo "<div class='well text-center'><h3 style='color:red'>Partner Not Found.....</h3>";
	header("location:partner_not_found.php");
}


mysqli_query($con,"update share_story set partner_name='$partner_name' ,share_your_story='$share_your_story' where uname='$uname'") or die(mysqli_error($con));
if(mysqli_affected_rows($con) > 0)
{
	echo "<div class='well text-center'><h3 style='color:green'>Thank You for sharing your story.....</h3>";
	echo "<div class='well text-center'><a href='supload.php'> <h2 style='color:Maroon'>To Upload Picture Click Me</h2></a></div></div>";
	
	//echo "<p><a href='share_story.php'>Back To Panel</a></p></div>";
}


	// include "supload.php";
?>      

		  