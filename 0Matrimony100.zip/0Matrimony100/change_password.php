<?php
include "header.php";
require "dbi.php";
?>
<!DOCTYPE html>
<html>
<?php
//include "header.php";
$uname=$_GET["uname"];
?>
 		<?php
//include "dbi.php";

if(!empty($uname))
{
	$result = mysqli_query($con,"select * from login where uname='$uname'");

	if($row=mysqli_fetch_array($result))
	{
		$pwd=$row["pwd"];

		//$udt=date("Y-m-d");
	}
	else
	{
		$pwd="";
	}

}

?>

<head>
    <meta charset="utf-8"/>
    <title>Forgot Your Password</title>
    <link rel="stylesheet" href="css/style_register.css"/>
</head>
<style>
body{
	background-image: url("images/nb.jpg");
	 background-size: cover;
}
</style>
<body>



    <form class="form" action="act_change_password.php" method="post">
        <h1 class="login-title">Change Password...</h1>
		<!--<input type="hidden"  value="<?php //echo $cpwd?>" name="cpwd"/>-->
<input type="hidden"  value="<?php echo $uname;?>" name="uname"/>

	<div class="form-holder">
		<input type="text" class="login-input" name="npwd"  placeholder="New Password" required />
		<input type="text" class="login-input" name="cpwd"  placeholder="New Confirm Password" required />

	<!--

	<input type="text" class="form-control" id="lname" name="npwd" placeholder="Last Name"  style='text-transform:uppercase' required>
	<input type="text" class="form-control" id="lname" name="cpwd" placeholder="Last Name"  style='text-transform:uppercase' required>
	-->			
	</div>
	  
	<input type="submit" name="submit"  class='btn active  btn-danger' value="Save and Next"  style="background-color:blue;"/>

    </form>

</body>
</html>
