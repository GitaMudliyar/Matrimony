<?php
include "header.php";
require "dbi.php";
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Succesful Matches</title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link href="css/styles.css" rel="stylesheet">
</head>
<style>
body{
background-image:url('images/bg1.jpg');
background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;

}
table {
  border-collapse: collapse;
  border-spacing: 0;
  width: 100%;
  border: 1px solid #ddd;
  background-color:White;
  
}

th, td {
  text-align: left;
  padding: 8px;
}
tr.big {
  line-height: 200%;
 font-family: Arial, Helvetica, sans-serif;
}
h1{
<!--background-color:floralWhite;-->

}
</style>

</style>

<?php
//include "header.php";   // require "header.php";
//include "dbi.php";
$uname=$_GET["uname"];
$partner_name=$_GET["partner_name"];

$query = "select * from share_story where display_on_site='added' and uname='$uname' and partner_name='$partner_name'"; 

//$skill=strtoupper($skill);
$result=mysqli_query($con,$query);
 
	//echo "<center><a href='/pic$uname.png'><img src='profile_pics/pic$uname.png' height='250px' width='230px' /></a></center>";
//echo "<br>";
	//echo "<center><a href='view_gallery.php?uname=$uname'><h3>Click Here to View Gallery</h3></a></center>";
echo "<br>";
//echo "<br>";
echo "<center>";
//echo "<center><h1><b> Our Successful Stories</b></h1></center>";
//echo '<div class="table-responsive">';
//echo '<table border>';

/*personal_information*/

while($row=mysqli_fetch_array($result))
{
	//$cnt++;
	$uname=$row["uname"];
	$partner_name = $row["partner_name"];
	$share_your_story=$row["share_your_story"];
	$display_on_site=$row["display_on_site"];
/*
	echo "<tr>";
	echo "<td>";
	echo "<a href='share_story_pics/pic$uname.png'><img src='share_story_pics/pic$uname.png' height='200px' width='200px' /></a>";
		
	//echo "<td>".$cnt."</td>";
	echo "<br>".ucwords($uname." Weds ".$partner_name)."</td>";
	//echo "Partner Name:-&nbsp;&nbsp;".$partner_name."<br><br>";
	echo "<td>".$share_your_story."</td></tr>";
	//echo "Partner Name:-&nbsp;&nbsp;".$display_on_site."<br><br></td>";
	*/
}

//echo "</table></div>";
echo "</center>";
 ?>
 <body>

<center><h2 style='color:white;'><b> Our Successful Story</b></h2></center><br>
<div class="container">
  <div class="row">
	<div class="col-xs-6">
		<div class="thumbnail">
		<?php
		echo "<img src='share_story_pics/pic$uname.png' height='300px' width='250px'>";
			echo '<div class="caption">';
				//echo '<center><h3><b>fd</b></h3></center>';
		
			echo '</div>';
		echo '</div>';
	echo '</div>';
	echo '<div class="col-xs-6">';
		echo '<div class="thumbnail">';
			echo '<div class="caption">';
				
				
				//echo '<h3><p>On 19-12-20</p></h3>';
				//echo '<p><b><h4>PRITAM SHINDE,PUNE Weds SMITA PATIL, PUNE</h4></b></p>';
				echo "<p><b><h4>".strtoupper($uname." Weds ".$partner_name)."</h4></b></p>";
			echo '</div>';
			echo '</div>';
			
	echo '<div style="overflow-x:auto;">';
			echo '<table border="1px">';
			  echo '<tr>  <td> <b><h3>Marriage Of this Groom & Bride</h3></b></td></tr>';
			   echo '<tr class="big"><td><h4>&nbsp;&nbsp;'.$share_your_story.' </h4></td></tr>';
			
	echo"</table></div></div></div></div></body>";	
	?>
 <?php
include "footer.php";   // require "header.php";
 ?>