
<style>
body{
background:url(images/nb3.jpg);

background-size:cover;
}
</style>
<body>
<?php
include "header.php";
include "carouse.php";
?>


</body>
<?php
include "index2.php";
?>