			$(document).ready(function(){
				
							console.log('I am in a new file now');
				// Your jquery code here
						console.log("We are using JQuery");
		//$('selector').action()
		
//		$('p').click(); //click on p
/*		$('p').click(function(){
			console.log('you clicked on p',this);
			//$('p').hide();
			//$(this).hide();
			//$('#id').hide();
			//$('.class').hide();
			
		}); // do this when we click on p
		
*/		
		/*	$('p').dblclick(function(){
			console.log('you double clicked on p',this);
			//$('p').hide();
			//$(this).hide();
			//$('#id').hide();
			//$('.class').hide();
			
		}); // do this when we click on p
		
			$('p').hover(function(){
			console.log('you hovered:',this);
			
		}); // do this when we click on p
		*/
		
		
		
		
		//1. Element Selector:- This is an example of Element Selector which clicks on all p
		//$('p').click();
		
		//2. ID Selector:- This is an example of ID Selector
		//$('#second').click();
		
		//3. Class Selector:- This is an example of Class Selector
		//$('.odd').click();
		
		
		//other selectors
		//$('*').click(); //clicks on all the elements
		//$('p.odd').click(); //clicks on all the elements
		//$('p:first').click(); //clicks on 1st para
		
		//Mouse events:- click,dblclick,mouseenter,mouseleave
		//keyboard events:- keypress, keydown, MediaKeyStatusMap
		//Form events:- submit, change, focus, blur
		//document/window events:- load, resize,scroll, unload
		
		//demonig the on method
/*		$('p').on({
			click: function(){
			console.log('Thanks for clicking',this);
		},
		mouseleave: function(){
			console.log("mouseleave");
		}
		
*/		
		
		})
	
/*	$('#wiki').hide(1000,function(){
		console.log("hidden");
	})
	
	$('#wiki').show(1000,function(){
		console.log("show");
	})
*/
/*
	$('#but').click(function()
	{
		$('#wiki').toggle(1000);
		// 1. fadeOut() 2.fadeIn() 3. fadeToggle()  4. fadeTo()
	})
*/	
/*	$('#but').click(function()
	{
		$('#wiki').fadeOut(1000);
		// 1. fadeOut() 2.fadeIn() 3. fadeToggle()  4. fadeTo()
	})
*/

//Slide Methods- speed and callback parameters are optional
	//$('#wiki').slideUp(1000)
	//$('#wiki').slideDown(1000)
	//$('#wik').slideToggle(1000)


//Animate function in Jquery
	$('#wik').animate({
		opacity:0.3,
		width:'350px'
	},"slow") //slow/fast

/*
	$('#wiki').animate({opacity:0.3},4000)
	$('#wiki').animate({opacity:0.9},4000)
	$('#wiki').animate({width:'350px'},1000)
*/
	
	});
