<?php
include "header.php";
require "dbi.php";
?>
<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}

tr:hover{
	background-color:FloralWhite;
}

table{
	width:95%;
}

</style>

<?php
//include "header.php";
//require "dbi.php";


$uname=$_SESSION["uname"];

$query="select * from interest where f_uname='$uname'";

//echo $query;

$result = mysqli_query($con,$query) or die(mysqli_error($con));

echo "<center>";

//echo "<p><a href='new_package.php'>New Package</a></p>";
echo "<h3 style='color: #009900'>Interest Sent List</h3>";
echo '<div class="table-responsive">';
echo '<table border>';
echo "<tr bgcolor='DeepPink'><th><center>Sr. No.</center></th><th><center>Interest Sent To</center></th>";

$cnt=0;



while($row=mysqli_fetch_array($result))
{
	$cnt++;
	$f_uname=$row["f_uname"];
	$t_uname=$row["t_uname"];	
	
	echo "<tr>";
	echo "<td align='center'>$cnt</td>";
	//echo "<td>&nbsp;".$row["f_uname"]." ";
	echo "<td>&nbsp;".$row["t_uname"]." ";

	echo "</tr>";
}
echo "<h5 style='color: #009900'><b>$cnt Interest Found</b></h5>";
echo "</table></div>";

/*888888*/
echo"<br>";
echo"<br>";


$query="select * from interest where t_uname='$uname' and comment='like'";
//$query="select * from interest where t_uname='$t_uname' and comment='like'";

//echo $query;

$result = mysqli_query($con,$query) or die(mysqli_error($con));

echo "<center>";

//echo "<p><a href='new_package.php'>New Package</a></p>";
echo "<h3 style='color:#ff0040'>People Who Liked Me</h3>";
echo '<div class="table-responsive">';
echo '<table border>';
echo "<tr bgcolor='LawnGreen'><th><center>Sr. No.</center></th><th><center>Liked Me</center></th>";

$cnt=0;


while($row=mysqli_fetch_array($result))
{
	$cnt++;
	$f_uname=$row["f_uname"];
	$t_uname=$row["t_uname"];	
	
	echo "<tr>";
	echo "<td align='center'>$cnt</td>";
	//echo "<td>&nbsp;".$row["f_uname"]." ";
	echo "<td>&nbsp;".$row["t_uname"]." ";

	echo "</tr>";
}
echo "<h5 style='color:#ff0040'><b>$cnt Interest Found</b></h5>";
echo "</table></div>";

echo "<p><a href='member.php'></a></p>";

echo "<center>";

mysqli_close($con);
?>