<?php
include "header.php";
//require "dbi.php";
?>
<!DOCTYPE html>
<html>
<?php
//include "header.php";
//523af537946b79c4f8369ed39ba78605 password of ad
//523af537946b79c4f8369ed39ba78605 password of ad
?>
<head>
    <meta charset="utf-8"/>
    <title>Registration</title>
    <link rel="stylesheet" href="css/style_register.css"/>
</head>
<style>
body{
	background-image: url("images/nb.jpg");
	 background-size: cover;
}
</style>


<script type="text/javascript">
    function blockSpecialChar(e){
        var k;
        document.all ? k = e.keyCode : k = e.which;
        return ((k > 64 && k < 91) || (k > 96 && k < 123) || k == 8 || k == 32 || (k >= 48 && k <= 57));
        }
    </script>

<body>

    <form class="form" action="act_register.php" method="post">
        <h1 class="login-title">Registration</h1>
        <input type="text" class="login-input" name="uname" placeholder="Username" onkeypress="return blockSpecialChar(event)" required />
		<!--<input type="password" class="login-input" name="npwd" placeholder="New Password" required />
		<input type="password" class="login-input" name="cpwd" placeholder="Confirm Password" required />-->
		
		<input type="password" pattern=".{4,8}" class="login-input" name="npwd" placeholder="New Password" required title="4 to 8 characters">
		
		<input type="password" pattern=".{4,8}" class="login-input" name="cpwd" placeholder="Confirm Password" required title="4 to 8 characters">
		
									  <div class="form-holder">
										<!--<fieldset>
											<legend>Gender</legend>-->
											<select name="gender" class="form-control text">
											
											<option value="Select"> Select Gender of Candidate</option>
											
											 <option value="Male">Male</option>
	                                 <option value="Female">Female</option>
	                                 
	                                  </select>
									 <!-- </fieldset>-->
									
										
									</div>
		<br>
		
	    <input type="submit" name="submit" value="Register" class="login-button">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
		<p class="link" class="login-button"> <a href="index.php"> Cancel</a></p><br>
        <p class="link">Already have an account? <a href="login.php">Login here</a></p>
    </form>

</body>
</html>
