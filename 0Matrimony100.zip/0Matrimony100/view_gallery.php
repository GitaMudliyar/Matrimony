<?php
include "header.php";
require "dbi.php";
?>
<!DOCTYPE html>

<?php
//include "header.php";   // require "header.php";
//include "dbi.php";
$uname=$_GET["uname"];


$loc1="album_photos/album1/pic$uname.png";
$loc2="album_photos/album2/pic$uname.png";
$loc3="album_photos/album3/pic$uname.png";
?>
<html> 

<head> 
	<title>Image-Gallery</title> 
	<link rel="stylesheet"
		type="text/css"
		href="lightbox2/dist/css/lightbox.min.css"> 
	<script src= 
"lightbox2/dist/js/lightbox-plus-jquery.min.js"> 
	</script> 
	<style> 
		body { 
			text-align: center; 
			//background:url(images/nb.jpg);

background-size:cover;
		} 
		img{
			border: 1px solid black;
		}
		
		h2 { 
			color: purple; 
		} 

		.gallery { 
			margin: 10px 40px; 
		} 
		
		.gallery img { 
			width: 200px; 
			height: 200px; 
			transition: 1s; 
			padding: 5px; 
		} 
		
		.gallery img:hover { 
			filter: drop-shadow(4px 4px 6px gray); 
			transform: scale(1.1); 
		} 

	</style> 
</head> 

<body > 
	
	<div class="gallery"> 
		<!--<a href= "<?php// echo "album_photos/album1/pic$uname.png"; ?>" data-lightbox="mygallery"> -->
		<?php
		
		$pull="select * from gallery1 where uname='$uname'";
			$res = mysqli_query($con,$pull) or die(mysqli_error($con));
			
			//$res=$db->query($pull);
        $pics=$res->fetch_assoc();
         
				//echo "<td>";
				echo "<img src='album_photos/album1/$pics[url]' height='200px' width='200px' />";
		?>
		<!--<a href= "<?php //echo "album_photos/album2/pic$uname.png"; ?>" data-lightbox="mygallery"> -->
		<?php
		
		$pull="select * from gallery2 where uname='$uname'";
			$res = mysqli_query($con,$pull) or die(mysqli_error($con));
			
			//$res=$db->query($pull);
        $pics=$res->fetch_assoc();
         
				//echo "<td>";
				echo "<img src='album_photos/album2/$pics[url]' height='200px' width='200px' />";
		?>
		<!--<a href= "<?php //echo "album_photos/album3/pic$uname.png"; ?>" data-lightbox="mygallery"> -->
		<?php
		
		$pull="select * from gallery3 where uname='$uname'";
			$res = mysqli_query($con,$pull) or die(mysqli_error($con));
			
			//$res=$db->query($pull);
        $pics=$res->fetch_assoc();
         
				//echo "<td>";
				echo "<img src='album_photos/album3/$pics[url]' height='200px' width='200px' />";
		?>
	</a>
			<!--<img src= "<?php //echo "album_photos/album1/pic$uname.png"; ?>"> 
		</a> 
		<a href= "<?php //echo "album_photos/album2/pic$uname.png"; ?>" data-lightbox="mygallery"> 
			<img src= "<?php //echo "album_photos/album2/pic$uname.png"; ?>"> 
		</a> 
		<a href= "<?php //echo "album_photos/album3/pic$uname.png"; ?>" data-lightbox="mygallery"> 
			<img src= "<?php //echo "album_photos/album3/pic$uname.png"; ?>"> 
		</a> -->
		
	</div> 
	<h2><b><i>Made For Each Other</i></b></h2> 
	<h4><b><i>To a Lifetime of Adventures Together</i></b> <h4>
</body> <br><br><br>
<br><br>
<?php
include "footer.php";
?>
</html> 
