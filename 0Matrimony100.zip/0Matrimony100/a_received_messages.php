<?php
include "header.php";
require "dbi.php";
?>
<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}

tr:hover{
	background-color:FloralWhite;
}
th{
	background-color:#F52887;
}

table{
	width:95%;
}

</style>
<?php
//include "header.php";
//require "dbi.php";

$query="select * from message where t_uname='$uname' order by mid";
//$query = "select * from member_profile where m_uname in (select to_u from messsage where service_type='$skill')";
$result = mysqli_query($con,$query) or die(mysqli_error($con));

echo "<center>";

echo "<p><b><h3>Message</h3></b></p>";

echo '<div class="table-responsive">';
echo "<table border='1'>";
echo "<tr bgcolor='ChartReuse'><th><center>Sr. No.</center></th><th><center>From</center></th><th><center>Date</center></th>";
echo "<th><center>Subject</center></th><th><center>Contents</center></th></tr>";

$cnt=0;

while($row=mysqli_fetch_array($result))
{
	$cnt++;
	
	echo "<tr>";
	echo "<td align='center'>$cnt</td>";
	echo "<td>&nbsp;".$row["from_u"]."</td>";
	echo "<td>&nbsp;".$row["mdate"];
	
	echo "<td>&nbsp;".$row["subject"];
	echo "<td>&nbsp;".$row["contents"]."</td>";
	
	echo "<td>";
	//echo "&nbsp;<a href='edit_service.php?w_uname=$w_uname'>Send Message</a>";
	
	echo "</tr>";
}

echo "</table></div>";

echo "<br><p><a href='admin.php'>Back to Panel</a></p>";

echo "<center>";

mysqli_close($con);
?>