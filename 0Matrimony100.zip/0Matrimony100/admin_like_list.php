<?php
include "header.php";
require "dbi.php";
?>
<style>
th,td{
	padding:15px;
	text-align:left;
	border-bottom:1px solid DeepPink;
	height:50px;
	text-align:center;
}

tr:hover{
	background-color:FloralWhite;
}

table{
	width:95%;
}

</style>

<?php
//include "header.php";
//require "dbi.php";

$query="select * from interest where comment='like'";

//echo $query;

$result = mysqli_query($con,$query) or die(mysqli_error($con));

echo "<center>";

//echo "<p><a href='new_package.php'>New Package</a></p>";
echo "<h3 style='color:#ff0040'>Matched Interest</h3>";
echo '<div class="table-responsive">';
echo '<table border>';
echo "<tr bgcolor='LawnGreen'><th><center>Sr. No.</center></th>";
echo "<th><center>Sent By</center></th><th><center>Liked By</center></th>";

$cnt=0;



while($row=mysqli_fetch_array($result))
{
	$cnt++;
	$f_uname=$row["f_uname"];
	$t_uname=$row["t_uname"];	
//	$package_type=strtoupper($_POST["package_type"]);
	
	echo "<tr>";
	echo "<td align='center'>$cnt</td>";
	echo "<td>&nbsp;".strtoupper($row["f_uname"])." ";
	echo "<td>&nbsp;".strtoupper($row["t_uname"])." ";

	echo "</tr>";
}
echo "<h5 style='color:#ff0040'><b>$cnt Interest Found</b></h5>";
echo "</table></div>";
















echo "<p><a href='member.php'></a></p>";

echo "<center>";

mysqli_close($con);
?>