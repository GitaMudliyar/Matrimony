<?php
include "header.php";
require "dbi.php";
?>
<?php //include "header.php"; ?>
<!DOCTYPE html>

<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Succesful Matches</title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link href="css/styles.css" rel="stylesheet">
</head>
<style>
body{
background-image:url('images/back10.jpg');
background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: cover;

}
h1{
<!--background-color:floralWhite;-->
}
img
{
	border-radius:20%;
	border: 5px solid navy;
}
</style>
<body>


<div class="container">
  <div class="row">
  
  
<?php
//include "header.php";   // require "header.php";
//include "dbi.php";

$query = "select * from share_story where display_on_site='added'"; 

//$skill=strtoupper($skill);
$result=mysqli_query($con,$query);
 
	//echo "<center><a href='/pic$uname.png'><img src='profile_pics/pic$uname.png' height='250px' width='230px' /></a></center>";
//echo "<br>";
	//echo "<center><a href='view_gallery.php?uname=$uname'><h3>Click Here to View Gallery</h3></a></center>";
//echo "<br>";
//echo "<br>";
//echo "<center><center><h1><b> Our Successful Stories</b></h1></center>";
echo '<div class="table-responsive">';
echo '<table border="0">';

echo "<center><h1><b> Our Successful Stories</b></h1></center>";
$cnt=0;
while($row=mysqli_fetch_array($result))
{
	//$cnt++;
	$uname=$row["uname"];
	$partner_name = $row["partner_name"];
	$share_your_story=$row["share_your_story"];
	$display_on_site=$row["display_on_site"];
	
	$cnt++;
	
/*	  <table>
  <tr>
    <th>Month</th>
    <th>Savings</th>
  </tr>
  <tr>
    <td>January</td>
    <td>$100</td>
  </tr>
</table>*/
	echo "<tr>";
	echo "<td>";
	echo "<a href='share_story_pics/pic$uname.png'><img src='share_story_pics/pic$uname.png' height='200px' width='200px' /></a>";
		
	echo "<br>".ucwords($uname." Weds ".$partner_name);

	echo "<center><p><a href='successful_stories_read_more.php?uname=$uname&partner_name=$partner_name' class='btn btn-primary'>";
	echo "Read More</a></p></center>";
	echo "</td></tr>";

//	echo "</td>";
	
/*	if($cnt<4)
	{
	echo "<td>";
	
	
/*	echo '<div class="col-xs-3">';
		echo '<div class="thumbnail">';
		
		//echo '<img src="share_story_pics/pic$uname.png" height="600px" width="400px">';
		echo "<a href='share_story_pics/pic$uname.png'><img src='share_story_pics/pic$uname.png' height='200px' width='200px' /></a>";
		
			
			echo '<div class="caption">';
				echo '<h3>'.ucwords($uname." Weds ".$partner_name).'</h3>';
				echo '<p><a href="successful_stories_read_more.php?uname=$uname&partner_name=$partner_name" class="btn btn-primary">Read More</a></p>';
			
			echo '</div>';
		echo '</div>';
	echo '</div>';*/
//$service_type=strtoupper($_POST["service_type"]);
	/*echo "<tr>";
	echo "<td>";
	echo "<a href='share_story_pics/pic$uname.png'><img src='share_story_pics/pic$uname.png' height='200px' width='200px' /></a>";
		
	//echo "<td>".$cnt."</td>";
	echo "<br>".ucwords($uname." Weds ".$partner_name)."</td>";
	//echo "Partner Name:-&nbsp;&nbsp;".$partner_name."<br><br>";
	//echo "<td>".$share_your_story."</td></tr>";
	echo "<td><p><a href='successful_stories_read_more.php?uname=$uname&partner_name=$partner_name' class='btn btn-primary'>Read More</a></p></td></tr>";
	//echo "Partner Name:-&nbsp;&nbsp;".$display_on_site."<br><br></td>";
	
	//echo $cnt;
	echo "</td>";
	
	}
	else
	{
		$cnt=0;
		//echo "<br><br><br><br><br><br><br><br>";
	}*/
}

echo "</table>";
echo "  </div>";

echo "</div>";
//echo "</center>";
//echo "<br>";
 ?>


<script src="js/jquery.js"></script>
<script src="js/bootstrap.js"></script>
</body>
</html>
 
 <?php
include "footer.php";   // require "header.php";
 ?>