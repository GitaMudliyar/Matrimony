<!DOCTYPE html>
<html lang="en">

<head>
<style>

#c{
  background-color: black;
  color: black;
 padding: 4px;
  text-align: center;
} 

.h3{
     font-color: #ffffff;
}


 hr.new2 {
  border-bottom: 1px dashed white;
}



 body{
	 width:100%;
    background-color:black;
    background-size:cover;
}






</style>

  <title>Bootstrap Example</title>
  <!--<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
-->
</head>
<body width="100px">

<!--<div class="jumbotron text-center">
  <h1>My First Bootstrap Page</h1>
  <p>Resize this responsive page to see the effect!</p> 
</div>-->


<div class="container-fluid" id="c" width="100%">
  <div class="row">
    <div class="col-sm-4" id="c1">
	
      <font color="white"><h4>Click here for online payment</h4></font>
	  <hr class="new2">
      <img src="images/googlep.png" height="50px" width="100px">
	  <hr class="new2">
	  <img src="images/app1.jpg" height="40px" width="150px">
      
    </div>
    <div class="col-sm-4" id="c2">
      
      <img src="images/r.jpg" height="250px" width="300px">
    </div>
    <div class="col-sm-4" id="c3">
      
      <h4><a href="https://www.astrosage.com/freechart/confirmMatchMaking.asp" target="_blank" ><font color="white">Click here for horoscope</font></a></h4>
	  
      <font color="white"><hr class="new2"></font>
	  
      <font color="white"><h4>Director:Pankaj Kamble</h4></font>
	  <hr class="new2">
	  
      <font color="white"><h4>contact@reshimgathi.com</h4>
	   <h4>65698565655 /656464545665</h4></font>
	  <hr class="new2">
    </div>
	
  </div>
</div>
<?php include "footer_header.php"?>


</body>
</html>
